<?php

use App\PaymentPlatform;
use Illuminate\Database\Seeder;

class PaymentPalformSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        PaymentPlatform::create([
            'name' => 'PayPal',
            'image' => 'paypal.png'
        ]);

        PaymentPlatform::create([
            'name' => 'Stripe',
            'image' => 'stripe.png'
        ]);
    }
}
