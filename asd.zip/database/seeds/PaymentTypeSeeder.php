<?php

use App\PaymentType;
use Illuminate\Database\Seeder;

class PaymentTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $types = [
            'per hour',
            'per day',
            'per week',
            'per month',
            'per year',
        ];
        foreach ($types as $type) {
            PaymentType::create([
                'name' => $type
            ]);
        }
    }
}
