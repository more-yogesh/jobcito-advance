<?php

use Illuminate\Database\Seeder;
use App\JobType;

class JobTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $jobTypes = [
            'full time',
            'part time',
            'freelancer',
            'work from home',
            'contract base',
            'permanent'
        ];
        foreach ($jobTypes as $jobType) {
            JobType::create([
                'name' => $jobType
            ]);
        }
    }
}
