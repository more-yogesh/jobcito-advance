<?php

use Illuminate\Database\Seeder;

class JobSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $userIds = [
        //     '2',
        //     '3',
        //     '4',
        //     '5',
        //     '6',
        // ];
        // $jobTypes = [
        //     '1',
        //     '2',
        //     '3',
        //     '4',
        //     '5',
        //     '6',
        // ];
        // $contractTypes = [
        //     '1',
        //     '2',
        //     '3',
        //     '4',
        //     '5',
        //     '6',
        //     '7'
        // ];

        // $paymentType = '4';


        // [
        //     'user_id',
        //     'job_type_id',
        //     'contract_type_id',
        //     'payment_type_id',
        //     'category_id', // 1
        //     'title',
        //     'description',
        //     'state',
        //     'zipcode',
        //     'city',
        //     'status',
        //     'salary_from',
        //     'salary_to',
        //     'positions',
        //     'expiry_date'
        // ];
    }
}
