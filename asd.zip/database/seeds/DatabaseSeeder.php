<?php


use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(UserSeeder::class);
        $this->call(CategorySeeder::class);
        $this->call(UniversitySeeder::class);
        $this->call(JobTypeSeeder::class);
        $this->call(PaymentTypeSeeder::class);
        $this->call(ContractTypeSeeder::class);
        // this should be in last for foreign key du to constraints
        $this->call(JobSeeder::class);
        $this->call(CurrencySeeder::class);
        $this->call(PaymentPalformSeeder::class);
    }
}
