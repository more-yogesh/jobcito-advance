<?php

use Illuminate\Database\Seeder;
use App\Category;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $categories = [
            'Accounting',
            'Interior Design',
            'Bank',
            'Content Writing',
            'Consultant',
            'Engineering',
            'Export Import',
            'Merchandiser',
            'Security',
            'HR',
            'Hotel',
            'Application Programming',
            'Client Server',
            'DBA',
            'Ecommerce',
            'ERP',
            'VLSI',
            'Mainframe',
            'Middleware',
            'Network administrator',
            'IT',
            'Testing',
            'System Programming',
            'EDP',
            'Telecom Software',
            'Telecom',
            'BPO',
            'Legal',
            'Marketing',
            'Packaging',
            'Pharma',
            'Maintenance',
            'Logistics',
            'Sales',
            'Secretary',
            'Corporate Planning',
            'Site Engineering',
            'Film',
            'Teacher',
            'Airline',
            'Graphic Designer',
            'Analytics',
            'Shipping',
            'Analytics',
            'Business Intelligence'
        ];
        foreach ($categories as $category) {
            Category::create([
                'name' => $category . " Jobs",
                'description' => '',
                'status' => 'enabled'
            ]);
        }
    }
}
