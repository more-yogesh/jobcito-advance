<?php

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use App\User;
use App\CompanyProfile;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Role::create(['name' => 'admin']);
        Role::create(['name' => 'company']);
        Role::create(['name' => 'employee']);
        $user = User::create([
            'mobile' => '9998822069',
            'email' => 'admin@jobcito.com',
            'show_password' => 'admin@247',
            'password' => bcrypt('admin@247')
        ]);
        $user->assignRole('admin');

        // create companies
        $accountant = User::create([
            'email' => 'acc@jobcito.com',
            'mobile' => '9265727188',
            'password' => bcrypt('hr24870@$$!'),
            'show_password' => 'hr24870@$$!'
        ]);

        $profile = new CompanyProfile();
        $profile->user_id = $accountant->id;
        $profile->name = 'Accountant Jobs Jobcito';
        $profile->save();
        $accountant->assignRole('company');



        $it = User::create([
            'email' => 'it@jobcito.com',
            'mobile' => '9265727181',
            'password' => bcrypt('it24870@$$!'),
            'show_password' => 'it24870@$$!'
        ]);

        $profile = new CompanyProfile();
        $profile->user_id = $it->id;
        $profile->name = 'IT Jobs Jobcito';
        $profile->save();
        $it->assignRole('company');



        $sales = User::create([
            'email' => 'sales@jobcito.com',
            'mobile' => '9265727182',
            'password' => bcrypt('sale24870@$$!'),
            'show_password' => 'sale24870@$$!'
        ]);
        $profile = new CompanyProfile();
        $profile->user_id = $sales->id;
        $profile->name = 'Sales Jobs Jobcito';
        $profile->save();
        $sales->assignRole('company');


        $textile = User::create([
            'email' => 'textile@jobcito.com',
            'mobile' => '9265727183',
            'password' => bcrypt('textile24870@$$!'),
            'show_password' => 'textile24870@$$!'
        ]);
        $profile = new CompanyProfile();
        $profile->user_id = $textile->id;
        $profile->name = 'Textile Jobs Jobcito';
        $profile->save();
        $textile->assignRole('company');

        $other = User::create([
            'email' => 'other@jobcito.com',
            'mobile' => '9265727185',
            'password' => bcrypt('other24870@$$!'),
            'show_password' => 'other24870@$$!'
        ]);
        $profile = new CompanyProfile();
        $profile->user_id = $other->id;
        $profile->name = 'Other Jobs Jobcito';
        $profile->save();
        $other->assignRole('company');
    }
}
