<?php

use Illuminate\Database\Seeder;
use App\ContractType;

class ContractTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $cotractTypes = [
            'temporary',
            'contract',
            'internship',
            'commission',
            'volunteer',
            'fresher',
            'walk-in'
        ];
        foreach ($cotractTypes as $cotractType) {
            ContractType::create([
                'name' => $cotractType
            ]);
        }
    }
}
