<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployeeProfilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employee_profiles', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('category_id')->nullable()->comment("job profession type is here");
            $table->unsignedBigInteger('job_type_id')->nullable()->comment("partime, full time, contract, work from home etc");
            $table->string('name')->nullable();
            $table->string('job_title')->nullable();
            $table->bigInteger('salary')->default(0);
            $table->date('dob')->nullable();
            $table->string('gender')->nullable();
            $table->string('type')->nullable();
            $table->string('street_address_search')->nullable();
            $table->string('street_search')->nullable();
            $table->string('house_no')->nullable();
            $table->string('street_address')->nullable();
            $table->string('state')->nullable();
            $table->string('city')->nullable();
            $table->string('zipcode')->nullable();
            $table->string('country')->nullable();
            $table->text('skills')->nullable();
            $table->text('description')->nullable();
            $table->timestamps();
            /**
             * adding foreign key
             */
            $table->index('user_id');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->index('category_id');
            $table->foreign('category_id')->references('id')->on('categories')->onDelete('cascade');
            $table->index('job_type_id');
            $table->foreign('job_type_id')->references('id')->on('job_types')->onDelete('cascade');
            /**
             * end adding foreign key 
             */
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employee_profiles');
    }
}
