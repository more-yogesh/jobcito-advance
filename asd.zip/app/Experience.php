<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Experience extends Model
{
    public function user()
    {
        return  $this->belongsTo('App\User');
    }
    protected $casts = [
        'from_date' => 'date',
        'to_date' => 'date',
    ];
}
