<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\Image\Manipulations;

class User extends Authenticatable implements MustVerifyEmail, HasMedia
{
    use Notifiable, SoftDeletes, HasRoles, InteractsWithMedia;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'mobile', 'email', 'password', 'show_password'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function registerMediaConversions(Media $media = null): void
    {
        $this->addMediaConversion('thumb-logo')
            ->width(150)
            ->height(180)
            ->sharpen(10);

        $this->addMediaConversion('logo')
            ->width(350)
            ->height(450)
            ->sharpen(10);
    }

    public function employee()
    {
        return $this->hasOne('App\EmployeeProfile', 'user_id');
    }
    public function company()
    {
        return $this->hasOne('App\CompanyProfile');
    }
    public function educations()
    {
        return $this->hasMany('App\Education');
    }
    public function experiences()
    {
        return $this->hasMany('App\Experience');
    }
    public function employeePercentage(): int
    {
        $percentage = 0;
        $fields = auth()->user()->employee;

        if ($fields->job_title) {
            $percentage += 15;
        }
        if ($fields->dob) {
            $percentage += 25;
        }
        if ($fields->city) {
            $percentage += 15;
        }
        if ($fields->category_id) {
            $percentage += 15;
        }
        if ($fields->description) {
            $percentage += 30;
        }
        return $percentage;
    }

    public function companyPercentage(): int
    {
        $percentage = 0;
        $fields = auth()->user()->company;

        if ($fields->name) {
            $percentage += 10;
        }
        if ($fields->zipcode) {
            $percentage += 10;
        }
        if ($fields->city) {
            $percentage += 15;
        }
        if ($fields->state) {
            $percentage += 15;
        }
        if ($fields->description) {
            $percentage += 25;
        }
        if ($fields->contact_person_name) {
            $percentage += 25;
        }
        return $percentage;
    }

    public function jobs()
    {
        return  $this->hasMany('App\Job');
    }

    public function favorites()
    {
        return $this->belongsToMany(Job::class, 'favorites', 'user_id', 'job_id')->withTimeStamps();
    }

    public function apply()
    {
        return $this->belongsToMany(Job::class, 'applied_jobs', 'user_id', 'job_id')->withTimeStamps();
    }

    public function appliedJobs()
    {
        return  $this->hasMany('App\AppliedJob');
    }
}
