<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class University extends Model
{
    protected $fillable = ['name', 'state', 'city', 'zipcode', 'status'];

    public function education()
    {
        return $this->hasMany('App\Education');
    }
}
