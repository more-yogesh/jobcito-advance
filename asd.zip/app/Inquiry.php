<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Inquiry extends Model
{
    protected $fillable = [
        'course_name',
        'name',
        'mobile',
        'status',
        'description'
    ];
}

