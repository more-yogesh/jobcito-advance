<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobType extends Model
{

    protected $fillable = [
        'name',
        'status'
    ];

    public function job()
    {
        return  $this->hasOne('App\Job');
    }
}
