<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;
use App\Favorite;

class Job extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'user_id',
        'job_type_id',
        'contract_type_id',
        'payment_type_id',
        'category_id',
        'title',
        'description',
        'state',
        'zipcode',
        'city',
        'status',
        'salary_from',
        'salary_to',
        'positions',
        'expiry_date'
    ];

    public function user()
    {
        return  $this->belongsTo('App\User');
    }
    public function jobType()
    {
        return  $this->belongsTo('App\JobType');
    }
    public function paymentType()
    {
        return  $this->belongsTo('App\PaymentType');
    }
    public function contractTypes()
    {
        return $this->belongsToMany('App\ContractType');
    }
    public function category()
    {
        return $this->belongsTo('App\Category');
    }
    public function favorited()
    {
        return (bool) Favorite::where('user_id', Auth::id())
            ->where('job_id', $this->id)
            ->first();
    }

    public function applied()
    {
        return (bool) AppliedJob::where('user_id', Auth::id())
            ->where('job_id', $this->id)
            ->first();
    }

    public function appliedJobs()
    {
        return  $this->hasMany('App\AppliedJob');
    }

    public function companySlug()
    {
        return str_slug($this->user->company->name . " " . $this->user->company->city . " " . $this->user->company->state) . "-" . $this->user->id;
    }

    public function jobSlug()
    {
        return  str_slug($this->title . '-' . $this->city . '-' . $this->state . ' ' . $this->id);
    }
    public function applications()
    {
        return $this->hasMany('App\AppliedJob');
    }
    public function contacts()
    {
        return $this->hasMany('App\Contact');
    }
    public function shortListed()
    {
        return $this->hasMany(AppliedJob::class)->whereStatus('shortlisted');
    }
}
