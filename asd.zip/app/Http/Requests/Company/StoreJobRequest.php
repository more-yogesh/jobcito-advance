<?php

namespace App\Http\Requests\Company;

use Illuminate\Foundation\Http\FormRequest;

class StoreJobRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title' => 'required|min:3|max:120',
            'description' => 'required|min:60|max:3000',
            'zipcode' => 'required|numeric|digits:6',
            'city' => 'required',
            'state' => 'required',
            'category' => 'required'
        ];
    }
}
