<?php

namespace App\Http\Controllers\Employee;

use App\Category;
use App\Http\Controllers\Controller;
use App\Job;
use App\JobType;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Artesaos\SEOTools\Facades\OpenGraph;
use Artesaos\SEOTools\Facades\SEOTools;

class WelcomeController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        $jobsCount = Job::count();
        SEOTools::setTitle('Home | Job Consultancy in Surat | Surat\'s No.1 Job Consultancy, We provide jobs in IT, Sales, Pharma and many other categories for free');
        SEOTools::setDescription('Jobcito is the best job consultancy in Surat provide job placement and recruitment services. Our recruitment agency have best placement consultants in Surat help you to find your desire jobs for free.');
        return view('welcome', compact('categories', 'jobsCount'));
    }

    public function search(Request $request, Job $job)
    {

        // SEO
        SEOTools::setTitle('Search Job | Find Remote Jobs, Freelance Work and Work From Home jobs for free.');
        SEOTools::setDescription('Find Freelance jobs, Remote Jobs, Best Contract Jobs, Work from apportunities, Permanent jobs in surat');

        // end SEO
        // job filters
        $jobs = $job->newQuery();
        if ($request->filled('job')) {
            $jobs->where('title', 'like', '%' . $request->job . '%');
            $jobs->OrWhere('description', 'like', '%' . $request->job . '%');
        }

        // city filter
        if ($request->filled('location')) {
            $jobs->where('city', $request->location);
        }

        // category filter
        if ($request->filled('category_id')) {
            $jobs->where('category_id', $request->category_id);
        }

        // search by job types
        if ($request->filled('job_type')) {
            $jobs->whereHas('jobType', function ($query) use ($request) {
                $query->whereIn('id', $request->job_type);
            });
        }

        // search by salary range
        if ($request->filled('salary_range')) {
            $salary = explode("-", $request->salary_range);
            $salaryFrom = $salary[0];
            $salaryTo = $salary[1];
            if (is_numeric($salaryTo)) {
                $jobs->where('salary_from', '>', $salaryFrom * 1000);
                $jobs->where('salary_to', '<', $salaryTo * 1000);
            } else {
                $jobs->where('salary_from', '>', $salaryFrom * 1000);
            }
        }

        if ($request->filled('posted_date')) {
            $hours = $request->posted_date;
            $jobs->where('created_at', '<', Carbon::now()->subHours($hours)->toDateTimeString());
        }

        $jobs->orderBy('created_at', 'DESC');

        $jobs = $jobs->paginate(10)->appends($request->query());
        $categories = Category::all();
        $jobTypes = JobType::all();
        $userFavourites = [];
        if (Auth::check()) {
            $userFavourites = Auth::user()->favorites;
        }

        return view('search', compact('categories', 'jobTypes', 'jobs', 'userFavourites'));
    }
    public function showJob($query, Request $request)
    {
        $stringArray = explode("-", $query);
        $id = end($stringArray);

        $job = Job::find($id);

        // SEO
        SEOTools::setTitle($job->title." at ".$job->city."| Salary: ₹" . number_format($job->salary_from) . " To ₹" . number_format($job->salary_to) . " | $job->state (" . $job->zipcode . ") ");
        SEOTools::setDescription($job->title . " " . strip_tags($job->description));
        OpenGraph::addImage(asset('hiring.jpg'), ['height' => 1200, 'width' => 630]); 
        // end SEO
        $similarJobs = Job::where('category_id', $job->category_id)
            ->where('category_id', $job->category_id)
            ->where('id', '<>', $id)
            ->take(5)
            ->get();
        return view('job-detail', compact('job', 'similarJobs'));
    }

    public function showCopmany($query, Request $request)
    {
        $stringArray = explode("-", $query);
        $id = end($stringArray);
        $company = User::findOrFail($id);

        $companyOtherJobs = Job::where('user_id', $id)->latest()->take(10)->get();

        // SEO
        SEOTools::setTitle($company->company->name . " | Job Openings: " . $company->jobs->count() . " | Location: " . $company->company->city . "(" . $company->company->city . ") " . $company->company->state);
        SEOTools::setDescription($company->company->description);
        // end SEO

        return view('company-detail', compact('company', 'companyOtherJobs'));
    }

    public function about()
    {
        SEOTools::setTitle('About ' . env('APP_NAME'));
        SEOTools::setDescription("This page contain information about " . env('APP_NAME'));
        return  view('about');
    }
    public function policy()
    {
        SEOTools::setTitle('Privacy Policy For ' . env('APP_NAME'));
        SEOTools::setDescription("Privacy Policy For the " . env('APP_NAME'));
        return  view('policy');
    }
    public function training()
    {
        SEOTools::setTitle('Training ' . env('APP_NAME'));
        SEOTools::setDescription("Training " . env('APP_NAME'));
        SEOTools::setTitle('Training ' . env('APP_NAME'));
        return  view('training');
    }
    public function team()
    {
        SEOTools::setTitle('Team Work ' . env('APP_NAME'));
        SEOTools::setDescription("Team Work " . env('APP_NAME'));
        SEOTools::setTitle('Team ' . env('APP_NAME'));
        return  view('team');
    }
}
