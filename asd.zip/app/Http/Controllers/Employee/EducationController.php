<?php

namespace App\Http\Controllers\Employee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Education;
use App\University;
use App\Http\Requests\Employee\StoreEducationRequest;
use Artesaos\SEOTools\Facades\SEOTools;

class EducationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        SEOTools::setTitle('Education');
        $educations = Education::with('university')->where('user_id', auth()->user()->id)->orderBy('year', 'desc')->get();
        return view('employee.education', ['educations' => $educations]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreEducationRequest $request)
    {
        if ($request->university_id == 0) {
            $university = new University;
            $university->name = $request->institute;
            $university->save();
        }
        $education = new Education;
        $education->title = $request->title;
        $education->user_id = auth()->user()->id;
        $education->year = $request->year;
        $education->university_id = ($request->university_id == '0' ? $university->id : $request->university_id);
        $education->score = $request->score;
        $education->save();
        return redirect()->back()->with('success', 'Education is added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $education = Education::with('university')->find($id);
        return $education->LoadMissing(['university']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(StoreEducationRequest $request, $id)
    {
        if ($request->university_id == 0) {
            $university = new University;
            $university->name = $request->institute;
            $university->save();
        }
        $education = Education::find($id)->first();
        $education->title = $request->title;
        $education->year = $request->year;
        $education->university_id = ($request->university_id == '0' ? $university->id : $request->university_id);
        $education->score = $request->score;
        $education->save();
        return redirect()->back()->with('success', 'Education is updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Education::find($id)->delete();
        return redirect()->back()->with('success', 'Education is deleted');
    }
}
