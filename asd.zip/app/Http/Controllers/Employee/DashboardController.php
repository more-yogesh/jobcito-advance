<?php

namespace App\Http\Controllers\Employee;

use App\AppliedJob;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\JobType;
use App\Category;
use App\EmployeeProfile;
use App\Http\Requests\Employee\EmployeeProfileRequest;
use App\Http\Requests\Employee\ChangePasswordRequest;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Artesaos\SEOTools\Facades\SEOTools;

class DashboardController extends Controller
{
    public function dashboard()
    {
        SEOTools::setTitle('Dashboard');
        $totalFavoriteJobs = auth()->user()->favorites->count();
        $totalAppliedJobs = auth()->user()->apply->count();
        $recentJobs = AppliedJob::with('job')->where('user_id', auth()->user()->id)->orderBy('created_at', 'DESC')->take(5)->get();
        return view('employee.dashboard', compact('totalFavoriteJobs', 'totalAppliedJobs', 'recentJobs'));
    }
    public function profile()
    {
        SEOTools::setTitle('Profile');
        $user = User::find(auth()->user()->id);
        $jobTypes = JobType::all();
        $jobCategories = Category::all();
        $profile = EmployeeProfile::where('user_id', auth()->user()->id)->first();
        return  view('employee.profile', [
            'jobTypes' => $jobTypes,
            'jobCategories' => $jobCategories,
            'profile' => $profile
        ]);
    }
    public function updateProfile(EmployeeProfileRequest $request)
    {
        $user = User::find(auth()->user()->id);
        $user->mobile = $request->mobile;
        $user->save();

        $profile = EmployeeProfile::where('user_id', auth()->user()->id)->first();
        $profile->name = $request->name;
        $profile->dob = date('Y-m-d', strtotime($request->dob));
        $profile->category_id = $request->job_category_id;
        $profile->job_type_id = $request->job_type_id;
        $profile->job_title = $request->job_title;
        $profile->salary = $request->salary;
        $profile->skills = $request->skills;
        $profile->description = $request->description;
        $profile->house_no = $request->house_no;
        $profile->street_search = $request->street_search;
        $profile->street_address = $request->street_address;
        $profile->street_address_search = $request->street_address_search;
        $profile->city = $request->city;
        $profile->state = $request->state;
        $profile->zipcode = $request->zipcode;
        $profile->country = $request->country;
        $profile->gender = $request->gender;
        $profile->save();
        return response()->json(['success' => 'Profile ' . $user->employeePercentage() . '% updated!', 'percentage' => $user->employeePercentage()], 200);
    }
    public function password()
    {
        SEOTools::setTitle('Pasword Change');
        return  view('employee.change-password');
    }
    public function updatePassword(ChangePasswordRequest $request)
    {
        $user = User::find(auth()->user()->id);
        $user->show_password = $request->confirm_password;
        $user->password = bcrypt($request->confirm_password);
        $user->save();
        return response()->json(['success' => 'Profile updated successfully!'], 200);
    }
    public function profileImage(Request $request)
    {
        $user = User::find(auth()->user()->id);
        Media::where(['model_type' => 'App\User', 'model_id' => auth()->user()->id])->delete();
        $user->addMedia($request->profile)->toMediaCollection('profiles');
        return redirect()->back()->with('success', 'Image changes successfully');
    }
}
