<?php

namespace App\Http\Controllers;

use App\EmployeeProfile;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BackupController extends Controller
{
    public function index()
    {
        $users = DB::table('users_old')->get();
        foreach ($users as $user) {
            $profile = DB::table('employee_profiles_old')->where('user_id', $user->id)->first();
            if ($profile) {
                $password = $this->userPassword();
                $user =  User::create([
                    'email' => $user->email,
                    'password' => bcrypt($password),
                    'show_password' => $password,
                    'mobile' => $profile->contact ?? $password
                ]);
                $employee = new EmployeeProfile();
                $employee->user_id = $user->id;
                $employee->name = $profile->name;
                $employee->job_title = $profile->title;
                $employee->dob = $profile->dob;
                $employee->description = $profile->overview;
                $employee->salary = $profile->expected_salary ?? 0;
                $employee->save();
                $user->assignRole('employee');
            }
        }
    }
}
