<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;
use Artesaos\SEOTools\Facades\SEOTools;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function showLoginForm()
    {
        SEOTools::setTitle('Login');
        SEOTools::setDescription('jobcito login for jobseeker and company');
        return view('auth.login');
    }

    protected function validateLogin(Request $request)
    {
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);
    }

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function username()
    {
        $login = request()->input('username');

        if (is_numeric($login)) {
            $field = 'mobile';
        } else {
            $field = 'email';
        }
        request()->merge([$field => $login]);
        return $field;
    }

    protected function attemptLogin(Request $request)
    {
        return $this->guard()->attempt(
            $this->credentials($request),
            $request->filled('remember')
        );
    }

    protected function sendFailedLoginResponse(Request $request)
    {
        throw ValidationException::withMessages([
            'username' => [trans('auth.failed')],
        ]);
    }

    protected function sendLoginResponse(Request $request)
    {
        $request->session()->regenerate();

        $this->clearLoginAttempts($request);

        if ($response = $this->authenticated($request, $this->guard()->user())) {
            return $response;
        }

        if (auth()->user()->hasRole('employee')) {
            return response()->json(['redirect' => route("dashboard")], 200);
        } else if (auth()->user()->hasRole('company')) {
            return response()->json(['redirect' => route("company.dashboard")], 200);
        } else if (auth()->user()->hasRole('admin')) {
            return response()->json(['redirect' => route("admin.dashboard")], 200);
        }
    }

    protected function credentials(Request $request)
    {
        return $request->only($this->username(), 'password');
    }
}
