<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\User;
use App\EmployeeProfile;
use App\CompanyProfile;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Artesaos\SEOTools\Facades\SEOTools;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    public const HOME = '/home';

    public function showRegistrationForm()
    {
        SEOTools::setTitle('Register');
        SEOTools::setDescription('Registration for employee|jobseeker it\'s free!');
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $this->validator($request->all())->validate();

        event(new Registered($user = $this->create($request->all())));

        $this->guard()->login($user);

        if ($response = $this->registered($request, $user)) {
            return $response;
        }
        if (auth()->user()->hasRole('employee')) {
            return response()->json(['redirect' => route("profile")], 200);
        } else {
            return response()->json(['redirect' => route("company.profile")], 200);
        }
    }
    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'role' => ['required'],
            'type' => ['required', 'string', 'max:255'],
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'mobile' => ['required', 'numeric', 'digits:10', 'unique:users'],
            'password' => ['required','min:6', 'max:20'],
            'confirm_password' => ['required','same:password'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        $user =  User::create([
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'show_password' => $data['password'],
            'mobile' => $data['mobile']
        ]);

        if ($data['role'] == 'company') {
            return $this->addCompany($user, $data);
        }
        return $this->addEmployee($user, $data);
    }

    public function addEmployee($user, $data)
    {
        $profile = new EmployeeProfile();
        $profile->user_id = $user->id;
        $profile->name = $data['name'];
        $profile->save();
        $user->assignRole('employee');
        return $user;
    }
    public function addCompany($user, $data)
    {
        $profile = new CompanyProfile();
        $profile->user_id = $user->id;
        $profile->name = $data['name'];
        $profile->save();
        $user->assignRole('company');
        return $user;
    }
}
