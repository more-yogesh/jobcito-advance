<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Artesaos\SEOTools\Facades\SEOTools;

class NotificationController extends Controller
{
    public function index()
    {
        return auth()->user()->unreadNotifications()->paginate(10);
    }

    public function markNotificationAsRead(Request $request)
    {
        if ($request->requestType == 'all') {
            $notifications = auth()->user()->unreadNotifications()->where('notifiable_id', auth()->user()->id)->get();
            $notifications->markAsRead();
        } else {
            $notifications = auth()->user()->unreadNotifications()->find($request->id);
            if ($notifications) {
                $notifications->markAsRead();
            }
        }

        return response()->json(['success' => 'marked as read'], '200');
    }

    public function allNotifications()
    {
        SEOTools::setTitle('Notifications');
        $notifications = auth()->user()->unreadNotifications()->paginate(5);
        return view('notifications', compact('notifications'));
    }
}
