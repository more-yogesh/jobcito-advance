<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Services\PayPalService;
use Illuminate\Http\Request;
use App\Resolvers\PaymentPlatformResolver;

class PaymentController extends Controller
{
    protected $paymentPlatformResolver;
    public function __construct(PaymentPlatformResolver $paymentPlatformResolver)
    {
        $this->middleware('auth');
        $this->paymentPlatformResolver = $paymentPlatformResolver;
    }
    public function pay(Request $request)
    {
        $rules = [
            'value' => ['required', 'min:5', 'numeric'],
            'currency' => ['required', 'exists:currencies,iso'],
            'payment_platform' => ['required', 'exists:payment_platforms,id']
        ];
        dd($request->all());
        $request->validate($rules);

        $paymentPlatform = $this->paymentPlatformResolver->resolveService($request->payment_platform);

        session()->put('paymentPlatformId', $request->payment_platform);

        return $paymentPlatform->handlePayment($request);
    }

    public function approval()
    {
        if (session()->has('paymentPlatformId')) {
            $paymentPlatform = resolve(PayPalService::class);
            return $paymentPlatform->handleApproval();
        }
        return redirect()->route('jobs.show', 1)->withErrors('You cancelled the payment sorry plese try again!');
    }
    public function cancelled()
    {
        return redirect()->route('jobs.show', 1)->withErrors('You cancelled the payment sorry plese try again!');
    }
}
