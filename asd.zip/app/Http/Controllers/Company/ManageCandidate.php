<?php

namespace App\Http\Controllers\Company;

use App\AppliedJob;
use App\Http\Controllers\Controller;
use App\Job;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use PDF;

class ManageCandidate extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $jobIds = Job::select('id')->where('user_id', auth()->user()->id)->get()->flatten(2);
        $shortlisted = AppliedJob::with(['job', 'user'])->whereIn('job_id', $jobIds)->where('status', 'shortlisted')->distinct()->get(['user_id']);
        return view('company.manage-candidates', compact('shortlisted'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $application = AppliedJob::where('user_id', $request->candidateId)->where('job_id', $request->jobId)->first();
        if ($request->type == 'rejected') {
            $application->status = 'rejected';
            $application->save();
        } else {
            $application->status = 'shortlisted';
            $application->save();
            $user = User::find($request->candidateId);
            $job = Job::find($request->jobId);
            $this->shorlistedNotification($user, $job);
        }

        return response()->json(['success' => 'Mail sent to candidate.'], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $string = Crypt::decryptString($id);
        $data = explode("***", $string);
        $jobId = $data[0];
        $candidateId = $data[1];
        $user = User::find($candidateId);
        $application = AppliedJob::where('user_id', $candidateId)->where('job_id', $jobId)->first();
        $application->status = 'viewed';
        $application->save();
        return view('company.resume', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $job = Job::with(['applications'])->find($id);
        return view('company.candidates', compact('job'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
