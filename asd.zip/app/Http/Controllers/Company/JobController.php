<?php

namespace App\Http\Controllers\Company;

use App\Category;
use App\CompanyProfile;
use App\ContractType;
use App\Currency;
use App\Http\Controllers\Controller;
use App\Http\Requests\Company\StoreJobRequest;
use App\Http\Requests\Company\UpdateJobRequest;
use App\Job;
use App\JobType;
use App\PaymentPlatform;
use App\PaymentType;
use Illuminate\Http\Request;

class JobController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $jobs = Job::where('user_id', auth()->user()->id)->get();

        return view('company.jobs.index', [
            'jobs' => $jobs
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $profile = CompanyProfile::where('user_id', auth()->user()->id)->first();
        return view('company.jobs.create', [
            'profile' => $profile
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreJobRequest $request)
    {
        $category_id = $request->category_id;
        if ($request->category_id == 0) {
            $category = Category::creat([
                'name' => '',
                'description' => "Created By (ID: " .  auth()->user()->id . ")" . auth()->user()->company->name,
            ]);
            $category_id = $category->id;
        }

        $jobData = $request->validated() + [
            'user_id' => auth()->user()->id,
            'status' => 'pending',
            'category_id' => $category_id
        ];
        $job = Job::create($jobData);
        $data = ['id' => $job->id];
        return response()->json($data, 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $currencies = Currency::all();
        $paymentPlatforms = PaymentPlatform::all();
        return view('company.jobs.show', [
            'currencies' => $currencies,
            'paymentPlatforms' => $paymentPlatforms
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Job $job)
    {
        $jobTypes = JobType::all();
        $contractTypes = ContractType::all();
        $paymentTypes = PaymentType::all();
        $profile = CompanyProfile::where('user_id', auth()->user()->id)->first();
        return view('company.jobs.edit', [
            'profile' => $profile,
            'job' => $job,
            'jobTypes' => $jobTypes,
            'contractTypes' => $contractTypes,
            'paymentTypes' => $paymentTypes
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateJobRequest $request, $id)
    {

        $job = Job::find($id);
        $job->title = $request->title;
        $job->description = $request->description;
        $job->state = $request->state;
        $job->city = $request->city;
        $job->zipcode = $request->zipcode;
        $job->job_type_id = $request->job_type;
        $job->salary_from = $request->salary_from;
        $job->salary_to = $request->salary_to;
        $job->payment_type_id = $request->payment_type;
        $job->positions = $request->positions;
        $job->status = $request->status;
        $job->save();

        $job->contractTypes()->sync($request->contract_type);
        return response()->json([
            'success' => 'job updated'
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Job $job)
    {
        $job->delete();
        return redirect()->back()->with('status', 'Job Deleted Successfully');
    }
}
