<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Company\CompanyProfileRequest;
use App\Http\Requests\Company\ChangePasswordRequest;
use App\JobType;
use App\CompanyProfile;
use App\Category;
use App\Job;
use App\User;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Artesaos\SEOTools\Facades\SEOTools;

class DashboardController extends Controller
{
    public function dashboard()
    {
        SEOTools::setTitle('Dashboard');
        $id = auth()->user()->id;
        $totalJobs = Job::where('user_id', $id)->count();
        $totalActiveJobs = Job::where(['user_id' =>  $id, 'status' => 'active'])->count();
        $totalPendingJobs = Job::where('user_id', $id)->where('status', 'pending')->OrWhere('status', 'confirm')->count();
        $recentJobs = Job::with(['contractTypes', 'jobType'])->where('user_id', $id)->latest()->take(5)->get();
        return view('company.dashboard', compact('totalJobs', 'totalActiveJobs', 'totalPendingJobs', 'recentJobs'));
    }
    public function profile()
    {
        SEOTools::setTitle('Profile');
        $jobTypes = JobType::all();
        $jobCategories = Category::all();
        $profile = CompanyProfile::where('user_id', auth()->user()->id)->first();
        return  view('company.profile', [
            'jobTypes' => $jobTypes,
            'jobCategories' => $jobCategories,
            'profile' => $profile
        ]);
    }
    public function updateProfile(CompanyProfileRequest $request)
    {
        $user = User::find(auth()->user()->id);
        $user->mobile = $request->mobile;
        $user->save();

        $profile = CompanyProfile::where('user_id', auth()->user()->id)->first();
        $profile->name = $request->name;
        $profile->date_found = date('Y-m-d', strtotime($request->date_found));
        $profile->description = $request->description;
        $profile->contact_person_name = $request->contact_person_name;
        $profile->house_no = $request->house_no;
        $profile->street_search = $request->street_search;
        $profile->street_address = $request->street_address;
        $profile->street_address_search = $request->street_address_search;
        $profile->city = $request->city;
        $profile->state = $request->state;
        $profile->zipcode = $request->zipcode;
        $profile->country = $request->country;
        $profile->save();
        return redirect()->back()->with('success', 'Company updated successfully!');
    }
    public function password()
    {
        SEOTools::setTitle('Change Password');
        return  view('company.change-password');
    }
    public function updatePassword(ChangePasswordRequest $request)
    {
        $user = User::find(auth()->user()->id);
        $user->show_password = $request->confirm_password;
        $user->password = bcrypt($request->confirm_password);
        $user->save();
        return redirect()->back()->with('success', 'Password updated successfully!');
    }
    public function profileImage(Request $request)
    {
        $user = User::find(auth()->user()->id);
        Media::where(['model_type' => 'App\User', 'model_id' => auth()->user()->id])->delete();
        $user->addMedia($request->profile)->toMediaCollection('profiles');
        return redirect()->back()->with('success', 'Image change successfully');
    }
}
