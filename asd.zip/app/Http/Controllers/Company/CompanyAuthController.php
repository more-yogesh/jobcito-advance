<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Artesaos\SEOTools\Facades\SEOTools;

class CompanyAuthController extends Controller
{
    public function __construct()
    {
        $this->middleware('guest');
    }
    public function register()
    {
        SEOTools::setTitle('Registration for Recruiter | Company | Employer');
        SEOTools::setDescription('Registration for Company | Employer | Recruiter it\'s free!');
        return  view('auth.register');
    }
}
