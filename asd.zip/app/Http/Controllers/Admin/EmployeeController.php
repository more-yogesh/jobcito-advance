<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use DataTables;
use Artesaos\SEOTools\Facades\SEOTools;
use Illuminate\Support\Facades\Crypt;
use App\Category;
use App\JobType;
use App\EmployeeProfile;
use Validator;
use App\File;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        SEOTools::setTitle('Employees');
        return view('admin.employee.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $candidateId = Crypt::decryptString($id);
        $user = User::find($candidateId);
        return view('admin.employee.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        SEOTools::setTitle('Edit Employee');
        $user = User::find($id);
        $jobCategories = Category::all();
        $jobTypes = JobType::all();
        return view('admin.employee.edit', compact('user', 'jobCategories', 'jobTypes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {   
        $user = User::find($id)->first();
        $user->mobile = $request->mobile;
        $user->save();

        $profile = EmployeeProfile::where('user_id', $id)->first();
        $profile->name = $request->name;
        $profile->dob = date('Y-m-d', strtotime($request->dob));
        $profile->category_id = $request->job_category_id;
        $profile->job_type_id = $request->job_type_id;
        $profile->job_title = $request->job_title;
        $profile->salary = $request->salary;
        $profile->skills = $request->skills;
        $profile->description = $request->description;
        $profile->house_no = $request->house_no;
        $profile->street_search = $request->street_search;
        $profile->street_address = $request->street_address;
        $profile->street_address_search = $request->street_address_search;
        $profile->city = $request->city;
        $profile->state = $request->state;
        $profile->zipcode = $request->zipcode;
        $profile->country = $request->country;
        $profile->gender = $request->gender;
        $profile->save();
        return response()->json(['success' => 'Profile  updated!'], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        User::where('id', $id)->delete();
        return redirect()->back()->with('status', 'Record Deleted Successfully');
    }
    public function resume()
    {
        return view('admin.employee.file');
    }
    public function datatable()
    {
        $users = User::with(['employee'])->role('employee')->orderBy('users.id', 'DESC')->newQuery();
        return DataTables::of($users)
            ->addIndexColumn()
            ->addColumn('action', function ($users) {
                $actions = '
                <div class="d-inline-block float-left">
                        <form class="float-left ml-1" method="POST" action="' . route('employee.destroy', $users->id) . '" onsubmit="return confirm(\'Do you really want to submit the form?\');">
                           <input type="hidden" name="_token" value="' . csrf_token() . '">
                           <input type="hidden" name="_method" value="DELETE">   
                           <button type="submit" class="edit btn btn-danger btn-sm p-1">
                            <i class="fas fa-fw fa-trash-alt"></i>
                           </button>
                        </form>
                        <a href="'.route('employee.edit', $users->id).'" class="btn btn-success btn-sm p-1 ml-2"><i class="fas fa-fw fa-edit"></i></a>
                        <a href="'.route('employee.show', Crypt::encryptString($users->id)).'" target="_blank" class="btn btn-primary btn-sm p-1"><i class="fas fa-fw fa-eye"></i></a>
                         <a href="' . route('employee.file', $users->id) . '" class="btn btn-success btn-sm p-1 ml-2"><i class="fa fa-file" aria-hidden="true"></i></i></a>
                        </div>
                            ';
                return $actions;
            })
            ->editColumn('created_at', function ($users) {
                return $users->created_at->format('d-m-Y');
            })
            ->editColumn('name', function ($users) {
                return $users->employee->name ?? 'N/A';
            })
            ->editColumn('city', function ($users) {
                return $users->employee->city ?? 'N/A';
            })
            ->editColumn('job_title', function ($users) {
                return $users->employee->job_title ?? 'N/A';
            })
            ->rawColumns(['action', 'duration'])
            ->make(true);
    }
     public function action(Request $request)
    {
        
        //
        $validation = Validator::make($request->all(), [
            'select_file' => 'required|max:2048'
        ]);
        if ($validation->passes()) {


            $user = User::find(request("id"))->first();

            if ($request->hasFile('select_file')) {
                $user->addMedia($request->select_file)->toMediaCollection('resume');
            }
            return response()->json([
                'status' => 'success',
                'message'   => 'Resume upload sucessfully',
            ], 200);
        } else {
            return response()->json([
                'message'   => $validation->errors()->all(),
                'uploaded_image' => '',
                'class_name'  => 'alert-danger'
            ]);
        }
    }
}
