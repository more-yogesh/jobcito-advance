<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Contact;
use DataTables;
use Artesaos\SEOTools\Facades\SEOTools;

class ContactController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        SEOTools::setTitle('Contact Requests');
        return view('admin.contact.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    public function directApply()
    {
        SEOTools::setTitle('Direct Apply');
        return view('admin.contact.direct-apply');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Contact $contact)
    {
        $contact->delete();
        return redirect()->back()->with('status', 'Record Deleted Successfully');
    }
    public function datatable()
    {
        $contacts = Contact::where('job_id', NULL)->orderBy('created_at', 'DESC')->newQuery();
        return DataTables::of($contacts)
            ->addIndexColumn()
            ->addColumn('action', function ($contacts) {
                $actions = '
                <div class="d-inline-block float-left">
                        <form class="float-left ml-1" method="POST" action="' . route('contacts.destroy', $contacts->id) . '" onsubmit="return confirm(\'Do you really want to submit the form?\');">
                           <input type="hidden" name="_token" value="' . csrf_token() . '">
                           <input type="hidden" name="_method" value="DELETE">   
                           <button type="submit" class="edit btn btn-danger btn-sm">
                            <i class="fas fa-fw fa-trash-alt"></i>
                           </button>
                        </form>
                        </div>
                            ';
                return $actions;
            })
            ->editColumn('created_at', function ($contacts) {
                return $contacts->created_at->format('d-m-Y');
            })
            ->rawColumns(['action', 'duration'])
            ->make(true);
    }
    public function directDatatable(){
        $contacts = Contact::with('job')->where('job_id','<>', NULL)->newQuery();
        return DataTables::of($contacts)
            ->addIndexColumn()
            ->addColumn('action', function ($contacts) {
                $actions = '
                <div class="d-inline-block float-left">
                        <form class="float-left ml-1" method="POST" action="' . route('contacts.destroy', $contacts->id) . '" onsubmit="return confirm(\'Do you really want to submit the form?\');">
                           <input type="hidden" name="_token" value="' . csrf_token() . '">
                           <input type="hidden" name="_method" value="DELETE">   
                           <button type="submit" class="edit btn btn-danger btn-sm">
                            <i class="fas fa-fw fa-trash-alt"></i>
                           </button>
                        </form>
                        </div>';
                return $actions;
            })
            ->editColumn('job_title', function ($contacts) {
                return $contacts->job->job_title;
            })
            ->editColumn('created_at', function ($contacts) {
                return $contacts->created_at->format('d-m-Y');
            })
            ->rawColumns(['action', 'duration'])
            ->make(true);
    }
}
