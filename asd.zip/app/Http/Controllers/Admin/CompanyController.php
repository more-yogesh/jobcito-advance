<?php

namespace App\Http\Controllers\Admin;

use App\CompanyProfile;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Admin\UpdateCompanyRequest;
use App\User;
use DataTables;
use Artesaos\SEOTools\Facades\SEOTools;
use App\EmployeeProfile;


class CompanyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        SEOTools::setTitle('Companies');
        return view('admin.company.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        SEOTools::setTitle('Edit company');
        $profile = CompanyProfile::where('user_id',$id)->first();
        //$jobCategories = Category::all();
        //$jobTypes = JobType::all();
        return view('admin.company.edit', compact('profile'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateCompanyRequest $request, $id)
    {
        
     
        $profile = CompanyProfile::where('user_id',$id)->first();
       $profile->name = $request->name;
        $profile->date_found = date('Y-m-d', strtotime($request->date_found));
        $profile->description = $request->description;
       $profile->contact_person_name = $request->contact_person_name;
       $profile->house_no = $request->house_no;
       $profile->street_search = $request->street_search;
       $profile->street_address = $request->street_address;
       $profile->street_address_search = $request->street_address_search;
       $profile->city = $request->city;
       $profile->state = $request->state;
       $profile->website = $request->website;
       $profile->zipcode = $request->zipcode;
       $profile->country = $request->country;
       $profile->save();
        

        return response()->json(['success' => 'Profile  updated!'], 200);
      
    }    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function datatable()
    {
        $users = User::with(['company'])->role('company')->newQuery();
        return DataTables::of($users)
        ->addIndexColumn()
        ->addColumn('action', function ($users) {
            $actions = '
            <div class="d-inline-block float-left">
                    <form class="float-left ml-1" method="POST" action="' . route('company.destroy', $users->id) . '" onsubmit="return confirm(\'Do you really want to submit the form?\');">
                       <input type="hidden" name="_token" value="' . csrf_token() . '">
                       
                       
                       </button>
                    </form>
                    <a href="' . route('company.edit', $users->id) . '" class="edit btn btn-info btn-sm ml-1"> <i class="fas fa-fw fa-edit"></i></a>
            </div>';
            return $actions;
        
            })
            ->editColumn('city', function ($users) {
                return $users->company->city ?? 'N/A';
            })
            ->editColumn('created_at', function ($users) {
                return $users->created_at->format('d-m-Y');
            })
            ->rawColumns(['action', 'duration'])
            ->make(true);
    }
}
