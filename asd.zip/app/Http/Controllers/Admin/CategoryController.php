<?php

namespace App\Http\Controllers\Admin;

use App\Category;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreCategoryRequest;
use App\Http\Requests\Admin\UpdateCategoryRequest;
use Illuminate\Http\Request;
use Artesaos\SEOTools\Facades\SEOTools;

use DataTables;


class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = $request->term;
        //return Category::select('name as label', 'id')->where('name', 'like', "%$query%")->skip(0)->take(10)->get();
        return view('admin.categories.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('admin.categories.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCategoryRequest $request ,Category $categories)
    {
        $categories = new Category();
        $categories->name = $request->name;
        $categories->description = $request->description;
        $categories->status = $request->status;
        $categories->save();
        return response()->json(['success' => 'categories added successfully']);      
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        SEOTools::setTitle('Edit categories');
        $categories = Category::find($id);
        //$jobCategories = Category::all();
        //$jobTypes = JobType::all();
        return view('admin.categories.edit', compact('categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateCategoryRequest $request ,Category $categories)
    {
        
        $categories->name = $request->name;
        $categories->description = $categories->description . "<br/>" . $request->description;
       
        $categories->status = $request->status;
        
        $categories->save();
        return view('admin.categories.edit', compact('categories'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Category $categories)
    {
        //
        $categories->delete();
        return redirect()->back()->with('status', 'Record Deleted Successfully');
    }
    public function datatable()
    {
            
        $categories = Category::select(['*']);
        return DataTables::of($categories)
            ->addIndexColumn()
            ->addColumn('action', function ($categories) {
                $actions = '
                <div class="d-inline-block float-left">
                        <form class="float-left ml-1" method="POST" action="' . route('categories.destroy', $categories->id) . '" onsubmit="return confirm(\'Do you really want to submit the form?\');">
                           <input type="hidden" name="_token" value="' . csrf_token() . '">
                           <input type="hidden" name="_method" value="DELETE">   
                           <button type="submit" class="edit btn btn-danger btn-sm">
                           <i class="fa fa-trash"></i>
                           
                           </button>
                        </form>
                        <a href="' . route('categories.edit', $categories->id) . '" class="edit btn btn-info btn-sm ml-1"> <i class="fas fa-fw fa-edit"></i></a>
                </div>';
                return $actions;
            })
            ->editColumn('created_at', function ($categories) {
                // return $inquiries->created_at->format('d-m-Y');
            })
            ->rawColumns(['action'])
            ->make(true);
    }
}

