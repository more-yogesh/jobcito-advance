<?php

namespace App\Http\Controllers\Admin;
use App\EmployeeProfile;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UpdateJobinquiryRequest;
use App\Http\Requests\Admin\StoreJobinquiryRequest;
use Illuminate\Http\Request;
use App\JobInquiry;
use DataTables;
use Carbon;
use Artesaos\SEOTools\Facades\SEOTools;
use Stripe\Order;

class JobinquiryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        \DB::enableQueryLog();
        $inquiry = new JobInquiry;
        $inquiry = $inquiry->Where('status', '=', request('status'));
        $inquiry = $inquiry->Where('course_name', 'LIKE', "%" . request('course_name') . "%");
        $inquiry = $inquiry->Where('name', 'LIKE', "%" . request('name') . "%");
        $inquiry = $inquiry->Where('mobile', 'LIKE', "%" . request('mobile') . "%");
        $inquiry =  $inquiry->get();
        return view('admin.jobinquiry.index', compact('inquiry'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('admin.jobinquiry.create');
       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreJobInquiryRequest $request)
    {
        //
        $inquiry = new JobInquiry();
        $inquiry->course_name = $request->course_name;
        $inquiry->name = $request->name;
        $inquiry->description = $request->description;
        $inquiry->schedule = $request->schedule;
        $inquiry->status = $request->status;
        $inquiry->mobile = $request->mobile;
        $inquiry->save();
        return response()->json(['success' => 'JobInquiry added successfully']);
    }
    
    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        SEOTools::setTitle('Edit inquiry');
        $inquiry = JobInquiry::find($id);
        //$jobCategories = Category::all();
        //$jobTypes = JobType::all();
        return view('admin.jobinquiry.edit', compact('inquiry'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateJobinquiryRequest $request, JobInquiry $inquiry)
    {
        //
        $inquiry->course_name = $request->course_name;
        $inquiry->name = $request->name;
        $inquiry->description = $inquiry->description . "<br/>" . $request->description;
        $inquiry->schedule = $request->schedule;
        $inquiry->status = $request->status;
        $inquiry->mobile = $request->mobile;
        $inquiry->save();
        return view('admin.jobinquiry.edit', compact('inquiry'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(JobInquiry $jobinquiry)
    {
        //
        $jobinquiry->delete();
        return redirect()->back()->with('status', 'Record Deleted Successfully');
    }
    public function datatable()
    {



        $jobinquiries = JobInquiry::select(['*']);
        return DataTables::of($jobinquiries)
            ->addIndexColumn()

            ->editColumn('created_at', function ($jobinquiries) {
                // return $inquiries->created_at->format('d-m-Y');
            })
            ->rawColumns(['action'])
            ->make(true);
    }
    public function sendMessage(Request $request)
    {
        foreach ($request->id as $user) {
            $inquiry = JobInquiry::find($user)->first();
            $this->sendSMS($inquiry->mobile, $inquiry->message);

        }
        return redirect()->back()->with('status', 'SMS send Successfully!');

    }
}
