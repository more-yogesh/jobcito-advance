<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Job;
use App\User;
use App\Contact;
use Illuminate\Http\Request;
use Artesaos\SEOTools\Facades\SEOTools;
use Carbon\Carbon;
use App\Http\Requests\Company\ChangePasswordRequest;

class DashboardController extends Controller
{
    public function dashboard()
    {
        SEOTools::setTitle('Dashboard');
        $todaysTotalEmployee = User::role('employee')->whereDate('created_at', Carbon::today())->count();
        $totalCompanies = User::role('company')->count();
        $totalEmployees = User::role('employee')->count();
        $totalActiveJobs = Job::where('status', 'active')->count();
        $pendingActiveJobs = Job::where('status', 'pending')->count();
        $recentJobs = Job::with(['contractTypes', 'jobType'])->latest()->take(5)->get();
        $directApplies = Contact::where('job_id', '<>', NULL)->count();
        //$totalInquiries = Inquiry::count();
        return view('admin.dashboard', compact('totalCompanies', 'totalEmployees', 'recentJobs', 'totalActiveJobs', 'pendingActiveJobs', 'todaysTotalEmployee', 'directApplies'));
    }
    public function password()
    {
        SEOTools::setTitle('Change Password');
        return  view('admin.change-password');
    }
    public function updatePassword(ChangePasswordRequest $request)
    {
        $user = User::find(auth()->user()->id);
        $user->show_password = $request->confirm_password;
        $user->password = bcrypt($request->confirm_password);
        $user->save();
        return redirect()->back()->with('success', 'Password updated successfully!');
    }
}
