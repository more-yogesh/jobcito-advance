<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UpdateInquiryRequest;
use App\Http\Requests\Admin\StoreInquiryRequest;
use App\Inquiry;
use Illuminate\Http\Request;
use DataTables;
use Carbon;
use Artesaos\SEOTools\Facades\SEOTools;
use Stripe\Order;

class InquiryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.inquiry.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.inquiry.create');
        
       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreInquiryRequest $request)
    {
        $inquiry = new Inquiry();
        $inquiry->course_name = $request->course_name;
        $inquiry->name = $request->name;
        $inquiry->description = $request->description;
        $inquiry->schedule = $request->schedule;
        $inquiry->status = $request->status;
        $inquiry->mobile = $request->mobile;
        $inquiry->save();
        return response()->json(['success' => 'Inquiry added successfully']);      
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show( )
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        SEOTools::setTitle('Edit inquiry');
        $inquiry = Inquiry::find($id);
        //$jobCategories = Category::all();
        //$jobTypes = JobType::all();
        return view('admin.inquiry.edit', compact('inquiry'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateInquiryRequest $request, Inquiry $inquiry)
    {
        $inquiry->course_name = $request->course_name;
        $inquiry->name = $request->name;
        $inquiry->description = $inquiry->description . "<br/>" . $request->description;
        $inquiry->schedule = $request->schedule;
        $inquiry->status = $request->status;
        $inquiry->mobile = $request->mobile;
        $inquiry->save();
        return view('admin.inquiry.edit', compact('inquiry'));
    }

    /**
     * Remove the specified resosurce from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Inquiry $inquiry)
    {
        $inquiry->delete();
        return redirect()->back()->with('status', 'Record Deleted Successfully');
    }

    public function datatable()
    {
       
          

        $inquiries = Inquiry::select(['*']);
        return DataTables::of($inquiries)
            ->addIndexColumn()
            ->addColumn('action', function ($inquiries) {
                $actions = '
                <div class="d-inline-block float-left">
                        <form class="float-left ml-1" method="POST" action="' . route('inquiry.destroy', $inquiries->id) . '" onsubmit="return confirm(\'Do you really want to submit the form?\');">
                           <input type="hidden" name="_token" value="' . csrf_token() . '">
                           <input type="hidden" name="_method" value="DELETE">   
                           <button type="submit" class="edit btn btn-danger btn-sm">
                            <i class="fa fa-trash"></i>
                           </button>
                        </form>
                        <a href="' . route('inquiry.edit', $inquiries->id) . '" class="edit btn btn-info btn-sm ml-1"> <i class="fas fa-fw fa-edit"></i></a>
                </div>';
                return $actions;
            })
            ->editColumn('created_at', function ($inquiries) {
                // return $inquiries->created_at->format('d-m-Y');
            })
            ->rawColumns(['action'])
            ->make(true);
    }
}
