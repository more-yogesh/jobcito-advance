<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Notification;
use App\Notifications\CredentialsNotification;
use App\Notifications\Employee\ShortlistNotification;
use App\Notifications\Employee\ApplyJobNotification;
use App\User;
use App\Job;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function userPassword()
    {
        return "JCT" . substr(number_format(time() * rand(), 0, '', ''), 0, 4);
    }
    public function CredentialsNotification($user)
    {
        $details = [
            'greeting' => "Welcome " . $user->name,
            'body' => "Thanks for registering with " . env('APP_NAME') . ". To login please follow the link and use bellow credetials.",
            'username' => "User Name:" . $user->mobile,
            'password' => "Password:" . $user->show_password,
            'actionText' => "Click To Login",
            'thanks' => "Thank you for using " . env('APP_NAME'),
            'actionURL' => url('/login'),
            'user_id' => $user->id,
            'email' => $user->email
        ];
        Notification::send($user, new CredentialsNotification($details));
    }
    public function shorlistedNotification($user, $job)
    {
        $details = [
            'greeting' => "Hello, " . $user->employee->name,
            'body' => "You'r Doing great " . $user->employee->name . "! You have been shortlisted for the job named '" . $job->title . "' By the company '" . $job->user->company->name . "', " . $job->user->company->name . " may contact you soon for the further process. Stay connected and never miss an apportunity.",
            'actionText' => "Check Updates",
            'thanks' => "Thank you for using " . env('APP_NAME'),
            'actionURL' => route('notifications'),
            'user_id' => $user->id,
            'email' => $user->email,
            'job_title' => $job->title,
            'company_name' => $job->user->company->name,
            'name' => $user->employee->name
        ];
        $admin =  User::where('email', 'admin@jobcito.com')->first();
        Notification::send($user, new ShortlistNotification($details));
        Notification::send($admin, new ShortlistNotification($details));
    }
    public function applyJobNotification($jobId){
        $job = Job::find($jobId)->first();
        $user = auth()->user();
        $details = [
            'greeting' => "Hello, " . $user->employee->name,
            'body' => $user->employee->name . "have been applied for job named '" . $job->title . "' By the company '" . $job->user->company->name . "', " . $job->user->company->name . " may contact you soon for the further process. Stay connected and never miss an apportunity.",
            'thanks' => "Thank you for using " . env('APP_NAME'),
            'user_id' => $user->id,
            'email' => $user->email
        ];
        $admin =  User::where('email', 'admin@jobcito.com')->first();
        Notification::send($admin, new ApplyJobNotification($details));
        Notification::send($user, new ApplyJobNotification($details));
    }
    public function sendSMS($mobile, $message, $otherDeatails=[])
    {
        // dd(str_replace("*first_name*", 'hina', $request->message));
        // dd($mobile);
    }
}
