<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentType extends Model
{
    protected $fillable = ['name', 'status'];

    public function job()
    {
        return  $this->hasOne('App\Job');
    }
}
