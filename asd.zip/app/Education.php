<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\University;

class Education extends Model
{
    public function user()
    {
        return  $this->belongsTo('App\User');
    }
    public function university()
    {
        return $this->belongsTo('App\University');
    }
}
