<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
    protected $fillable = [
        'name',
        'job_id',
        'mobile',
        'email',
        'subject',
        'message',
    ];

    public function job()
    {
        return $this->belongsTo('App\Job');
    }
}
