<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'Employee\WelcomeController@index')->name('welcome');
Route::get('/search', 'Employee\WelcomeController@search')->name('search');
Route::get('/job/{query}', 'Employee\WelcomeController@showJob')->name('showJob');
Route::get('/employer/{query}', 'Employee\WelcomeController@showCopmany')->name('showCopmany');
Route::get('/recruiter', 'Company\CompanyAuthController@register')->name('recruiter');
Route::get('/about-us', 'Employee\WelcomeController@about')->name('about');
Route::get('/privacy-policy', 'Employee\WelcomeController@policy')->name('policy');
Route::get('/training', 'Employee\WelcomeController@training')->name('training');
Route::get('/team', 'Employee\WelcomeController@team')->name('team');
Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');
Route::resource('contact-us', 'Employee\ContactController');
Route::get('/team', 'Employee\WelcomeController@team')->name('team');
Route::get('/training', 'Employee\WelcomeController@training')->name('training');
Route::resource('training-inquiry', 'Employee\InquiryController');

Auth::routes(['verify' => true]);
// employee routes
Route::group(['prefix' => 'employee', 'namespace' => 'Employee', 'middleware' => ['auth', 'role:employee']], function () {
    Route::get('/home', 'HomeController@index')->name('home');
    Route::get('/dashboard', 'DashboardController@dashboard')->name('dashboard');
    Route::get('/profile', 'DashboardController@profile')->name('profile');
    Route::post('/profile', 'DashboardController@updateProfile')->name('post.profile');
    Route::post('/empolyee-image', 'DashboardController@profileImage')->name('empolyee.image');
    Route::get('/change-password', 'DashboardController@password')->name('change.password');
    Route::post('/change-password', 'DashboardController@updatePassword')->name('post.change.password');
    Route::resource('education', 'EducationController');
    Route::resource('experience', 'ExperienceController');
    Route::resource('favorites', 'FavoriteController');
    Route::resource('apply-job', 'ApplyJobController');
});

// company routes
Route::group(['prefix' => 'company', 'namespace' => 'Company', 'middleware' => ['auth', 'role:company'],], function () {
    Route::get('/dashboard', 'DashboardController@dashboard')->name('company.dashboard');
    Route::get('/profile', 'DashboardController@profile')->name('company.profile');
    Route::post('/company-image', 'DashboardController@profileImage')->name('company.image');
    Route::post('/profile', 'DashboardController@updateProfile')->name('company.post.profile');
    Route::get('/change-password', 'DashboardController@password')->name('company.change.password');
    Route::post('/change-password', 'DashboardController@updatePassword')->name('company.post.change.password');
    Route::resource('jobs', 'JobController');
    Route::resource('candidates', 'ManageCandidate');
    Route::post('payments/pay', 'PaymentController@pay')->name('pay');
    Route::get('payments/approval', 'PaymentController@approval')->name('approval');
    Route::get('payments/cancelled', 'PaymentController@cancelled')->name('cancelled');
});

// company routes
Route::group(['prefix' => 'admin', 'namespace' => 'Admin', 'middleware' => ['auth', 'role:admin'],], function () {
    Route::get('/dashboard', 'DashboardController@dashboard')->name('admin.dashboard');
    Route::resource('company', 'CompanyController');
    Route::get('company-datatable', 'CompanyController@datatable')->name('company.datatable');
    Route::resource('employee', 'EmployeeController');
    Route::get('employee-datatable', 'EmployeeController@datatable')->name('employee.datatable');
    Route::get('file/{id}', 'EmployeeController@resume')->name('employee.file');
    Route::get('file-open/{id}', 'EmployeeController@open')->name('employee.open');
    Route::post('/employee/action', 'EmployeeController@action')->name('employee.action');
    Route::resource('contacts', 'ContactController');
    Route::get('direct-apply', 'ContactController@directApply')->name('contacts.direct');
    Route::get('contacts-datatable', 'ContactController@datatable')->name('contacts.datatable');
    Route::get('direct-contacts-datatable', 'ContactController@directDatatable')->name('contacts.direct.datatable');
    Route::get('/change-password', 'DashboardController@password')->name('admin.change.password');
    Route::post('/change-password', 'DashboardController@updatePassword')->name('admin.post.change.password');
    Route::get('settings', 'EmployeeController@settings')->name('settings');
    Route::resource('inquiry', 'InquiryController');
    Route::get('inquiry-datatable', 'InquiryController@datatable')->name('inquiry.datatable');
    Route::post('send-message', 'InquiryController@sendMessage')->name('send.message');
    Route::resource('jobinquiry', 'JobinquiryController');
    Route::get('jobinquiry-datatable', 'JobinquiryController@datatable')->name('jobinquiry.datatable');
    Route::resource('categories', 'CategoryController');
    Route::get('categories-datatable', 'CategoryController@datatable')->name('categories.datatable');

});


// institute gloabal request
Route::get('get-institute', 'Employee\InstituteController@index')->name('index.institute');
// institute job categories request
Route::resource('category', 'Admin\CategoryController');

Route::group(['middleware' => ['auth']], function () {
    Route::post('change-notification-status', 'NotificationController@markNotificationAsRead')->name('notificationStatus');
    Route::get('notification', 'NotificationController@allNotifications')->name('notifications');
});

// other links
Route::get('storage-create', function () {
    Artisan::call('storage:link');
});