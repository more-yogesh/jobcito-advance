<div class="header-inner bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="candidates-user-info">
                    <div class="jobber-user-info">
                        <div class="profile-avatar">
                            <form method="POST" enctype="multipart/form-data" id="profileImage" action="{{ route('empolyee.image') }}">
                                @csrf
                                @php
                                $logo = auth()->user()->getFirstMediaUrl('profiles', 'logo');
                                $existLogo = $logo;
                                if($logo == ''){
                                $logo = asset('employee.png');
                                }
                                @endphp
                                <img class="img-fluid " src="{{ $logo }}" alt="">
                                <label for="profile">
                                    <i class="fas fa-pencil-alt" id="{{ $existLogo == '' ? 'pencil' : 'userImage' }}"></i>
                                    <input type="file" name="profile" id="profile" class="d-none" onchange="document.getElementById('profileImage').submit();" accept="image/png, image/jpeg, image/jpg">
                                </label>
                            </form>
                        </div>
                        <div class="profile-avatar-info ml-4">
                            <h3 class="text-capitalize">{{ auth()->user()->employee->name }}</h3>
                        </div>
                    </div>
                </div>
            </div>
            @php
            $percentage = auth()->user()->employeePercentage();
            @endphp
            <div class="col-lg-6">
                <div class="progress">
                    <div class="progress-bar {{ $percentage == 100 ? 'bg-success' : 'bg-danger'}}" role="progressbar" style="width:{{ $percentage }}%" aria-valuenow="{{ $percentage }}" aria-valuemin="0" aria-valuemax="100">
                        <span class="progress-bar-number">{{ $percentage }}%</span>
                    </div>
                </div>
                <div class="candidates-skills">
                    <div class="candidates-skills-info">
                        <h3 class="{{ $percentage == 100 ? 'text-success' : 'text-danger'}}">{{ $percentage }}%</h3>
                        @if($percentage == 100)
                        <span class="d-block text-success">Well Done! Your profile is complete.</span>
                        @else
                        <span class="d-block">Please complete your profile!</span>
                        @endif
                    </div>
                    <div class="candidates-required-skills ml-auto mt-sm-0 mt-3">
                        <a class="btn btn-dark" href="{{ route('search') }}">Find Jobs Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="sticky-top secondary-menu-sticky-top">
                    <div class="secondary-menu">
                        <ul class="list-unstyled mb-0">
                            <li><a class="{{ Route::currentRouteNamed('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}">Dashboard</a></li>
                            <li><a class="{{ Route::currentRouteNamed('profile') ? 'active' : '' }}" href="{{ route('profile') }}">My Profile</a></li>
                            <li><a class="{{ Route::currentRouteNamed('education.index') ? 'active' : '' }}" href="{{ route('education.index') }}">Education</a></li>
                            <li><a class="{{ Route::currentRouteNamed('experience.index') ? 'active' : '' }}" href="{{ route('experience.index') }}">Experience</a></li>
                            <li><a class="{{ Route::currentRouteNamed('favorites.index') ? 'active' : '' }}" href="{{ route('favorites.index') }}">Favorite Jobs</a></li>
                            <li><a class="{{ Route::currentRouteNamed('apply-job.index') ? 'active' : '' }}" href="{{ route('apply-job.index') }}">Applied Jobs</a></li>
                            <li><a class="{{ Route::currentRouteNamed('change.password') ? 'active' : '' }}" href="{{ route('change.password') }}">Change Password</a></li>
                            <li><a class="{{ Route::currentRouteNamed('notifications') ? 'active' : '' }}" href="{{ route('notifications') }}">Notifications &nbsp;<span class="badge badge-danger"> {{ auth()->user()->unreadNotifications->count() }}</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@push('style')
<style>
    #pencil {
        -webkit-animation: rotation 3s infinite;
    }

    @-webkit-keyframes rotation {


        to {
            -webkit-transform: rotate(359deg);
        }
    }
</style>
@endpush