@extends('layouts.app')

@section('content')
@include('employee.includes.header')
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-dashboard-info-box mb-0">
                    <div class="row mb-4">
                        <div class="col-md-7 col-sm-5 d-flex align-items-center">
                            <div class="section-title-02 mb-0 ">
                                <h4 class="mb-0">Manage Favorites</h4>
                            </div>
                        </div>
                    </div>
                    <div class="user-dashboard-table">
                        <table id="example" class="table table-striped table-bordered">
                            <thead class="bg-light">
                                <tr>
                                    <th scope="col">Favorite Jobs</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($favoriteJobs as $favoriteJob)
                                <tr>
                                    <th scope="row">
                                        <div class="job-list ">
                                            <div class="job-list-logo">
                                                @php
                                                $logo = $favoriteJob->user->getFirstMediaUrl('profiles', 'logo');
                                                if($logo == ''){
                                                $logo = asset('company.png');
                                                }
                                                @endphp
                                                <img class="img-fluid" src="{{$logo}}" alt="{{ $favoriteJob->user->company->name }}">
                                            </div>
                                            <div class="job-list-details">
                                                <div class="job-list-info">
                                                    <div class="job-list-title">
                                                        <h5 class="mb-0"><a href="{{ route('showJob', $favoriteJob->jobSlug()) }}">{{$favoriteJob->title}}</a>
                                                            @if($favoriteJob->Applied())
                                                            <small>
                                                                <span class="badge badge-secondary text-white p-1" style="font-weight: normal;"><i class="fa fa-check"></i> Applied</span>
                                                            </small>
                                                            @endif
                                                        </h5>
                                                    </div>
                                                    <div class="job-list-option">
                                                        <ul class="list-unstyled">
                                                            <li> <span>via</span> <a href="{{ route('showCopmany', $favoriteJob->companySlug()) }}">{{ $favoriteJob->user->company->name }}</a> </li>
                                                            <li><i class="fas fa-map-marker-alt pr-1"></i>{{ $favoriteJob->user->company->city }}, {{ $favoriteJob->user->company->state }}</li>
                                                            <li><i class="fas fa-filter pr-1"></i>{{ $favoriteJob->category->name }}</li>
                                                            <li><a class="freelance text-capitalize" href="#"><i class="fas fa-suitcase pr-1"></i>{{ $favoriteJob->jobType->name }}</a></li>
                                                        </ul>
                                                    </div>
                                                    <div class="job-list-option">
                                                        <div class="job-list-title text-dark">
                                                            @if($favoriteJob->salary_from)
                                                            ₹ {{ number_format($favoriteJob->salary_from) }} <i> - </i> ₹ {{ number_format($favoriteJob->salary_to) ?? ''}}
                                                            @else
                                                            Not Spacified
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="job-list-favourite-time" id="favoriteArea-{{$favoriteJob->id}}">
                                                @role('employee')
                                                @if($favoriteJob->favorited())
                                                <a class="job-list-favourite order-2" href="javascript:void(0)" onclick="removeFavourite({{$favoriteJob->id}})"><i class="fa fa-heart text-danger" id="favorite-{{$favoriteJob->id}}"></i></a>
                                                @else
                                                <a class="job-list-favourite order-2" href="javascript:void(0)" onclick="addFavourite({{$favoriteJob->id}})"><i class="far fa-heart" id="favorite-{{$favoriteJob->id}}"></i></a>
                                                @endif
                                                @endrole
                                                @guest
                                                <a class="job-list-favourite order-2" href="javascript:void(0)" data-toggle="modal" data-target="#loginModalCenter"><i class="far fa-heart"></i></a>
                                                @endguest
                                                <span class="job-list-time order-1">
                                                    <i class="far fa-clock pr-1"></i>{{$favoriteJob->created_at->diffForHumans()}}</span>
                                            </div>
                                        </div>
                                    </th>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
@section('css-css-hooks')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" />
@endsection

@push('style')
<style>
    .dataTables_filter {
        float: right !important;
    }
</style>
@endpush

@section('custom-scripts')
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });

    function confirmDelete() {
        if (confirm('Are you sure you want to delete this post?')) {
            return true;
        }
        return false;
    }
</script>
@endsection