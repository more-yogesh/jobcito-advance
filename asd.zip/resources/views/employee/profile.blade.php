@extends('layouts.app')

@section('content')
@include('employee.includes.header')
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form method="POST" id="profileForm">
                    @csrf
                    <div class="user-dashboard-info-box">
                        <div class="section-title-02 mb-2">
                            <h4>Basic Information</h4>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>Your Name</label>
                                <input type="text" class="form-control" value="{{ auth()->user()->employee->name }}" name="name">
                            </div>
                            <div class="form-group col-md-6">
                                <label>Email</label>
                                <input type="email" class="form-control" value="{{ auth()->user()->email }}" readonly>
                            </div>
                            <div class="form-group col-md-6 datetimepickers">
                                <label>Date of birth</label>
                                <div class="input-group date" id="datetimepicker-01" data-target-input="nearest">
                                    <input type="text" class="form-control datetimepicker-input" value="{{ ($profile->dob == '') ? '31-12-1995' : date('d-m-Y', strtotime($profile->dob)) }}" data-target="#datetimepicker-01" name="dob">
                                    <div class="input-group-append" data-target="#datetimepicker-01" data-toggle="datetimepicker">
                                        <div class="input-group-text"><i class="far fa-calendar-alt"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Phone</label>
                                <input type="number" class="form-control" value="{{ auth()->user()->mobile }}" name="mobile">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="gender">Gender</label>
                                <select class="form-control" name="gender" id="gender">
                                    <option value="">Select Gender</option>
                                    <option value="male" {{ $profile->gender == 'male' ? 'selected' : '' }}>Male</option>
                                    <option value="female" {{ $profile->gender == 'female' ? 'checked' : '' }}>Female</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Job Title(Title that explain your Job Profile)</label>
                                <input type="text" class="form-control" value="{{ $profile->job_title }}" name="job_title" placeholder="E.g. Store Manager, Software Developer, etc.">
                            </div>
                            <div class="form-group col-md-6 select-border">
                                <label>Your Profession</label>
                                <select class="form-control basic-select" name="job_category_id">
                                    @foreach($jobCategories as $category)
                                    <option value="{{ $category->id }}" {{ $profile->category_id == $category->id ? 'selected' : ''  }}>{{ $category->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6 select-border">
                                <label>Job Type</label>
                                <select class="form-control basic-select" name="job_type_id">
                                    @foreach($jobTypes as $jobType)
                                    <option value="{{ $jobType->id }}" {{ $profile->job_type_id == $jobType->id ? 'selected' : ''  }}>{{ $jobType->name }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="form-group col-md-6">
                                <label>Expected Salary Per Month</label>
                                <input type="text" class="form-control" placeholder="Amount In Rupees" name="salary" value="{{ $profile->salary ?? 0 }}">
                            </div>
                            <div class="form-group mb-0 col-md-12">
                                <label>Description</label>
                                <textarea name="description" class="form-control" rows="5" placeholder="Which kind of job or work you want? Please write full description here.">{{$profile->description}}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="user-dashboard-info-box">
                        <div class="section-title-02 mb-3">
                            <h4>Address</h4>
                        </div>
                        <div class="form-row">
                            <div class="form-group mb-0 col-md-12">
                                <label>Enter Your Location</label>
                                <input type="text" class="form-control" id="autocomplete" placeholder="start typing your society appartment name here." onchange="geolocate()" name="street_address_search" value="{{ $profile->street_address_search }}">
                            </div>
                        </div>
                        <div class="form-row mt-2">
                            <div class="form-group mb-0 col-md-2">
                                <label>Flat(House)</label>
                                <input type="text" class="form-control" name="house_no" id="street_number" value="{{ $profile->house_no }}">
                            </div>
                            <div class="form-group mb-0 col-md-10">
                                <label>Street Address</label>
                                <input type="text" class="form-control" name="street_address" id="route" value="{{ $profile->street_address }}">
                            </div>
                            <div class="form-group col-md-4 mt-2">
                                <label>Zipcode</label>
                                <input type="text" class="form-control" placeholder="ZIPCODE" name="zipcode" id="postal_code" value="{{ $profile->zipcode }}">
                            </div>

                            <div class="form-group col-md-4 mt-2">
                                <label>City</label>
                                <input type="text" class="form-control" placeholder="City" name="city" id="locality" value="{{ $profile->city }}">
                            </div>

                            <div class="form-group col-md-4 mt-2">
                                <label>State</label>
                                <input type="text" class="form-control" placeholder="State" name="state" id="administrative_area_level_1" value="{{ $profile->state }}">
                                <input type="hidden" name="country" id="country" value="{{ $profile->country }}">
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-md btn-primary" type="submit" id="profileUpdateButton">Update Profile</button>
                </form>
            </div>
        </div>
    </div>
</section>
@endsection

@section('js-hooks')
<script src="{{ asset('assets/js/select2/select2.full.js') }}"></script>
<script src="{{ asset('assets/js/datetimepicker/moment.min.js') }}"></script>
<script src="{{ asset('assets/js/datetimepicker/datetimepicker.min.js') }}"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC4NPCCrBZ1TsbpYntb_AIHaNE180bQTcQ&libraries=places&callback=initAutocomplete" async defer></script>
<script>
    var placeSearch, autocomplete;
    var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'long_name',
        country: 'long_name',
        postal_code: 'short_name',
    };

    function initAutocomplete() {
        // Create the autocomplete object, restricting the search predictions to
        // geographical location types.
        autocomplete = new google.maps.places.Autocomplete(
            document.getElementById('autocomplete'), {
                types: ['geocode']
            });

        // Avoid paying for data that you don't need by restricting the set of
        // place fields that are returned to just the address components.
        autocomplete.setFields(['address_component']);

        // When the user selects an address from the drop-down, populate the
        // address fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
    }

    function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();
        console.log(place);

        for (var component in componentForm) {
            document.getElementById(component).value = '';
            document.getElementById(component).disabled = false;
        }

        // Get each component of the address from the place details,
        // and then fill-in the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
            var addressType = place.address_components[i].types[0];
            if (componentForm[addressType]) {
                var val = place.address_components[i][componentForm[addressType]];
                document.getElementById(addressType).value = val;
            }
        }
    }

    function geolocate() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                var geolocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                var circle = new google.maps.Circle({
                    center: geolocation,
                    radius: position.coords.accuracy
                });
                autocomplete.setBounds(circle.getBounds());
            });
        }
    }
</script>
@endsection

@section('css-hooks')
<link rel="stylesheet" href="{{ asset('assets/css/datetimepicker/datetimepicker.min.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/css/select2/select2.css') }}" />
@endsection

@section('custom-scripts')
<script>
    $(document).ready(function() {
        $('#profileForm').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('post.profile') }}",
                method: 'POST',
                beforeSend: function() {
                    $('#profileUpdateButton').attr('disabled', true);
                    $('#profileUpdateButton').text('Loading...');
                },
                data: $('#profileForm').serialize(),

                success: function(data) {
                    if (parseInt(data.percentage) > 90) {
                        toastr["success"]("Profile is updated successfully.", data.success);
                        location.reload();
                    }
                    toastr["success"]("Profile is updated successfully.", data.success);
                },
                error: function(xhr) {
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors);
                },
                complete: function() {
                    $('#profileUpdateButton').attr('disabled', false);
                    $('#profileUpdateButton').text('Update Profile');
                }

            });
        });
    });
</script>
@endsection