@extends('layouts.app')

@section('content')
@include('employee.includes.header')
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row mb-3 mb-lg-5 mt-3 mt-lg-0">
                    <div class="col-lg-4 mb-4 mb-lg-0">
                        <div class="candidates-feature-info bg-dark">
                            <div class="candidates-info-icon text-white">
                                <i class="fas fa-globe-asia"></i>
                            </div>
                            <div class="candidates-info-content">
                                <h6 class="candidates-info-title text-white">Saved Applications</h6>
                            </div>
                            <div class="candidates-info-count">
                                <h3 class="mb-0 text-white">{{ $totalFavoriteJobs }}</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4 mb-lg-0">
                        <div class="candidates-feature-info bg-primary">
                            <div class="candidates-info-icon text-white">
                                <i class="fas fa-thumbs-up"></i>
                            </div>
                            <div class="candidates-info-content">
                                <h6 class="candidates-info-title text-white">Total Applied</h6>
                            </div>
                            <div class="candidates-info-count">
                                <h3 class="mb-0 text-white">{{ $totalAppliedJobs }}</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4 mb-lg-0">
                        <div class="candidates-feature-info bg-success">
                            <div class="candidates-info-icon text-white">
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="candidates-info-content">
                                <h6 class="candidates-info-title text-white">Shortlisted Applications</h6>
                            </div>
                            <div class="candidates-info-count">
                                <h3 class="mb-0 text-white">00</h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="user-dashboard-info-box mb-0 pb-4">
                    <div class="section-title">
                        <h4>Recent Applied Jobs</h4>
                    </div>
                    <div class="row">
                        @forelse($recentJobs as $recentJob)
                        @php
                        $logo = $recentJob->job->user->getFirstMediaUrl('profiles', 'logo');
                        if($logo == ''){
                        $logo = asset('company.png');
                        }
                        @endphp
                        <div class="col-12">
                            <div class="job-list ">
                                <div class="job-list-logo">
                                    <img class="img-fluid" src="{{$logo}}" alt="">
                                </div>
                                <div class="job-list-details">
                                    <div class="job-list-info">
                                        <div class="job-list-title">
                                            <h5 class="mb-0"><a href="{{ route('showCopmany', $recentJob->job->companySlug()) }}">{{ $recentJob->job->title }}</a></h5>
                                        </div>
                                        <div class="job-list-option">
                                            <ul class="list-unstyled">
                                                <li><i class="fas fa-map-marker-alt pr-1"></i>{{ $recentJob->job->city }}, {{ $recentJob->job->state }}</li>
                                                <li><i class="fas fa-filter pr-1"></i>{{ $recentJob->job->category->name }}</li>
                                                <li><a class="freelance text-capitalize" href="javascript:void(0)"><i class="fas fa-suitcase pr-1"></i>{{ $recentJob->job->jobType->name }}</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="job-list-favourite-time"> <span class="job-list-time order-1"><i class="far fa-clock pr-1"></i>{{ $recentJob->created_at->diffForHumans() }}</span> </div>
                            </div>
                        </div>
                        @empty
                        <div class="col-12 text-center">
                            <h4>No Jobs Applied Yet</h4>
                            <a href="{{ route('search') }}" class="btn btn-primary">Find Jobs</a>
                        </div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection