@extends('layouts.app')

@section('content')
@include('employee.includes.header')
<section>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="user-dashboard-info-box">
                    <div class="dashboard-resume-title d-flex align-items-center">
                        <div class="section-title-02 mb-sm-0">
                            <h4 class="mb-0">Education</h4>
                        </div>
                    </div>
                    <div class="collapse show mb-4" id="dateposted">
                        <div class="bg-light p-3 mt-4">
                            <form class="form-row" id="addEducationForm">
                                @csrf
                                <div class="form-group col-md-12">
                                    <label>Title</label>
                                    <input type="text" class="form-control" name="title">
                                </div>
                                <div class="form-group col-md-6 select-border">
                                    <label>Year</label>
                                    <select class="form-control basic-select" name="year">
                                        @foreach(range(date('Y'),1970) as $year)
                                        <option value="{{ $year }}">{{$year}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Institute(University, College Name, Organization)</label>
                                    <input type="text" class="form-control" name="institute">
                                    <input type="hidden" name="university_id" value="0">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Scroe(Percentages/CGPA)</label>
                                    <input type="number" class="form-control" step="any" name="score">
                                </div>
                                <div class="form-group col-md-12 mb-0">
                                    <button class="btn btn-md btn-primary" id="addEducationButton" type="submit">Add Education</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    @foreach($educations as $education)
                    <div class="jobber-candidate-timeline">
                        <div class="jobber-timeline-icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <div class="jobber-timeline-item">
                            <div class="jobber-timeline-cricle">
                                <i class="far fa-circle"></i>
                            </div>
                            <div class="jobber-timeline-info">
                                <div class="dashboard-timeline-info">
                                    <div class="dashboard-timeline-edit">
                                        <ul class="list-unstyled d-flex">
                                            <li><a class="text-right" href="javascript:void(0);" onclick="editEducation({{$education->id}})"> <i class="fas fa-pencil-alt text-info mr-2"></i> </a></li>
                                            <li><a href="javascript:void(0);" onclick="deleteEducation({{$education->id}})"><i class="far fa-trash-alt text-danger"></i></a></li>
                                        </ul>
                                    </div>
                                    <span class="jobber-timeline-time">Year {{ $education->year }}</span>
                                    <h6 class="mb-2">{{ $education->title }}</h6>
                                    <span>- {{ $education->university->name }}</span>
                                    <p class="mt-2"><b>Scrore - <b> <i>{{ $education->score }} {{ $education->score > 10 ? '%' : 
                                        ''  }}</i></p>
                                </div>

                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editEducationModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header p-4">
                    <h4 class="mb-0 text-center">Change Education Details</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body mb-3">
                    <form class="form-row" id="editEducationForm">
                        <input type="hidden" name="id">
                        @csrf
                        {{ method_field('PATCH') }}
                        <div class="form-group col-md-12">
                            <label>Title</label>
                            <input type="text" class="form-control" name="title">
                        </div>
                        <div class="form-group col-md-6 select-border">
                            <label>Year</label>
                            <select class="form-control" name="year">
                                @foreach(range(date('Y'),1970) as $year)
                                <option value="{{ $year }}">{{$year}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Institute(University, College Name, Organization)</label>
                            <input type="text" class="form-control" name="institute">
                            <input type="hidden" name="university_id" value="0">
                        </div>
                        <div class="form-group col-md-12">
                            <label>Scroe(Percentages/CGPA)</label>
                            <input type="number" class="form-control" step="any" name="score">
                        </div>
                        <div class="form-group col-md-12 mb-0">
                            <button class="btn btn-md btn-primary" id="updateEducationButton" type="submit">Update Details</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
@section('js-hooks')
<script src="{{ asset('assets/js/select2/select2.full.js') }}"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
@endsection
@section('css-hooks')
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
@endsection
@section('custom-scripts')
<script>
    function editEducation(educationId) {
        var DataUrl = "{{ route('education.edit', ':argument') }}";
        DataUrl = DataUrl.replace(':argument', educationId);
        $.ajax({
            url: DataUrl,
            method: 'GET',
            beforeSend: function() {
                // $('#addEducationButton').attr('disabled', true);
                // $('#addEducationButton').text('Loading...');
            },
            data: {
                id: educationId,
                _token: '{{ csrf_token() }}',
                _method: 'DELETE'
            },
            success: function(data) {
                initializeAutocomplete('editEducationModal');
                $('#editEducationForm [name="title"]').val(data.title);
                $('#editEducationForm [name="id"]').val(data.id);
                $('#editEducationForm [name="institute"]').val(data.university.name);
                $('#editEducationForm [name="score"]').val(data.score);
                $('#editEducationForm [name="university_id"]').val(data.university_id);
                $('select[name="year"]').find('option[value="' + data.year + '"]').attr("selected", true);
                $('#editEducationModal').modal('show');
            },
            error: function(xhr) {
                $("input").removeClass("is-invalid");
                $(".invalid-feedback").remove();
                errors = xhr.responseJSON.errors;
                printErrorMsg(errors);
            },
            complete: function() {
                // $('#addEducationButton').attr('disabled', false);
                // $('#addEducationButton').text('Add Education');
            }

        });
    }

    function deleteEducation(educationId) {
        if (confirm('Are you sure you want to delete it?')) {
            var DataUrl = "{{ route('education.destroy', ':argument') }}";
            DataUrl = DataUrl.replace(':argument', educationId);
            $.ajax({
                url: DataUrl,
                method: 'POST',
                beforeSend: function() {
                    // $('#addEducationButton').attr('disabled', true);
                    // $('#addEducationButton').text('Loading...');
                },
                data: {
                    id: educationId,
                    _token: '{{ csrf_token() }}',
                    _method: 'DELETE'
                },
                success: function(data) {
                    toastr["success"]("Education removed successfully.", "Education Deleted!");
                    location.reload();
                },
                complete: function() {
                    // $('#addEducationButton').attr('disabled', false);
                    // $('#addEducationButton').text('Add Education');
                }
            });
        }
    }
</script>
<script>
    $(document).ready(function() {
        $('#addEducationForm').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('education.store') }}",
                method: 'POST',
                beforeSend: function() {
                    $('#addEducationButton').attr('disabled', true);
                    $('#addEducationButton').text('Loading...');
                },
                data: $('#addEducationForm').serialize(),
                success: function(data) {
                    toastr["success"]("Education added successfully.", "Education Added!");
                    location.reload();
                },
                error: function(xhr) {
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors, 'addEducationForm');
                },
                complete: function() {
                    $('#addEducationButton').attr('disabled', false);
                    $('#addEducationButton').text('Add Education');
                }
            });
        });
        $('#editEducationForm').submit(function(e) {
            e.preventDefault();
            let educationId = $('#editEducationForm [name="id"]').val();
            var DataUrl = "{{ route('education.update', ':argument') }}";
            DataUrl = DataUrl.replace(':argument', educationId);
            $.ajax({
                url: DataUrl,
                method: 'POST',
                beforeSend: function() {
                    $('#updateEducationButton').attr('disabled', true);
                    $('#updateEducationButton').text('Loading...');
                },
                data: $('#editEducationForm').serialize(),
                success: function(data) {
                    toastr["success"]("Education updated successfully.", "Education updated!");
                    location.reload();
                },
                error: function(xhr) {
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors, 'editEducationForm');
                },
                complete: function() {
                    $('#updateEducationButton').attr('disabled', false);
                    $('#updateEducationButton').text('Update Details');
                }
            });
        });
    });
</script>
<script>
    function initializeAutocomplete(formId) {
        $("#" + formId + " [name='institute']").autocomplete({
            source: function(request, response) {
                $.ajax({
                    url: "{{ route('index.institute') }}",
                    type: 'GET',
                    dataType: "JSON",
                    data: {
                        term: request.term
                    },
                    success: function(data) {
                        if (data.length > 0) {
                            response(data);
                        } else {
                            $("#" + formId + " [name='university_id']").val(0);
                        }
                    }
                });
            },
            minLength: 3,
            appendTo: $('#' + formId),
            select: function(event, ui) {
                $("#" + formId + " [name='university_id']").val(ui.item.id);
            }
        });
    }
    initializeAutocomplete('addEducationForm');
</script>

@endsection