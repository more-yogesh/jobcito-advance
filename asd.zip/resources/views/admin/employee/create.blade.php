@extends('layouts.app')

@section('content')
<section class="space-ptb bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="section-title text-center">
                    <h2 class="text-primary">Post a New Job</h2>
                </div>
            </div>
            <div class="col-md-8">
                <div class=" justify-content-center">
                    <ul class="nav nav-tabs nav-tabs-03 justify-content-center d-sm-flex d-block text-center" id="myTab" role="tablist">
                        <li class="flex-fill">
                            <a class="nav-item active" id="Job-detail-tab" data-toggle="tab" href="#Job-detail" role="tab" aria-controls="Job-detail" aria-selected="false">
                                <div class="feature-info-icon mb-3">
                                    <i class="flaticon-suitcase"></i>
                                </div>
                                <span>Job Detail</span>
                            </a>
                        </li>
                        <li class="flex-fill">
                            <a class="nav-item disabled" id="Package-tab" role="tab" aria-controls="Package" aria-selected="false">
                                <div class="feature-info-icon mb-3">
                                    <i class="flaticon-debit-card"></i>
                                </div>
                                <span>Package &amp; Payments</span>
                            </a>
                        </li>
                        <li class="flex-fill">
                            <a class="nav-item disabled" id="Confirm-tab" role="tab" aria-controls="Confirm" aria-selected="false">
                                <div class="feature-info-icon mb-3">
                                    <i class="flaticon-tick"></i>
                                </div>
                                <span>Confirmation</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="tab-content" id="myTabContent">
    <div class="tab-pane fade active show" id="Job-detail" role="tabpanel" aria-labelledby="Job-detail-tab">
        <section class="space-ptb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <form method="post" id="addJobForm">
                            @csrf
                            <input type="hidden" name="phase1" value="phase1">
                            <div class="user-dashboard-info-box">
                                <div class="section-title-02 mb-4">
                                    <h4>Basic Information</h4>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label>Job Title</label>
                                        <input type="text" class="form-control" name="title" placeholder="Example: Sales Exective, Software Developer, etc.">
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label>Job Category</label>
                                        <input type="text" class="form-control" name="category" placeholder="Example: Accounting, Engineering, IT Jobs etc.">
                                        <input type="hidden" name="category_id" value="0">
                                    </div>
                                    <div class="form-group col-md-12 mb-0">
                                        <label>Description</label>
                                        <textarea class="form-control" rows="5" placeholder="Use a past defeat as a motivator. Remind yourself you have nowhere to go except up as you have already been at the bottom" name="description" id="description"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="user-dashboard-info-box">
                                <div class="section-title-02 mb-3">
                                    <h4>Job Location</h4>
                                </div>
                                <div class="form-row mt-2">
                                    <div class="form-group col-md-4 mt-2">
                                        <label>Zipcode</label>
                                        <input type="text" class="form-control" placeholder="ZIPCODE" name="zipcode" id="postal_code" value="{{ $profile->zipcode ?? '' }}">
                                    </div>

                                    <div class="form-group col-md-4 mt-2">
                                        <label>City</label>
                                        <input type="text" class="form-control" placeholder="City" name="city" id="locality" value="{{ $profile->city ?? '' }}">
                                    </div>

                                    <div class="form-group col-md-4 mt-2">
                                        <label>State</label>
                                        <input type="text" class="form-control" placeholder="State" name="state" id="administrative_area_level_1" value="{{ $profile->state ?? '' }}">
                                        <input type="hidden" name="country" id="country" value="{{ $profile->country ?? '' }}">
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-lg btn-primary" id="addJobButton">Add Job</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <div class="tab-pane fade show" id="Package" role="tabpanel" aria-labelledby="Package-tab">
        <section class="space-ptb">
            <h1>TAB2</h1>
        </section>
    </div>
    <div class="tab-pane fade show" id="Confirm" role="tabpanel" aria-labelledby="Confirm-tab">
        <section class="space-ptb">
            <h1>TAB3</h1>
        </section>
    </div>
</div>
@endsection
@section('css-hooks')
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="{{ asset('assets/richtext/richtext.min.css') }}">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
@endsection
@section('js-hooks')
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="{{ asset('assets/richtext/jquery.richtext.js') }}"></script>
@endsection
@section('custom-scripts')
<script>
    $(document).ready(function() {
        $('#addJobForm').submit(function(e) {
            console.log("Desc", $('#description').val());
            e.preventDefault();
            $.ajax({
                url: "{{ route('jobs.store') }}",
                method: 'POST',
                beforeSend: function() {
                    $('#addJobButton').attr('disabled', true);
                    $('#addJobButton').text('Loading...');
                },
                data: $('#addJobForm').serialize(),

                success: function(data) {
                    toastr["success"]("Job added successfully.", "Job Added!");
                    let JobUpdateUrl = "{{ route('jobs.edit', ':jobId') }}"
                    JobUpdateUrl = JobUpdateUrl.replace(':jobId', data.id);
                    window.location.replace(JobUpdateUrl);
                },
                error: function(xhr) {
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors);
                },
                complete: function() {
                    $('#addJobButton').attr('disabled', false);
                    $('#addJobButton').text('Add Job');
                }

            });
        });
        $('#description').richText({
            // text formatting
            bold: true,
            italic: true,
            underline: true,
            // text alignment
            leftAlign: false,
            centerAlign: false,
            rightAlign: false,
            justify: false,
            // lists
            ol: true,
            ul: true,
            // title
            heading: false,
            // fonts
            fonts: false,
            fontColor: false,
            fontSize: false,
            // uploads
            imageUpload: false,
            fileUpload: false,
            // media
            videoEmbed: false,
            // link
            urls: false,
            // tables
            table: false,
            // code
            removeStyles: false,
            code: false,
            // colors
            colors: [],
            // dropdowns
            fileHTML: '',
            imageHTML: '',
            // privacy
            youtubeCookies: false,
            // developer settings
            useSingleQuotes: false,
            height: 0,
            heightPercentage: 0,
            id: "",
            class: "",
            useParagraph: false,
            maxlength: 0,
            callback: undefined
        });

    });
</script>
<script>
    function initializeAutocomplete(formId) {
        $("#" + formId + " [name='category']").autocomplete({
            source: function(request, response) {
                $.ajax({
                    url: "{{ route('category.index') }}",
                    type: 'GET',
                    dataType: "JSON",
                    data: {
                        term: request.term
                    },
                    success: function(data) {
                        if (data.length > 0) {
                            response(data);
                        } else {
                            $("#" + formId + " [name='category_id']").val(0);
                        }
                    }
                });
            },
            minLength: 2,
            appendTo: $('#' + formId),
            select: function(event, ui) {
                $("#" + formId + " [name='category_id']").val(ui.item.id);
            }
        });
    }
    initializeAutocomplete('addJobForm');
</script>
@endsection