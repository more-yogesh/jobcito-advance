<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="{{ $user->employee->name }}" />
    <meta name="author" content="{{ $user->employee->description }} " />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>{{ $user->employee->name }}</title>
    <link href="images/favicon.ico" rel="shortcut icon" />
    <link rel="stylesheet" href="{{ asset('assets/css/font-awesome/all.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/flaticon/flaticon.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap/bootstrap.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}" />
</head>
<body>
    <section class="space-ptb">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-lg-5">
                            <div class="resume-base bg-light user-dashboard-info-box">
                                <div class="profile">
                                    <div class="jobber-user-info">
                                        <div class="profile-avatar">
                                            @php
                                            $logo = $user->getFirstMediaUrl('profiles', 'logo');
                                            if($logo == ''){
                                            $logo = asset('employee.png');
                                            }
                                            @endphp
                                            <img class="img-fluid " src="{{ $logo }}" alt="">
                                        </div>
                                        <div class="profile-avatar-info mt-3">
                                            <h5>{{ $user->employee->name }}</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="about-candidate border-top">
                                    <div class="candidate-info">
                                        <h6>Name:</h6>
                                        <p>{{ $user->employee->name }}</p>
                                    </div>
                                    <div class="candidate-info">
                                        <h6>Email:</h6>
                                        <p>{{ $user->email }}</p>
                                    </div>
                                    <div class="candidate-info">
                                        <h6>Phone:</h6>
                                        <p>{{ $user->mobile }}</p>
                                    </div>
                                    <div class="candidate-info">
                                        <h6>Date Of Birth:</h6>
                                        <p>{{ $user->employee->dob ? $user->employee->dob->format('d M, Y')  :  'Not Provided' }}</p>
                                    </div>
                                    <div class="candidate-info">
                                        <h6>Address:</h6>
                                        <p>{{ $user->employee->city }}, {{ $user->employee->state }}</p>
                                    </div>
                                    <div class="candidate-info">
                                        <h6>Gender:</h6>
                                        <p>{{ $user->employee->gender }}</p>
                                    </div>
                                    <div class="candidate-info">
                                        <h6>About Me:</h6>
                                        <p>{{ $user->employee->description }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="resume-experience pl-0">
                                <div class="timeline-box">
                                    <h5 class="resume-experience-title">Education:</h5>
                                    @forelse($user->educations as $education)
                                    <div class="jobber-candidate-timeline">
                                        <div class="jobber-timeline-icon">
                                            <i class="fas fa-graduation-cap"></i>
                                        </div>
                                        <div class="jobber-timeline-item">
                                            <div class="jobber-timeline-cricle">
                                                <i class="far fa-circle"></i>
                                            </div>
                                            <div class="jobber-timeline-info">
                                                <div class="dashboard-timeline-info">
                                                    <div class="dashboard-timeline-edit">
                                                        <ul class="list-unstyled d-flex">
                                                            <li><a class="text-right" href="javascript:void(0);" onclick="editEducation({{$education->id}})"> <i class="fas fa-pencil-alt text-info mr-2"></i> </a></li>
                                                            <li><a href="javascript:void(0);" onclick="deleteEducation({{$education->id}})"><i class="far fa-trash-alt text-danger"></i></a></li>
                                                        </ul>
                                                    </div>
                                                    <span class="jobber-timeline-time">Year {{ $education->year }}</span>
                                                    <h6 class="mb-2">{{ $education->title }}</h6>
                                                    <span>- {{ $education->university->name }}</span>
                                                    <p class="mt-2"><b>Scrore - <b> <i>{{ $education->score }} {{ $education->score > 10 ? '%' : ''  }}</i></p>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    @empty
                                    <div>
                                        <h6 class="text-center text-secondary">No education is provided</h6>
                                    </div>
                                    @endforelse
                                </div>
                                <div class="timeline-box mt-4">
                                    <h5 class="resume-experience-title">Work & Experience:</h5>
                                    <div class="jobber-candidate-timeline">
                                        @forelse($user->experiences as $experience)
                                        <div class="jobber-candidate-timeline mt-4">
                                            <div class="jobber-timeline-icon">
                                                <i class="fas fa-briefcase"></i>
                                            </div>
                                            <div class="jobber-timeline-item">
                                                <div class="jobber-timeline-cricle">
                                                    <i class="far fa-circle"></i>
                                                </div>
                                                <div class="jobber-timeline-info">
                                                    <div class="dashboard-timeline-info">
                                                        <div class="dashboard-timeline-edit">
                                                            <ul class="list-unstyled d-flex">
                                                                <li><a class="text-right" href="javascript:void(0)" onclick="editExperience({{ $experience->id }})"> <i class="fas fa-pencil-alt text-info mr-2"></i> </a></li>
                                                                <li><a href="javascript:void(0)" onclick="deleteExperience({{ $experience->id }})"><i class="far fa-trash-alt text-danger"></i></a></li>
                                                            </ul>
                                                        </div>
                                                        @php
                                                        $start_date = \Carbon\Carbon::parse($experience->from_date);
                                                        $end_date = \Carbon\Carbon::parse($experience->to_date);
                                                        $experienceMonths = $start_date->diffInMonths($end_date);
                                                        @endphp
                                                        <span class="jobber-timeline-time">{{ $experience->from_date->format('d M, Y') }} <b>To</b> {{ $experience->to_date->format('d M, Y') }} (<i>{{ $experienceMonths }} months of experience</i>)</span>
                                                        <h6 class="mb-2">{{ $experience->title }}</h6>
                                                        <span>- {{ $experience->company_name }}</span>
                                                        <p class="mt-2">{{ $experience->description }}</p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        @empty
                                        <div>
                                            <h6 class="text-center text-secondary">No education is provided</h6>
                                        </div>
                                        @endforelse
                                    </div>
                                </div>
                                <div class="mt-4">
                                    <h5>Professional Skill:</h5>
                                    <p>{{ $user->employee->skills }}</p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div id="back-to-top" class="back-to-top">
        <i class="fas fa-angle-up"></i>
    </div>
</body>
</html>