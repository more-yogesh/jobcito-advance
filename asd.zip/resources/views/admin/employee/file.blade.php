@extends('layouts.app')
@section('content')
@include('admin.includes.header')
<section>
    <title>Upload Resume</title>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Resume Upload <a href="{{ route('employee.index') }}" class="btn btn-info btn-sm float-right">Back</a></h4>
                        <hr />
                    </div>
                    <div class="alert" id="message" style="display: none"></div>
                    <form method="post" id="upload_form" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="id" value="{{ request('id') }}">
                        <div class="form-group">
                            <table class="table">
                                <tr>
                                    <td><label>Select File And Upload</label> <input type="file" name="select_file" id="select_file" /></br>
                                        <input type="submit" name="upload" id="submit" class="btn btn-primary" value="Upload">
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </form>
                    <span id="uploaded_image"></span>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
@section('custom-scripts')
<script>
    $(document).ready(function() {
        $('#upload_form').on('submit', function(event) {
            event.preventDefault();
            $.ajax({
                url: "{{ route('employee.action') }}",
                method: "POST",
                data: new FormData(this),
                dataType: 'JSON',
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    
                    $("#upload_form").html("Resume Upload sucessfully");
                    $('#upload_form').fadeOut(5000);
                }
            })
        });
    });
</script>
@endsection