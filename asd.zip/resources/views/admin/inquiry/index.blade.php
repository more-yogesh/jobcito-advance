@extends('layouts.app')

@section('content')
@include('admin.includes.header')
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-dashboard-info-box mb-0">
                    <div class="section-title-02 mb-2">
                        <h4>Student Inquiries <a href="{{ route('inquiry.create') }}" class="btn btn-info btn-sm float-right">Create Inquiry</a></h4>
                        <hr />

                    </div>

                    <div class="user-dashboard-table">
                        <table id="inquiry-table" class="table table-striped table-bordered">
                            <thead class="bg-light">
                                <tr>
                                    <th scope="col">id</th>
                                    <th scope="col">course Name</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Mobile</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Schedule</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
@section('css-css-hooks')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" />
@endsection

@section('custom-scripts')
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(function() {
        var table = $('#inquiry-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('inquiry.datatable') }}",

            columns: [{
                    data: 'id',
                    name: 'id'
                },
                {
                    data: 'course_name',
                    name: 'course_name',
                },

                {
                    data: 'name',
                    name: 'name',
                },
                {
                    data: 'mobile',
                    name: 'mobile',
                    sortable: false
                },
                {
                    data: 'status',
                    name: 'status',
                },
                {
                    data: 'description',
                    name: 'description',
                },
                {
                    data: 'schedule',
                    name: 'schedule',
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                },
            ]
        });
    });


    function confirmDelete() {
        if (confirm('Are you sure you want to delete this post?')) {
            return true;
        }
        return false;
    }
</script>
@endsection