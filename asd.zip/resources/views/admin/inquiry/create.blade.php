@extends('layouts.app')
@section('content')
@include('admin.includes.header')
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form method="POST" id="inquiryCreateForm">
                    @csrf
                    <div class="user-dashboard-info-box">
                        <div class="section-title-02 mb-2">
                            <h4>Create inquiry Details <a href="{{ route('inquiry.index') }}" class="btn btn-info btn-sm float-right">Back</a></h4>
                            <hr />

                        </div>
                        <div class="form-row">

                            <div class="form-group col-md-6">
                                <label>Course Name</label>
                                <input type="course_name" class="form-control" name="course_name">
                            </div>
                            <div class="form-group col-md-6">
                                <label>Name</label>
                                <input type="name" class="form-control" name="name">
                            </div>
                            <div class="form-group col-md-6">
                                <label>Phone</label>
                                <input type="number" class="form-control" name="mobile">
                            </div>
                            <div class="form-group col-md-6">
                                <label>Status</label>
                                <select name="status" class="form-control" id="status">
                                    <option value="Pending">Pending</option>
                                    <option value="Done" id="done">Done</option>
                                    <option value="Not Reachable" id="notreachable">Not Reachable</option>
                                    <option value="Busy">Busy</option>
                                    <option value="Schedule">Schedule</option>
                                    <option value="Not Intrested" id="notintrested">Not Intrested</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6" id="picker">
                                <label>Schedule</label>
                                <div class="md-form md-outline ">
                                    <div class="input-group date" id="datetimepicker-01" data-target-input="nearest">
                                        <input type="datetime-local" class="form-control" name="schedule" id="datetime">
                                        <div class="input-group-append">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group mb-0 col-md-12">
                                <label>Description</label>
                                <textarea name="description" class="form-control" rows="5" placeholder="Give yourself the power of responsibility. Remind yourself the only thing stopping you is yourself."></textarea>
                            </div>
                        </div>


                    </div>
            </div>
        </div>
        <button class="btn btn-md btn-primary" type="submit" id="inquiryCreateButton">Submit</button>
        </form>
    </div>
    </div>
    </div>
</section>
@endsection

@section('js-hooks')
<script src="{{ asset('assets/js/select2/select2.full.js') }}"></script>
<script src="{{ asset('assets/js/datetimepicker/moment.min.js') }}"></script>
<script src="{{ asset('assets/js/datetimepicker/datetimepicker.min.js') }}"></script>
@endsection

@section('css-hooks')
<link rel="stylesheet" href="{{ asset('assets/css/datetimepicker/datetimepicker.min.css') }}" />
@endsection

@section('custom-scripts')
<script>
    $(document).ready(function() {
        $('#inquiryCreateForm').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('inquiry.store') }}",
                method: 'POST',
                beforeSend: function() {
                    $('#inquiryCreateButton').attr('disabled', true);
                    $('#inquiryCreateButton').text('Loading...');
                },
                data: $('#inquiryCreateForm').serialize(),

                success: function(data) {
                    toastr["success"]("Create successfully.", "success");
                    $('#inquiryCreateForm')[0].reset();
                    printErrorMsg([]);
                    // window.location.href = "{{ route('inquiry.index') }}";
                },
                error: function(xhr) {
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors);
                },
                complete: function() {
                    $('#inquiryCreateButton').attr('disabled', false);
                    $('#inquiryCreateButton').text('Create');
                }

            });
        });
    });
</script>
<script>
    $(document).ready(function() {
        $("#picker").hide();
        $("#status").change(function() {
            var status = $("#status").val();
            showSchedule(status);
        });

        function showSchedule(status) {
            if (status == 'Schedule') {
                $("#picker").show();
            } else {
                $("#picker").hide();
            }
        }
    });
</script>
@endsection