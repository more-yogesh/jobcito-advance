@extends('layouts.app')

@section('content')
@include('admin.includes.header')
<section>
    <div class="container">
        <form method="POST" id="resetPasswordForm">
            @csrf
            <div class="row">
                <div class="col-md-12">
                    <div class="user-dashboard-info-box">
                        <div class="section-title-02 mb-4">
                            <h4>Change Password</h4>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group col-md-12">
                                    <label>Current Password</label>
                                    <input type="password" class="form-control" name="current_password">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>New Password</label>
                                    <input type="password" class="form-control" name="new_password">
                                </div>
                                <div class="form-group col-md-12 mb-0">
                                    <label>Confirm Password</label>
                                    <input type="password" class="form-control" name="confirm_password">
                                </div>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-lg btn-primary" id="passwordUpdateButton" type="submit">Change Password</button>
                </div>
            </div>
        </form>
    </div>
</section>
@endsection
@section('custom-scripts')
<script>
    $(document).ready(function() {
        $('#resetPasswordForm').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('admin.post.change.password') }}",
                method: 'POST',
                beforeSend: function() {
                    $('#passwordUpdateButton').attr('disabled', true);
                    $('#passwordUpdateButton').text('Loading...');
                },
                data: $('#resetPasswordForm').serialize(),

                success: function(data) {
                    toastr["success"]("Password is updated successfully.", "Password Updated!");
                },
                error: function(xhr) {
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors);
                },
                complete: function() {
                    $('#passwordUpdateButton').attr('disabled', false);
                    $('#passwordUpdateButton').text('Change Password');
                }
            });
        });
    });
</script>
@endsection