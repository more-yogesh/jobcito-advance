<div class="header-inner bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="candidates-user-info">
                    <div class="jobber-user-info">
                        <div class="profile-avatar">
                            <form method="POST" enctype="multipart/form-data" id="profileImage" action="{{ route('empolyee.image') }}">
                                <img class="img-fluid " src="{{ asset('employee.png') }}" alt="">
                            </form>
                        </div>
                        <div class="profile-avatar-info ml-4">
                            <h3 class="text-capitalize">Admin</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<section class="header-inner">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="sticky-top secondary-menu-sticky-top">
                    <div class="secondary-menu">
                        <ul class="list-unstyled mb-0">
                            <li><a class="{{ Route::currentRouteNamed('admin.dashboard') ? 'active' : '' }}" href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                            <li><a class="{{ Route::currentRouteNamed('company.index') ||Route::currentRouteNamed('company.edit')? 'active' : '' }}" href="{{ route('company.index') }}">Companies</a></li>
                            <li><a class="{{ Route::currentRouteNamed('employee.index') || Route::currentRouteNamed('employee.edit') ? 'active' : '' }}" href="{{ route('employee.index') }}">Employee</a></li>
                            <li><a class="{{ Route::currentRouteNamed('contacts.index') ? 'active' : '' }}" href="{{ route('contacts.index') }}">Contacts</a></li>
                            <li><a class="{{ Route::currentRouteNamed('contacts.direct') ? 'active' : '' }}" href="{{ route('contacts.direct') }}">Direct Apply</a></li>
                           <li><a class="{{ Route::currentRouteNamed('inquiry.index') ||Route::currentRouteNamed('inquiry.create') ||Route::currentRouteNamed('inquiry.edit') ? 'active' : '' }}" href="{{ route('inquiry.index') }}">Inquiry</a></li>
                           <li><a class="{{ Route::currentRouteNamed('jobinquiry.index') ||Route::currentRouteNamed('jobinquiry.create') ||Route::currentRouteNamed('jobinquiry.edit') ? 'active' : '' }}" href="{{ route('jobinquiry.index') }}">Job Inquiry</a></li>
                            <li><a class="{{ Route::currentRouteNamed('admin.change.password') ? 'active' : '' }}" href="{{ route('admin.change.password') }}">Change Password</a></li>
                            <li><a class="{{ Route::currentRouteNamed('notifications') ? 'active' : '' }}" href="{{ route('notifications') }}">Notifications &nbsp;<span class="badge badge-danger"> {{ auth()->user()->unreadNotifications->count() }}</span></a></li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>