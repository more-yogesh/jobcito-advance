@extends('layouts.app')
@section('content')
@include('admin.includes.header')
<section>

    <div class="row">
        <div class="col-md-12">
            <div class="user-dashboard-info-box">
                <div class="section-title-02 mb-2">
                    <h4>Student Job Inquiries <a href="{{ route('jobinquiry.create') }}" class="btn btn-info btn-sm float-right">Create Job Inquiry</a></h4>
                    <hr />
                </div>
                <form method="get" id="searchFrom">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Status</label>
                            <select name="status" class="form-control">
                                <option value="Pending" {{ request('status') == 'Pending' ? 'selected' : '' }}>Pending</option>
                                <option value="Schedule" {{ request('status') == 'Schedule' ? 'selected' : '' }}>Schedule</option>
                                <option value="Not Reachable" {{ request('status') == 'Not Reachable' ? 'selected' : '' }}>Not Reachable</option>
                                <option value="Busy" {{ request('status') == 'Busy' ? 'selected' : '' }}>Busy</option>
                                <option value="Done" {{ request('status') == 'Done' ? 'selected' : '' }}>Done</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Course Name</label>
                            <input type="course_name" class="form-control" value="{{ request('course_name') ?? '' }}" name="course_name">
                        </div>
                        <div class="form-group col-md-6">
                            <label>Name</label>
                            <input type="name" class="form-control" value="{{ request('name') ?? '' }}" name="name">
                        </div>
                        <div class="form-group col-md-6">
                            <label>Phone</label>
                            <input type="mobile" class="form-control" value="{{ request('mobile') ?? '' }}" name="mobile">
                        </div>
                        <div class="form-group col-md-6">
                            <button type="submit" class="btn btn-info btn-sm">Search</button></h4>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>



    <form method="get">
        @csrf

        <div class="row">
            <div class="col-md-12">
                <div class="user-dashboard-info-box mb-2">
                    <div class="user-dashboard-table">
                        <table id="jobinquiry-table" class="table table-striped table-bordered">
                            <thead class="bg-light">
                                <tr>
                                    <th scope="col">id</th>
                                    <th scope="col">course Name</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Mobile</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Schedule</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>


                                @forelse($inquiry as $inq)
                                <tr>
                                    <td><input type="checkbox" name="id[]" value="{{$inq->id}}"> </td>

                                    <td>{{ $inq->course_name }}</td>
                                    <td>{{ $inq->name }}</td>
                                    <td>{{ $inq->mobile }}</td>
                                    <td>{{ $inq->status }}</td>
                                    <td>{{ $inq->description }}</td>
                                    <td>{{ $inq->schedule }}</td>

                                    <td>{{ $inq->action }}
                                        <div class="d-inline-block float-left">
                                            <form class="float-left ml-1" method="POST" action="{{route('jobinquiry.destroy', $inq->id)}}" onsubmit="return confirm('Do you really want to submit the form?')">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="edit btn btn-danger btn-sm">
                                                    <i class="fa fa-trash"></i>
                                                </button>



                                        </div>
    </form>
    <a href="{{route('jobinquiry.edit', $inq->id)}}" class="edit btn btn-info btn-sm ml-1"> <i class="fas fa-fw fa-edit"></i></a>
    </div>
    </td>
    </tr>
    @empty
    <tr>
        <td colspan="8">No Data Found</td>
    </tr>
    @endforelse
    </tbody>
    </table>
    </div>
</section>
@endsection
@section('css-css-hooks')
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">
</script>
<link rel="stylesheet" href="https://cdn.datatables.net/rowreorder/1.2.7/css/rowReorder.dataTables.min.css
">
</script>
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.6/css/responsive.dataTables.min.css">
</script>
@endsection

@section('custom-scripts')
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/rowreorder/1.2.7/js/dataTables.rowReorder.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.6/js/dataTables.responsive.min.js"></script>
<script>
    $(document).ready(function() {
        var table = $('#jobinquiry-table').DataTable({
            rowReorder: {
                selector: 'td:nth-child(2)'
            },
            responsive: true
        });
    });
</script>
@endsection
@section('custom-scripts')
<script>
    function confirmDelete() {
        if (confirm('Are you sure you want to delete this post?')) {
            return true;
        }
        return false;

    }
</script>
@endsection