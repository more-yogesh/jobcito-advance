@extends('layouts.app')

@section('content')
@include('company.includes.header')
<section>
    <div class="container">
        @if (isset($errors) && $errors->any())
        <div class="alert alert-danger" role="alert">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
            {{ session('status') }}
        </div>
        @endif

        @if (session()->has('success'))
        <div class="alert alert-success" role="alert">
            <ul>
                @foreach (session()->get('success') as $message)
                <li>{{ $message }}</li>
                @endforeach
            </ul>
            {{ session('status') }}
        </div>
        @endif
        <form method="POST" id="paymentForm" action="{{ route('pay') }}">
            @csrf
            <div class="row">
                <div class="col-md-12">
                    <div class="user-dashboard-info-box">
                        <div class="section-title-02 mb-4">
                            <h4>Make Payment</h4>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group col-md-6">
                                    <label>Payment</label>
                                    <input type="number" class="form-control" name="value" step="0.01" value="{{ mt_rand(500, 10000) / 100 }}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Currency</label>
                                    <select name="currency" class="form-control" required>
                                        @foreach($currencies as $currency)
                                        <option value="{{ $currency->iso }}">{{ strtoupper($currency->iso) }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Select Payment Platform</label>
                                    <div class="form-group" id="toggler">
                                        <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                            @foreach ($paymentPlatforms as $paymentPlatform)
                                            <label class="btn btn-outline-secondary rounded m-2 p-1" data-target="#{{ $paymentPlatform->name }}Collapse" data-toggle="collapse">
                                                <input type="radio" name="payment_platform" value="{{ $paymentPlatform->id }}" required>
                                                <img class="img-thumbnail" src="{{ asset($paymentPlatform->image) }}" height="100" width="100">
                                            </label>
                                            @endforeach
                                        </div>
                                        @foreach ($paymentPlatforms as $paymentPlatform)
                                        <div id="{{ $paymentPlatform->name }}Collapse" class="collapse" data-parent="#toggler">
                                            @include('company.components.' . strtolower($paymentPlatform->name) . '-collapse')
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>

                        <button class="btn btn-lg btn-primary" id="payButton" type="submit">Pay</button>
                    </div>
                </div>
        </form>
    </div>
</section>
@endsection
@section('custom-scripts')
<script>
    $(document).ready(function() {
        $('#resetPasswordForm').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('company.post.change.password') }}",
                method: 'POST',
                beforeSend: function() {
                    $('#passwordUpdateButton').attr('disabled', true);
                    $('#passwordUpdateButton').text('Loading...');
                },
                data: $('#resetPasswordForm').serialize(),

                success: function(data) {
                    toastr["success"]("Password is updated successfully.", "Password Updated!");
                },
                error: function(xhr) {
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors);
                },
                complete: function() {
                    $('#passwordUpdateButton').attr('disabled', false);
                    $('#passwordUpdateButton').text('Change Password');
                }

            });
        });
    });
</script>
@endsection