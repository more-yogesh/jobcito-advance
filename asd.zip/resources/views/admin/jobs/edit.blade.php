@extends('layouts.app')

@push('style')
<style>
    .bg-light-gray {
        background-color: #6c757d1c !important;
    }
</style>
@endpush

@section('content')
<form method="post" id="updateJobPost">
    @csrf
    {{ method_field('PATCH') }}
    <section class="space-ptb bg-light">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12">
                    <div class="section-title text-center">
                        <h2 class="text-primary">Post a New Job</h2>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class=" justify-content-center">
                        <ul class="nav nav-tabs nav-tabs-03 justify-content-center d-sm-flex d-block text-center" id="myTab" role="tablist">
                            <li class="flex-fill">
                                <a class="nav-item" id="datails" data-toggle="tab" href="#Job-detail" role="tab" aria-controls="Job-detail" aria-selected="false">
                                    <div class="feature-info-icon mb-3">
                                        <i class="flaticon-suitcase"></i>
                                    </div>
                                    <span>Job Detail</span>
                                </a>
                            </li>
                            <li class="flex-fill">
                                <a class="nav-item {{ $job->job_type_id == '' ? 'active' : '' }}" id="job-deatails" data-toggle="tab" href="#Details" role="tab" aria-controls="Details" aria-selected="false">
                                    <div class="feature-info-icon mb-3">
                                        <i class="flaticon-check-list"></i>
                                    </div>
                                    <span>Job Criterea</span>
                                </a>
                            </li>
                            <li class="flex-fill">
                                <a class="nav-item {{ $job->job_type_id != ''  ? 'active' : '' }}" id="confirm" data-toggle="tab" href="#Confirm" role="tab" aria-controls="Confirm" aria-selected="false">
                                    <div class="feature-info-icon mb-3">
                                        <i class="flaticon-tick"></i>
                                    </div>
                                    <span>Preview & Confirmation</span>
                                </a>
                            </li>
                            {{-- <li class="flex-fill">
                                <a class="nav-item {{ $job->status == 'confirm'  ? 'active' : '' }}" id="package" data-toggle="tab" href="#package-details" role="tab" aria-controls="package-details" aria-selected="false">
                            <div class="feature-info-icon mb-3">
                                <i class="flaticon-debit-card"></i>
                            </div>
                            <span>Package &amp; Payments</span>
                            </a>
                            </li> --}}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show" id="Job-detail" role="tabpanel" aria-labelledby="datails">
            <section class="space-ptb">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="user-dashboard-info-box">
                                <div class="section-title-02 mb-4">
                                    <h4>Basic Information</h4>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label>Job Title</label>
                                        <input type="text" class="form-control" name="title" placeholder="Example: Sales Exective, Software Developer, etc." value="{{ $job->title }}">
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label>Job Category</label>
                                        <input type="text" class="form-control" name="category" placeholder="Example: Accounting, Engineering, IT Jobs etc." value="{{ $job->category->name }}">
                                        <input type="hidden" name="category_id" value="{{ $job->category->id }}">
                                    </div>
                                    <div class="form-group col-md-12 mb-0">
                                        <label>Description</label>
                                        <textarea name="description" id="description">{{$job->description}}</textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="user-dashboard-info-box">
                                <div class="section-title-02 mb-3">
                                    <h4>Job Location</h4>
                                </div>
                                <div class="form-row mt-2">
                                    <div class="form-group col-md-4 mt-2">
                                        <label>Zipcode</label>
                                        <input type="text" class="form-control" placeholder="ZIPCODE" name="zipcode" id="postal_code" value="{{ $job->zipcode ?? '' }}">
                                    </div>
                                    <div class="form-group col-md-4 mt-2">
                                        <label>City</label>
                                        <input type="text" class="form-control" placeholder="City" name="city" id="locality" value="{{ $job->city ?? '' }}">
                                    </div>
                                    <div class="form-group col-md-4 mt-2">
                                        <label>State</label>
                                        <input type="text" class="form-control" placeholder="State" name="state" id="state" value="{{ $job->state ?? '' }}">
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-lg btn-primary updateJobButton" id="updateJobButton" value="update_job">Update Job</button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <div class="tab-pane fade show {{ $job->job_type_id == '' ? 'active' : '' }}" id="Details" role="tabpanel" aria-labelledby="job-deatails">
            <section class="space-ptb">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="user-dashboard-info-box text-dark">
                                <fieldset>
                                    <div class="section-title-02 mb-4">
                                        <h4>Job Details</h4>
                                    </div>
                                    <div><b>Job Title:</b> <i>{{ $job->title }}</i></div>
                                    <div><b>Company Name:</b> <i>{{ auth()->user()->company->name }}</i></div>
                                    <div><b>Job Location:</b> <i>{{ $job->city }}, {{ $job->state }} {{ $job->country }}</i></div>
                                </fieldset>
                            </div>
                            <div class="user-dashboard-info-box">
                                <div class="section-title-02 mb-4">
                                    <h4>Basic Information</h4>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label>What type of job it is?</label>
                                        <select class="form-control" name="job_type">
                                            <option value="">Select Job Type</option>
                                            @foreach($jobTypes as $jobType)
                                            <option value="{{$jobType->id}}" {{ $job->job_type_id == $jobType->id ? 'selected' : '' }}>{{ ucwords($jobType->name) }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="d-block mb-3">What contract type is it?</label>
                                        <div class="row">
                                            @php

                                            $contractIds = [];
                                            foreach($job->contractTypes as $contract){
                                            $contractIds[] = $contract->id;
                                            }
                                            @endphp

                                            @foreach($contractTypes as $contractType)
                                            <div class="custom-control col-md-3 pr-1">
                                                <input type="checkbox" id="{{str_slug($contractType->name)}}" name="contract_type[]" class="" value="{{ $contractType->id }}" {{ in_array($contractType->id, $contractIds) ? 'checked' : '' }}>
                                                <label class="" for="{{str_slug($contractType->name)}}">&nbsp;{{ucfirst($contractType->name)}}</label>
                                            </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="user-dashboard-info-box">
                                <div class="section-title-02 mb-4">
                                    <h4>Salary is the key feature for the job seekers!</h4>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-4">
                                        <label>Salary From (INR)</label>
                                        <input type="text" class="form-control" name="salary_from" placeholder="Example: 8,000" value="{{ $job->salary_from }}">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label>Salary To (INR)</label>
                                        <input type="text" class="form-control" name="salary_to" placeholder="Example: 15,000" value="{{ $job->salary_to }}">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label>What is payment type?</label>
                                        <select class="form-control" name="payment_type">
                                            @foreach($paymentTypes as $paymentType)
                                            <option value="{{$paymentType->id}}" {{ $paymentType->id == $job->payment_type_id ? 'selected' : '' }}>
                                                {{ ucwords($paymentType->name) }}
                                            </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label>How many hires do you want to make for this position?</label>
                                        <input type="number" class="form-control" name="positions" placeholder="" value="{{ $job->positions ?? '1' }}">
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-lg btn-primary updateJobButton" id="updateJobButton" value="updateDetails">Update Details</button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <div class="tab-pane fade show {{ $job->job_type_id != ''  ? 'active' : '' }}" id="Confirm" role="tabpanel" aria-labelledby="confirm">
            <input type="hidden" name="status" value="pending" id="status">
            <section class="space-ptb">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="user-dashboard-info-box bg-light-gray">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="job-list border">
                                            <div class=" job-list-logo">
                                                @php
                                                $logo = auth()->user()->getFirstMediaUrl('profiles', 'logo');
                                                if($logo == ''){
                                                $logo = asset('company.png');
                                                }
                                                @endphp
                                                <img class="img-fluid" src="{{ $logo }}" alt="">
                                            </div>
                                            <div class="job-list-details">
                                                <div class="job-list-info">
                                                    <div class="job-list-title">
                                                        <h5 class="mb-0">{{ $job->title }}</h5>
                                                    </div>
                                                    <div class="job-list-option">
                                                        <ul class="list-unstyled">
                                                            <li><i class="fas fa-map-marker-alt pr-1"></i>
                                                                {{ auth()->user()->company->city }}, {{ auth()->user()->company->state }}({{ auth()->user()->company->country }})</li>
                                                            <li><i class="fas fa-phone fa-flip-horizontal fa-fw"></i><span class="pl-2">+91 {{ auth()->user()->mobile }}</span></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="job-list-favourite-time">
                                                <a class="job-list-favourite order-2 disabled" data-toggle="popover" data-trigger="click" data-placement="bottom" data-content="For employees only" href="javascript:void(0)"><i class="far fa-heart"></i></a>
                                                <span class="job-list-time order-1"><i class="far fa-clock pr-1"></i>{{ ucwords($job->created_at->diffForHumans()) }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="border p-4 mt-4 mt-lg-5">
                                    <div class="row">
                                        <div class="col-md-6 col-sm-6 mb-4">
                                            <div class="d-flex">
                                                <i class="font-xll text-primary align-self-center flaticon-debit-card"></i>
                                                <div class="feature-info-content pl-3">
                                                    <label class="mb-1">Offered Salary</label>

                                                    <span class="mb-0 font-weight-bold d-block text-dark">
                                                        @if($job->salary_from)
                                                        ₹ {{ number_format($job->salary_from, 2) }} <i> - </i> ₹ {{ number_format($job->salary_to, 2) ?? ''}}
                                                        @else
                                                        Not Spacified
                                                        @endif
                                                    </span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-6 mb-4">
                                            <div class="d-flex">
                                                <i class="font-xll text-primary align-self-center flaticon-bar-chart"></i>
                                                <div class="feature-info-content pl-3">
                                                    <label class="mb-1">Job Type</label>
                                                    <span class="mb-0 font-weight-bold d-block text-dark">{{ $job->jobType->name ?? '' }}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-6 mb-md-0 mb-4">
                                            <div class="d-flex">
                                                <i class="font-xll text-primary align-self-center flaticon-apartment"></i>
                                                <div class="feature-info-content pl-3">
                                                    <label class="mb-1">Industry</label>
                                                    <span class="mb-0 font-weight-bold d-block text-dark">{{ $job->category->name ?? ''}}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-6 mb-sm-0 mb-4">
                                            <div class="d-flex">
                                                <i class="font-xll text-primary align-self-center flaticon-medal"></i>
                                                <div class="feature-info-content pl-3">
                                                    <label class="mb-1">Positions</label>
                                                    <span class="mb-0 font-weight-bold d-block text-dark">{{ $job->positions ?? '' }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="my-4 my-lg-5">
                                    <h5 class="mb-3 mb-md-4">Job Description</h5>
                                    {!! $job->description !!}
                                </div>
                                <hr />
                                <div class="my-4 my-lg-5">
                                    <h5 class="mb-3 mb-md-4">Job Contract Type</h5>
                                    <ul class="list-unstyled list-style">
                                        @forelse($job->contractTypes as $contractList)
                                        <li class="text-capitalize">
                                            <i class="far fa-check-circle font-md text-primary mr-2 text-capitalize"></i>
                                            {{ $contractList->name }}
                                        </li>
                                        @empty
                                        <li class="text-capitalize">
                                            Not Specified
                                        </li>
                                        @endforelse
                                    </ul>
                                </div>
                                <hr />
                                <a class="btn btn-secondary btn-block" data-toggle="popover" data-trigger="click" data-placement="top" data-content="For employees only" href="javascript:void(0)"><i class="far fa-paper-plane"></i> Apply Now</a>
                            </div>
                            <a class="btn btn-primary btn-block" data-toggle="popover" data-trigger="hover" data-placement="top" data-content="Publish This Job" href="javascript:void(0)" onclick="changeTab('package')">Publish Job</a>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        {{-- <div class="tab-pane fade show {{ $job->status == 'confirm'  ? 'active' : '' }}" id="package-details" role="tabpanel" aria-labelledby="package">
        <section class="space-ptb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="user-dashboard-info-box">
                            <div class="section-title-02 mb-3">
                                <h4>Job Location</h4>
                            </div>
                            <div class="form-row mt-2">
                                <div class="form-group col-md-4 mt-2">
                                    <label>Amount</label>
                                    <input type="number" class="form-control" name="value" id="" min="5" step="0.01" value="{{ mt_rand(500, 10000) / 100 }}">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div> --}}
    </div>
</form>
@endsection
@section('css-hooks')
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="{{ asset('assets/richtext/richtext.min.css') }}">
@endsection
@section('js-hooks')
<script type="text/javascript" src="{{ asset('assets/richtext/jquery.richtext.js') }}"></script>
@endsection
@section('custom-scripts')
<script>
    $(document).ready(function() {
        $('#updateJobPost').submit(function(e) {
            e.preventDefault();
            let jobStatus = '{{ $job->status }}';
            let JobUpdateUrl = "{{ route('jobs.update', ':jobId') }}"
            JobUpdateUrl = JobUpdateUrl.replace(':jobId', '{{ $job->id }}');
            $.ajax({
                url: JobUpdateUrl,
                method: 'POST',
                beforeSend: function() {
                    $('.updateJobButton').attr('disabled', true);
                    $('.updateJobButton').text('Loading...');
                },
                data: $('#updateJobPost').serialize(),

                success: function(data) {
                    if (jobStatus == 'pending') {
                        toastr["success"]("One more step away to get your job live.", "Job Updated!");
                        window.location.reload();
                    } else {
                        toastr["success"]("Your post is published now!", "Job Published!");
                        window.location.replace('{{ route("jobs.index") }}');
                    }
                },
                error: function(xhr) {
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors);
                },
                complete: function() {
                    $('.updateJobButton').attr('disabled', false);
                    $('.updateJobButton').text('Update Details');
                }
            });
        });
        $('#description').richText({
            // text formatting
            bold: true,
            italic: true,
            underline: true,
            // text alignment
            leftAlign: false,
            centerAlign: false,
            rightAlign: false,
            justify: false,
            // lists
            ol: true,
            ul: true,
            // title
            heading: false,
            // fonts
            fonts: false,
            fontColor: false,
            fontSize: false,
            // uploads
            imageUpload: false,
            fileUpload: false,
            // media
            videoEmbed: false,
            // link
            urls: false,
            // tables
            table: false,
            // code
            removeStyles: false,
            code: false,
            // colors
            colors: [],
            // dropdowns
            fileHTML: '',
            imageHTML: '',
            // privacy
            youtubeCookies: false,
            // developer settings
            useSingleQuotes: false,
            height: 0,
            heightPercentage: 0,
            id: "",
            class: "",
            useParagraph: false,
            maxlength: 0,
            callback: undefined
        });
    });

    function changeTab(id) {
        $('#status').val('active');
        $('#' + id).trigger('click');
        $('#updateJobButton').trigger('click');
    }

    function initializeAutocomplete(formId) {
        $("#" + formId + " [name='category']").autocomplete({
            source: function(request, response) {
                $.ajax({
                    url: "{{ route('category.index') }}",
                    type: 'GET',
                    dataType: "JSON",
                    data: {
                        term: request.term
                    },
                    success: function(data) {
                        if (data.length > 0) {
                            response(data);
                        } else {
                            $("#" + formId + " [name='category_id']").val(0);
                        }
                    }
                });
            },
            minLength: 2,
            appendTo: $('#' + formId),
            select: function(event, ui) {
                $("#" + formId + " [name='category_id']").val(ui.item.id);
            }
        });
    }
    initializeAutocomplete('updateJobPost');
</script>
@endsection