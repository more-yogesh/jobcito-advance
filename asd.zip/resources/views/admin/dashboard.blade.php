@extends('layouts.app')

@section('content')
@include('admin.includes.header')
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row mb-3 mb-lg-5 mt-3 mt-lg-0">
                    <div class="col-lg-4 mb-4 mb-lg-0">
                        <div class="candidates-feature-info bg-dark">
                            <div class="candidates-info-icon text-white">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="candidates-info-content">
                                <h6 class="candidates-info-title text-white">Todays Employee Reg. </h6>
                            </div>
                            <div class="candidates-info-count">
                                <h3 class="mb-0 text-white">{{ $todaysTotalEmployee ?? 0 }}</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4 mb-lg-0">
                        <div class="candidates-feature-info bg-dark">
                            <div class="candidates-info-icon text-white">
                                <i class="fas fa-building"></i>
                            </div>
                            <div class="candidates-info-content">
                                <h6 class="candidates-info-title text-white">Total Company</h6>
                            </div>
                            <div class="candidates-info-count">
                                <h3 class="mb-0 text-white">{{ $totalCompanies ?? 0 }}</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4 mb-lg-0">
                        <div class="candidates-feature-info bg-success">
                            <div class="candidates-info-icon text-white">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <div class="candidates-info-content">
                                <h6 class="candidates-info-title text-white">Total Employee</h6>
                            </div>
                            <div class="candidates-info-count">
                                <h3 class="mb-0 text-white">{{ $totalEmployees ?? 0 }}</h3>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 mt-4 mb-4 mb-lg-0">
                        <div class="candidates-feature-info bg-success">
                            <div class="candidates-info-icon text-white">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <div class="candidates-info-content">
                                <h6 class="candidates-info-title text-white">Direct Apply</h6>
                            </div>
                            <div class="candidates-info-count">
                                <h3 class="mb-0 text-white">{{ $directApplies ?? 0 }}</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4 mt-4 mb-lg-0">
                        <div class="candidates-feature-info bg-primary">
                            <div class="candidates-info-icon text-white">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="candidates-info-content">
                                <h6 class="candidates-info-title text-white">Total Pending Jobs</h6>
                            </div>
                            <div class="candidates-info-count">
                                <h3 class="mb-0 text-white">{{ $totalPendingJobs ?? 0 }}</h3>
                            </div>
                        </div>
                    </div>
                   
                    <div class="col-lg-4 mb-4 mt-4 mb-lg-0">
                        <div class="candidates-feature-info bg-success">
                            <div class="candidates-info-icon text-white">
                                <i class="fas fa-check"></i>
                            </div>
                            <div class="candidates-info-content">
                                <h6 class="candidates-info-title text-white">Total Active Jobs</h6>
                            </div>
                            <div class="candidates-info-count">
                                <h3 class="mb-0 text-white">{{ $totalActiveJobs ?? 0 }}</h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="user-dashboard-info-box mb-0 pb-4">
                    <div class="section-title">
                        <h4>Recent Jobs</h4>
                    </div>
                    <div class="row">
                        @forelse ($recentJobs as $job)
                        <div class="col-12">
                            <div class="job-list ">
                                <div class="job-list-logo">
                                    <div class="img-fluid">
                                        <h1>0{{ $loop->iteration }}</h1>
                                    </div>
                                </div>
                                <div class="job-list-details">
                                    <div class="job-list-info">
                                        <div class="job-list-title">
                                            <h5 class="mb-0"><a href="{{ route('showJob', $job->jobSlug()) }}">{{ $job->title }}</a></h5>
                                        </div>
                                        <div class="job-list-option">
                                            <ul class="list-unstyled">
                                                <li><i class="fas fa-map-marker-alt pr-1"></i>{{ $job->city }}, {{ $job->state }}</li>
                                                <li><i class="fas fa-filter pr-1"></i>{{ $job->category->name ?? 'Not Specified' }}</li>
                                                <li><a class="freelance text-capitalize" href="javascript:void(0)"><i class="fas fa-suitcase pr-1"></i>{{ $job->jobType->name }}</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="job-list-favourite-time"> <span class="job-list-time order-1"><i class="far fa-clock pr-1"></i>{{ $job->created_at->diffForHumans() }}</span> </div>
                            </div>
                        </div>
                        @empty
                        <div class="col-12 text-center">
                            <h5>No Jobs Added!</h5>
                            <a class="btn btn-dark" href="{{ route('jobs.create') }}">Post New Job Now</a>
                        </div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection