@extends('layouts.app')

@section('content')
<section class="position-relative">
    <div class="banner bg-holder bg-overlay-black-20 text-dark" style="background-image: url({{ asset('assets/images/bg/banner-02.jpg') }});">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-9 text-left">
                    <h1 class="text-dark">Find A Job at <span class="text-primary"> Surat's </span> No.1 Job Site</h1>
                    <p class="lead mb-4 mb-lg-5 font-weight-normal">Find Jobs, Employment & Career Opportunities</p>
                    <div class="job-search-field">
                        <div class="job-search-item">
                            <form class="form row" action="{{ route('search') }}" method="GET">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <div class="d-flex">
                                            <label>What</label>
                                        </div>
                                        <div class="position-relative left-icon">
                                            <input type="text" class="form-control" name="job" placeholder="Start typing your job title">
                                            <i class="fas fa-search"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <div class="d-flex">
                                            <label>Where</label>
                                        </div>
                                        <div class="position-relative left-icon">
                                            <input type="text" class="form-control location-input" name="location" placeholder="City or postcode">
                                            <i class="far fa-compass"></i>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-12">
                                    <div class="form-group form-action">
                                        <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-search"></i> Find Jobs</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <svg class="banner-shape" xmlns="http://www.w3.org/2000/svg" width="100%" height="100" viewBox="0 0 1920 100">
        <path class="cls-1" fill="#ffffff" d="M0,80S480,0,960,0s960,80,960,80v20H0V80Z" /></svg>
</section>
<section class="space-ptb">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="browse-job d-flex">
                    <h3 class="mb-3">Browse Jobs</h3>
                    <div class="justify-content-center flex-fill">
                        <ul class="nav nav-tabs nav-tabs-02 justify-content-center d-flex mb-3 mb-md-0" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Categories</a>
                            </li>
                        </ul>
                    </div>
                    <div class="job-found mb-3">
                        <span class="badge badge-lg badge-primary">{{ $jobsCount ?? 0 }}</span>
                        <h6 class="ml-3 mb-0">Job Found</h6>
                    </div>
                </div>
                <div class="tab-content">
                    <div class="tab-pane fade active show" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <div class="row mt-4 mt-md-5">
                            @foreach ($categories as $key => $category)
                            <div class="col-md-4 border-right mb-3 mb-md-0">
                                <div class="category-style-02">
                                    <ul class="list-unstyled mb-0">
                                        <li>
                                            <a href="{{ route('search') }}?category={{ str_slug($category->name) }}">
                                                <h6 class="category-title">{{ $category->name }}</h6> <span class="category-count">{{ mt_rand(300, 1350) }}</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="bg-light space-ptb overflow-hidden">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="section-title-02 text-center">
                    <h2>Clients Say About Us</h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-xl-5 col-lg-7">
                <div class="owl-carousel testimonial-center owl-nav-bottom-center" data-nav-arrow="false" data-items="1" data-md-items="1" data-sm-items="1" data-xs-items="1" data-xx-items="1" data-space="0" data-autoheight="true">
                    <div class="item">
                        <div class="testimonial-item-02">
                            <div class="testimonial-content">
                                <p><i class="fas fa-quote-left quotes"></i>The jobcito database has been one of our current sources for recruitment, backed by a very experienced team who would go out of their way to make sure that requests are taken ahead. </p>
                            </div>
                            <div class="testimonial-author">
                                <div class="testimonial-avatar avatar avatar-lg">
                                    <img class="img-fluid rounded-circle" src="{{ asset('assets/images/avatar/01.jpg') }}" alt="">
                                </div>
                                <div class="testimonial-name">
                                    <h6 class="mb-1">Sumit Jain</h6>
                                    <span>Recruitment Specialist</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonial-item-02">
                            <div class="testimonial-content">
                                <p><i class="fas fa-quote-left quotes"></i>Portal is very user-friendly in terms of searching for resumes and job postings. Also, they have an excellent database to search for resumes. As far as services are involved, it's terrific! </p>
                            </div>
                            <div class="testimonial-author">
                                <div class="testimonial-avatar avatar avatar-lg">
                                    <img class="img-fluid rounded-circle" src="{{ asset('assets/images/avatar/2.jpg') }}" alt="">
                                </div>
                                <div class="testimonial-name">
                                    <h6 class="mb-1">Priyanka Mahajan</h6>
                                    <span>HR Specialist</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonial-item-02">
                            <div class="testimonial-content">
                                <p><i class="fas fa-quote-left quotes"></i>Jobcito is an excellent job portal. We value the resumes received through this channel. Magic Search and Power search are handy tools. We are delighted with their service.</p>
                            </div>
                            <div class="testimonial-author">
                                <div class="testimonial-avatar avatar avatar-lg">
                                    <img class="img-fluid rounded-circle" src="{{ asset('assets/images/avatar/04.jpg') }}" alt="">
                                </div>
                                <div class="testimonial-name">
                                    <h6 class="mb-1">Rushi Patel</h6>
                                    <span>Product Designer</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="space-ptb">
    <div class="container">
        <div class="row align-self-center">
            <div class="col-xl-7 col-lg-6 col-md-12">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="section-title-02">
                            <h2>Why You Choose Job Among Other Job Site?</h2>
                        </div>
                    </div>
                </div>
                <div class="align-self-center">
                    <div class="row">
                        <div class="col-lg-6 col-sm-6">
                            <div class="feature-info mb-4">
                                <div class="feature-info-icon mb-3">
                                    <i class="flaticon-team"></i>
                                </div>
                                <div class="feature-info-content">
                                    <h5 class="text-black mb-3">Best talented people</h5>
                                    <p>We provide certified and filtered resources to the clients for better quality services.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="feature-info mb-4">
                                <div class="feature-info-icon mb-3">
                                    <i class="flaticon-chat"></i>
                                </div>
                                <div class="feature-info-content">
                                    <h5 class="text-black mb-3">Easy to communicate</h5>
                                    <p>We are just a call away to help you! Feel free to call us we'll love to help you.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="feature-info mb-lg-0 mb-4">
                                <div class="feature-info-icon mb-3">
                                    <i class="flaticon-job-3"></i>
                                </div>
                                <div class="feature-info-content">
                                    <h5 class="text-black mb-3">Easy to find the candidate</h5>
                                    <p>We allow companies to find the best suitable resources in jobcito as per their needs.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="feature-info mb-lg-0 mb-4">
                                <div class="feature-info-icon mb-3">
                                    <i class="flaticon-job-2"></i>
                                </div>
                                <div class="feature-info-content">
                                    <h5 class="text-black mb-3">Global recruitment option</h5>
                                    <p>Yes, We provide global recruitment services to our NRI clients too.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-lg-6 col-md-12">
                <div>
                    <img class="img-fluid rounded" src="{{ asset('assets/images/about/about-09.jpg') }}" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
@endsection