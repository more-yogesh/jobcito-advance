@extends('layouts.app')
@section('content')
<div class="header-inner bg-light text-center">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="text-primary">Privacy Policy</h1>
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}"> Home </a></li>
                    <li class="breadcrumb-item active"> <i class="fas fa-chevron-right"></i> <span> Privacy Policy </span></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<section class="space-ptb" style="background-image: url(images/google-map.png); background-position: center center; background-repeat: no-repeat;">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2 class="mb-4">Privacy Policy JobCito.com</h2>
            </div>
            <div class="col-lg-10">
                <div>
                    <p class="mb-lg-2 mb-2 ">
                        At JobCito, accessible from https://jobcito.com/, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that are collected and recorded by JobCito and how we use it. If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us through email at info@jobcito.com
                    </p>
                    <h5>Log Files</h5>
                    <p class="mb-lg-2 mb-2 ">
                        Job Cito follows a standard procedure of using log files. These files log visitors when they visit websites.
                        <br/>
                        All hosting companies do this and a part of hosting services’ analytics. The information collected by log files includes internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks. These are not linked to any personally identifiable information. The purpose of the information is for analyzing trends, administering the site, tracking users’ movement on the website, and gathering demographic information.    
                    </p>
                    <h5>Privacy Policies</h5>
                    <p class="mb-lg-2 mb-2 ">                        
                        Third-party ad servers or ad networks uses technologies like cookies, JavaScript, or Web Beacons that are used in their respective advertisements and links that appear on Job Cito, which are sent directly to users’ browser. They automatically receive your IP address when this occurs. These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on websites that you visit.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection