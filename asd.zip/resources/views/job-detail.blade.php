@extends('layouts.app')
@section('content')
@php
$logo = $job->user->getFirstMediaUrl('profiles', 'logo');
if($logo == ''){
$logo = asset('company.png');
}
@endphp

<section class="space-ptb">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-md-12">
                        <div class="job-list border">
                            <div class=" job-list-logo">
                                <img class="img-fluid" src="{{ $logo }}" alt="{{ $job->user->company->name }}">
                            </div>
                            <div class="job-list-details">
                                <div class="job-list-info">
                                    <div class="job-list-title">
                                        <h5 class="mb-0">{{ $job->title }}</h5>
                                    </div>
                                    <div class="job-list-option">
                                        <ul class="list-unstyled">
                                            <li><i class="fas fa-map-marker-alt pr-1"></i>{{ $job->city }}, {{ $job->state }}</li>
                                            <li><i class="fas fa-phone fa-flip-horizontal fa-fw"></i><span class="pl-2">(+91) 98251 XXXXX</span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="job-list-favourite-time" id="favoriteArea-{{$job->id}}">
                                @role('employee')
                                @if($job->favorited())
                                <a class="job-list-favourite order-2" href="javascript:void(0)" onclick="removeFavourite({{$job->id}})"><i class="fa fa-heart text-danger" id="favorite-{{$job->id}}"></i></a>
                                @else
                                <a class="job-list-favourite order-2" href="javascript:void(0)" onclick="addFavourite({{$job->id}})"><i class="far fa-heart" id="favorite-{{$job->id}}"></i></a>
                                @endif
                                @endrole
                                @guest
                                <a class="job-list-favourite order-2" href="javascript:void(0)" data-toggle="modal" data-target="#loginModalCenter"><i class="far fa-heart"></i></a>
                                @endguest
                                <span class="job-list-time order-1"><i class="far fa-clock pr-1"></i>{{ $job->created_at->diffForHumans() }}</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="border p-4 mt-4 mt-lg-5">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 mb-4">
                            <div class="d-flex">
                                <i class="font-xll text-primary align-self-center flaticon-debit-card"></i>
                                <div class="feature-info-content pl-3">
                                    <label class="mb-1">Offered Salary</label>
                                    <span class="mb-0 font-weight-bold d-block text-dark">
                                        @if($job->salary_from)
                                            ₹ {{ number_format($job->salary_from) }} <i> - </i> ₹ {{ number_format($job->salary_to) ?? ''}}
                                        @else
                                            Not Spacified
                                        @endif
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 mb-4">
                            <div class="d-flex">
                                <i class="font-xll text-primary align-self-center flaticon-bar-chart"></i>
                                <div class="feature-info-content pl-3">
                                    <label class="mb-1">Job Type</label>
                                    <span class="mb-0 font-weight-bold d-block text-dark">{{ $job->jobType->name ?? '' }}</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 mb-md-0 mb-4">
                            <div class="d-flex">
                                <i class="font-xll text-primary align-self-center flaticon-apartment"></i>
                                <div class="feature-info-content pl-3">
                                    <label class="mb-1">Industry</label>
                                    <span class="mb-0 font-weight-bold d-block text-dark">{{ $job->category->name ?? ''}}</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 mb-sm-0 mb-4">
                            <div class="d-flex">
                                <i class="font-xll text-primary align-self-center flaticon-medal"></i>
                                <div class="feature-info-content pl-3">
                                    <label class="mb-1">Positions</label>
                                    <span class="mb-0 font-weight-bold d-block text-dark">{{ $job->positions ?? '' }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="my-4 my-lg-5">
                    <h5 class="mb-3 mb-md-4">Job Description</h5>
                    {!! $job->description !!}
                </div>
                <hr />
                <div class="my-4 my-lg-5">
                    <h5 class="mb-3 mb-md-4">Job Contract Type</h5>
                    <ul class="list-unstyled list-style">
                        @forelse($job->contractTypes as $contractList)
                        <li class="text-capitalize">
                            <i class="far fa-check-circle font-md text-primary mr-2 text-capitalize"></i>
                            {{ $contractList->name }}
                        </li>
                        @empty
                        <li class="text-capitalize">
                            Not Specified
                        </li>
                        @endforelse
                    </ul>
                </div>
                <hr />
                <div class="jobAction mb-3">
                    @role('employee')
                    @if($job->applied())
                    <a class="btn btn-secondary btn-block" href="javascript:void(0)" onclick="removeJob({{ $job->id }})"><i class="fa fa-check"></i>
                        Applied
                    </a>
                    @else
                    <a class="btn btn-primary btn-block" href="javascript:void(0)" onclick="applyJob({{ $job->id }})"><i class="far fa-paper-plane"></i>
                        Apply Now
                    </a>
                    @endif
                    @endrole
                    @role('company')
                    <a class="btn btn-secondary btn-block" href="javascript:void(0)"><i class="fa fa-check"></i>
                        Apply Now(Employees Only)
                    </a>
                    @endrole

                    @guest
                    <a class="btn btn-primary btn-block" href="javascript:void(0)" data-toggle="modal" data-target="#loginModalCenter"><i class="far fa-paper-plane"></i>
                        Apply Now
                    </a>
                    @endguest
                </div>
            </div>
            <div class="col-lg-4">
                <div class="sidebar mb-0">
                    <div class="widget jobAction d-none d-lg-block ">
                        @role('employee')
                        @if($job->applied())
                        <a class="btn btn-secondary btn-block" href="javascript:void(0)" onclick="removeJob({{ $job->id }})"><i class="fa fa-check"></i>
                            Applied
                        </a>
                        @else
                        <a class="btn btn-primary btn-block" href="javascript:void(0)" onclick="applyJob({{ $job->id }})"><i class="far fa-paper-plane"></i>
                            Apply Now
                        </a>
                        @endif
                        @endrole
                        @role('company')
                        <a class="btn btn-secondary btn-block" href="javascript:void(0)"><i class="fa fa-check"></i>
                            Apply Now(Employees Only)
                        </a>
                        @endrole
                        @guest
                        <a class="btn btn-primary btn-block" href="javascript:void(0)" data-toggle="modal" data-target="#loginModalCenter"><i class="far fa-paper-plane"></i>
                            Apply Now
                        </a>
                        @endguest
                    </div>
                    <div class="widget ">
                        <div class="company-detail-meta">
                            <div class="widget">
                                <div class="widget-title">
                                    <h5>Share {{ $job->title }}</h5>
                                </div>
                                <div class="company-detail-meta justify-content-start">
                                    <a class="btn btn-sm m-1 btn-social btn-fb" href="https://www.facebook.com/sharer/sharer.php?u={{url()->current()}}" target="_blank" title="Share this job on Facebook">
                                        <i class="fab fa-facebook-square"></i> Share
                                    </a>
                                    <a class="btn btn-sm m-1 btn-social btn-tw" href="https://twitter.com/intent/tweet?text={{$job->title}}&amp;url={{url()->current()}}" target="_blank" title="Share this job on Twitter">
                                        <i class="fab fa-twitter"></i> Tweet
                                    </a>
                                    <a class="btn btn-sm m-1 btn-social btn-in" href="https://www.linkedin.com/shareArticle?mini=true&url={{url()->current()}}&amp;title={{$job->title}}" target="_blank" title="Share this job on LinkedIn">
                                        <i class="fab fa-linkedin-in" data-fa-transform="grow-2"></i> Share
                                    </a>
                                    <a class="btn btn-sm m-1 btn-success " target="_blank" href="whatsapp://send?text={{url()->current()}}" target="_blank" title="Share this job on LinkedIn">
                                        <i class="fab fa-whatsapp" data-fa-transform="grow-2"></i> Whatsapp
                                    </a>
                                    
                                    <div class=" widget mt-4 col-12">
                                        <div class="widget-title">
                                            <h5>Contact {{ $job->user->company->title ?? '' }}</h5>
                                        </div>
                                        <div class="company-contact-inner widget-box">
                                            <form id="contactCompanyForm" enctype="multipart/form-data">
                                                @csrf
                                            <input type="hidden" name="job_id" value="{{ $job->id }}">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" placeholder="Full name" name="name" required>
                                                </div>
                                                <div class="form-group">
                                                    <input type="email" class="form-control" placeholder="Email address" name="email">
                                                </div>
                                                <div class="form-group">
                                                    <input type="number" class="form-control" placeholder="Mobile" name="mobile" required>
                                                </div>
                                                <input type="hidden" name="subject" value="{{ $job->title ?? '' }}">
                                                <div class="form-group">
                                                    <textarea class="form-control" rows="3" placeholder="Message" name="message" ></textarea>
                                                </div>
                                                <button class="btn btn-primary btn-outline-primary btn-block" id="contactCompanyFormButton" type="submit">Direct Apply</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="widget">
                        <div class="widget-title">
                            <h5>Similar Jobs</h5>
                        </div>
                        <div class="similar-jobs-item widget-box">
                            @forelse($similarJobs as $similarJob)
                            @php
                            $similarJobLogo = $similarJob->user->getFirstMediaUrl('profiles', 'logo');
                            if($similarJobLogo == ''){
                            $similarJobLogo = asset('company.png');
                            }
                            @endphp
                            <div class="job-list">
                                <div class="job-list-logo">
                                    <img class="img-fluid" src="{{$similarJobLogo}}" alt="">
                                </div>
                                <div class="job-list-details">
                                    <div class="job-list-info">
                                        <div class="job-list-title">
                                            <h6><a href="{{ route('showJob', $similarJob->jobSlug()) }}">{{ $similarJob->title }}</a></h6>
                                        </div>
                                        <div class="job-list-option">
                                            <ul class="list-unstyled">
                                                <li>
                                                    <span>via</span>
                                                    <a href="{{ route('showCopmany', $job->companySlug()) }}">{{ $similarJob->user->company->name }}</a>
                                                </li>
                                                <li><a class="freelance" href="#"><i class="fas fa-suitcase pr-1"></i>Freelance</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @empty
                            <div class="job-list">
                                <h5 class="mx-auto">No similar Jobs Found</h5>
                            </div>
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
@section('custom-scripts')
<script>
    $(document).ready(function() {
        $('#contactCompanyForm').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('contact-us.store') }}",
                method: 'POST',
                beforeSend: function() {
                    $('#contactCompanyFormButton').attr('disabled', true);
                    $('#contactCompanyFormButton').text('Loading...');
                },
                data: $('#contactCompanyForm').serialize(),

                success: function(data) {
                    toastr["success"](data.success, "Message Sent!");
                    $('#contactCompanyForm')[0].reset();
                    $("textarea, input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                },
                error: function(xhr) {
                    toastr["error"]("Please check from details and try again", "Error!");
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors);
                },
                complete: function() {
                    $('#contactCompanyFormButton').attr('disabled', false);
                    $('#contactCompanyFormButton').text('Send your messaage');
                }

            });
        });
    });
</script>
<script type="application/ld+json">
    {
        "@context": "https://schema.org/",
        "@type": "JobPosting",
        "title": "{{ $job->title }}",
        "description": "{{ $job->description }}",
        "identifier": {
            "@type": "{{ $job->category->name }}",
            "name": "jobcito.com",
            "value": "{{ $job->zipcode }}-{{ $job->title }}"
        },
        "datePosted": "{{ $job->created_at->format('Y-m-d') }}",
        "validThrough": "{{ $job->expire_date ?? date('Y-m-d H:i:s', strtotime(" + 30 day ")) }}",
        "applicantLocationRequirements": {
            "@type": "City",
            "name": "India"
        },
        "jobLocationType": "TELECOMMUTE",
        "employmentType": "{{ $job->jobType->name }}",
        "hiringOrganization": {
            "@type": "Organization",
            "name": "Jobcito",
            "sameAs": "https://jobcito.com/",
            "logo": "https://jobcito.com/assets/images/logo.png"
        },
        "jobLocation": {
            "@type": "Place",
            "address": {
                "@type": "PostalAddress",
                "streetAddress": "-",
                "addressLocality": "Surat",
                "addressRegion": "{{ $job->city }}",
                "postalCode": "{{ $job->zipcode }}"
            }
        },
        "baseSalary": {
            "@type": "MonetaryAmount",
            "currency": "INR",
            "value": {
                "@type": "QuantitativeValue",
                "value": {{ $job->salary_to }},
                "unitText": "{{ ucwords($job->paymentType->name) }}"
            }
        }
    }
</script>
@endsection