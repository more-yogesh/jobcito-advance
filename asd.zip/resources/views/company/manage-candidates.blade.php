@extends('layouts.app')

@section('content')
@include('company.includes.header')
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-dashboard-info-box table-responsive pb-4 mb-0">
                    <div class="row mb-4">
                        <div class="col-md-7 col-sm-5 d-flex align-items-center">
                            <div class="section-title-02 mb-0 ">
                                <h4 class="mb-0">Manage Candidates</h4>
                            </div>
                        </div>
                    </div>
                    <table class="table table-bordered mb-0" id="example">
                        <thead class="bg-light">
                            <tr>
                                <th>Candidate Name</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($shortlisted as $shortlist)
                            @php
                            $employee = $shortlist->user;
                            $logo = $employee->getFirstMediaUrl('profiles', 'logo');
                            if($logo == ''){
                                $logo = asset('employee.png');
                            }
                            @endphp
                            <tr class="candidates-list">
                                <td class="title">
                                    <div class="thumb mx-2">
                                        <img class="img-fluid" src="{{ $logo }}" alt="">
                                    </div>
                                    <div class="candidate-list-details">
                                        <div class="candidate-list-info">
                                            <div class="candidate-list-title">
                                                <h5 class="mb-0 text-capitalize">{{ $employee->employee->name }}</h5>
                                            </div>
                                            <div class="candidate-list-option">
                                                <ul class="list-unstyled">
                                                    <li><i class="fas fa-filter pr-1"></i>
                                                        {{ $employee->category->name ?? 'No Specified' }}
                                                    </li>
                                                    <li><i class="fas fa-map-marker-alt pr-1"></i>
                                                        {{ $employee->city ?? 'Not Provided' }}, {{ $employee->state ?? 'Not Provided' }}
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="candidate-list-favourite-time text-center">
                                    <a href="javascript:void(0)" id="reject-{{ $shortlist->user->id }}" onclick="changeStatus({{ $shortlist->user->id }}, 'rejected')" class="btn btn-danger">
                                        <i class="fa fa-times"></i>
                                        Reject
                                    </a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
@endsection
@section('css-css-hooks')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" />
@endsection

@section('custom-scripts')
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
@endsection