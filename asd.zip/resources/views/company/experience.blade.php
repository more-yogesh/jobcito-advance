@extends('layouts.app')

@section('content')
@include('employee.includes.header')
<section>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="user-dashboard-info-box">
                    <div class="dashboard-resume-title d-flex align-items-center">
                        <div class="section-title-02 mb-sm-0">
                            <h4 class="mb-0">Work & Experience</h4>
                        </div>
                    </div>
                    <div class="collapse show" id="dateposted-05">
                        <div class="bg-light p-3 mt-4">
                            <form class="form-row" method="POST" id="addExperienceForm">
                                @csrf
                                <div class="form-group col-md-12">
                                    <label>Title</label>
                                    <input type="text" class="form-control" value="" name="title">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Company name</label>
                                    <input type="text" class="form-control" value="" name="company_name">
                                </div>
                                <div class="form-group col-md-6 datetimepickers">
                                    <label>From Date</label>
                                    <div class="input-group date" id="datetimepicker-01" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" value="" data-target="#datetimepicker-01" name="from_date">
                                        <div class="input-group-append" data-target="#datetimepicker-01" data-toggle="datetimepicker">
                                            <div class="input-group-text bg-white"><i class="far fa-calendar-alt"></i></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group col-md-6 datetimepickers">
                                    <label>To Date</label>
                                    <div class="input-group date" id="datetimepicker-02" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" value="" data-target="#datetimepicker-02" name="to_date">
                                        <div class="input-group-append" data-target="#datetimepicker-02" data-toggle="datetimepicker">
                                            <div class="input-group-text bg-white"><i class="far fa-calendar-alt"></i></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Description</label>
                                    <textarea class="form-control" rows="4" name="description"></textarea>
                                </div>
                                <div class="form-group col-md-12 mb-0">
                                    <button type="submit" class="btn btn-md btn-primary" id="addExperienceButton">Add Experience</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    @foreach($experiences as $experience)
                    <div class="jobber-candidate-timeline mt-4">
                        <div class="jobber-timeline-icon">
                            <i class="fas fa-briefcase"></i>
                        </div>
                        <div class="jobber-timeline-item">
                            <div class="jobber-timeline-cricle">
                                <i class="far fa-circle"></i>
                            </div>
                            <div class="jobber-timeline-info">
                                <div class="dashboard-timeline-info">
                                    <div class="dashboard-timeline-edit">
                                        <ul class="list-unstyled d-flex">
                                            <li><a class="text-right" href="javascript:void(0)" onclick="editExperience({{ $experience->id }})"> <i class="fas fa-pencil-alt text-info mr-2"></i> </a></li>
                                            <li><a href="javascript:void(0)" onclick="deleteExperience({{ $experience->id }})"><i class="far fa-trash-alt text-danger"></i></a></li>
                                        </ul>
                                    </div>
                                    @php
                                    $start_date = \Carbon\Carbon::parse($experience->from_date);
                                    $end_date = \Carbon\Carbon::parse($experience->to_date);
                                    $experienceMonths = $start_date->diffInMonths($end_date);
                                    @endphp
                                    <span class="jobber-timeline-time">{{ $experience->from_date->format('d M, Y') }} <b>To</b> {{ $experience->to_date->format('d M, Y') }} (<i>{{ $experienceMonths }} months of experience</i>)</span>
                                    <h6 class="mb-2">{{ $experience->title }}</h6>
                                    <span>- {{ $experience->company_name }}</span>
                                    <p class="mt-2">{{ $experience->description }}</p>
                                </div>

                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        <div class="modal fade" id="editExperienceModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header p-4">
                        <h4 class="mb-0 text-center">Change Education Details</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body mb-3">
                        <form class="form-row" method="POST" id="editExperienceForm">
                            @csrf
                            {{ method_field('PATCH') }}
                            <input type="hidden" name="id">
                            <div class="form-group col-md-12">
                                <label>Title</label>
                                <input type="text" class="form-control" value="" name="title">
                            </div>
                            <div class="form-group col-md-12">
                                <label>Company name</label>
                                <input type="text" class="form-control" value="" name="company_name">
                            </div>
                            <div class="form-group col-md-6 datetimepickers">
                                <label>From Date</label>
                                <div class="input-group date" id="datetimepicker-03" data-target-input="nearest">
                                    <input type="text" class="form-control datetimepicker-input" value="" data-target="#datetimepicker-03" name="from_date">
                                    <div class="input-group-append" data-target="#datetimepicker-03" data-toggle="datetimepicker">
                                        <div class="input-group-text bg-white"><i class="far fa-calendar-alt"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-6 datetimepickers">
                                <label>To Date</label>
                                <div class="input-group date" id="datetimepicker-04" data-target-input="nearest">
                                    <input type="text" class="form-control datetimepicker-input" value="" data-target="#datetimepicker-04" name="to_date">
                                    <div class="input-group-append" data-target="#datetimepicker-04" data-toggle="datetimepicker">
                                        <div class="input-group-text bg-white"><i class="far fa-calendar-alt"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <label>Description</label>
                                <textarea class="form-control" rows="4" name="description"></textarea>
                            </div>
                            <div class="form-group col-md-12 mb-0">
                                <button type="submit" class="btn btn-md btn-primary" id="updateExperienceButton">Update Experience</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</section>
@endsection
@section('js-hooks')
<script src="{{ asset('assets/js/select2/select2.full.js') }}"></script>
<script src="{{ asset('assets/js/datetimepicker/moment.min.js') }}"></script>
<script src="{{ asset('assets/js/datetimepicker/datetimepicker.min.js') }}"></script>
@endsection

@section('css-hooks')
<link rel="stylesheet" href="{{ asset('assets/css/datetimepicker/datetimepicker.min.css') }}" />
@endsection
@section('custom-scripts')
<script>
    function editExperience(experienceId) {
        var DataUrl = "{{ route('experience.show', ':argument') }}";
        DataUrl = DataUrl.replace(':argument', experienceId);
        $.ajax({
            url: DataUrl,
            method: 'GET',
            beforeSend: function() {
                $('#updateExperienceButton').attr('disabled', true);
                $('#updateExperienceButton').text('Loading...');
            },
            success: function(data) {

                $('#editExperienceForm [name="title"]').val(data.title);
                $('#editExperienceForm [name="company_name"]').val(data.company_name);
                $('#editExperienceForm [name="from_date"]').val(formatDate(data.from_date));
                $('#editExperienceForm [name="to_date"]').val(formatDate(data.to_date));
                $('#editExperienceForm [name="description"]').val(data.description);
                $('#editExperienceForm [name="id"]').val(data.id);
                $('#editExperienceModal').modal('show');
            },
            error: function(xhr) {
                $("input").removeClass("is-invalid");
                $(".invalid-feedback").remove();
                errors = xhr.responseJSON.errors;
                printErrorMsg(errors, 'editExperienceForm');
            },
            complete: function() {
                $('#updateExperienceButton').attr('disabled', false);
                $('#updateExperienceButton').text('Update Details');
            }
        });
    }

    function deleteExperience(experienceId) {
        if (confirm('Are you sure you want to delete it?')) {
            var DataUrl = "{{ route('experience.destroy', ':argument') }}";
            DataUrl = DataUrl.replace(':argument', experienceId);
            $.ajax({
                url: DataUrl,
                method: 'POST',
                beforeSend: function() {
                    // $('#addEducationButton').attr('disabled', true);
                    // $('#addEducationButton').text('Loading...');
                },
                data: {
                    id: experienceId,
                    _token: '{{ csrf_token() }}',
                    _method: 'DELETE'
                },
                success: function(data) {
                    toastr["success"]("Exprience deleted successfully.", "Education Deleted!");
                    location.reload();
                },
                complete: function() {
                    // $('#addEducationButton').attr('disabled', false);
                    // $('#addEducationButton').text('Add Education');
                }
            });
        }
    }
</script>
<script>
    $(document).ready(function() {
        $('#addExperienceForm').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('experience.store') }}",
                method: 'POST',
                beforeSend: function() {
                    $('#addExperienceButton').attr('disabled', true);
                    $('#addExperienceButton').text('Loading...');
                },
                data: $('#addExperienceForm').serialize(),
                success: function(data) {
                    toastr["success"]("Experience added successfully.", "Experience Added!");
                    location.reload();
                },
                error: function(xhr) {
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors, 'addExperienceForm');
                },
                complete: function() {
                    $('#addExperienceButton').attr('disabled', false);
                    $('#addExperienceButton').text('Add Experience');
                }
            });
        });
        $('#editExperienceForm').submit(function(e) {
            e.preventDefault();
            let experienceId = $('#editExperienceForm [name="id"]').val();
            var DataUrl = "{{ route('experience.update', ':argument') }}";
            DataUrl = DataUrl.replace(':argument', experienceId);
            $.ajax({
                url: DataUrl,
                method: 'POST',
                beforeSend: function() {
                    $('#updateExperienceButton').attr('disabled', true);
                    $('#updateExperienceButton').text('Loading...');
                },
                data: $('#editExperienceForm').serialize(),
                success: function(data) {
                    toastr["success"]("Experience updated successfully.", "Experience updated!");
                    location.reload();
                },
                error: function(xhr) {
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors, 'editExperienceForm');
                },
                complete: function() {
                    $('#updateExperienceButton').attr('disabled', false);
                    $('#updateExperienceButton').text('Update Details');
                }
            });
        });
    });
</script>
@endsection