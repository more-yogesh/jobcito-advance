@extends('layouts.app')

@section('content')
@include('company.includes.header')

<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-dashboard-info-box mb-0">
                    <div class="row mb-4">
                        <div class="col-md-7 col-sm-5 d-flex align-items-center">
                            <div class="section-title-02 mb-0 ">
                                <h4 class="mb-0">Manage Jobs</h4>
                            </div>
                        </div>

                    </div>
                    <div class="user-dashboard-table">
                        <table id="example" class="table table-striped table-bordered">
                            <thead class="bg-light">
                                <tr>
                                    <th scope="col">Job Title</th>
                                    <th scope="col">Applications</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($jobs as $job)
                                <tr>
                                    <th scope="row">{{ $loop->iteration }}. {{ $job->title }} (Positions: {{ $job->positions ?? 'Not Specified' }})
                                        <p class="mb-1 mt-2">Expiry: {{ isset($job->expiry) ? $job->expiry->format('d M, Y') : 'Pending' }}</p>
                                        <p class="mb-0">Address: Wellesley Rd, London</p>
                                    </th>
                                    <td>
                                        <a href="{{ route('candidates.edit', $job->id) }}" class="btn btn-primary btn-sm">
                                            Applied <span class="badge badge-light"> {{ $job->applications->count() }}</span>
                                        </a>
                                        <a href="#" class="btn btn-success btn-sm">
                                            Shortlisted <span class="badge badge-light">
                                                {{ $job->shortlisted->count() }}</span>
                                        </a>
                                    </td>
                                    <td>
                                        <span class="badge badge-{{ $job->status == 'active' ? 'success' : 'primary' }} p-2 text-uppercase">{{ $job->status }}</span>
                                    </td>
                                    <td>
                                        <ul class="list-unstyled mb-0 d-flex">
                                            <li><a href="#" class="text-primary" data-toggle="tooltip" title="view"><i class="far fa-eye"></i></a></li>
                                            <li><a href="{{ route('jobs.edit', $job->id) }}" class="text-info" data-toggle="tooltip" title="Edit"><i class="fas fa-pencil-alt"></i></a></li>

                                            <form action="{{ route('jobs.destroy', $job->id) }}" method="POST" onsubmit="return confirmDelete()">
                                                @csrf
                                                @method('DELETE')
                                                <button class="text-danger" data-toggle="tooltip" title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                            {{-- <li><a href="#" class="text-danger" data-toggle="tooltip" title="Delete"><i class="far fa-trash-alt"></i></a></li>
                                            <li><a href="#" class="text-danger" data-toggle="tooltip" title="Delete"><i class="far fa-trash-alt"></i></a></li> --}}
                                        </ul>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
@endsection
@section('css-css-hooks')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" />
@endsection


@section('custom-scripts')
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });

    function confirmDelete() {
        if (confirm('Are you sure you want to delete this post?')) {
            return true;
        }
        return false;
    }
</script>
@endsection