@extends('layouts.app')

@section('content')
@include('company.includes.header')
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form method="post" id="updateCompanyProfile">
                    @csrf
                    <div class="user-dashboard-info-box">
                        <div class="section-title-02 mb-4">
                            <h4>Basic Information</h4>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>Company Name</label>
                                <input type="text" class="form-control" value="{{ $profile->name ?? '' }}" name="name">
                            </div>
                            <div class="form-group col-md-6">
                                <label>Email</label>
                                <input type="email" class="form-control" value="{{ auth()->user()->email }}" name="email" readonly>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Contact Person Name</label>
                                <input type="text" class="form-control" value="{{ $profile->contact_person_name ?? '' }}" name="contact_person_name">
                            </div>
                            <div class="form-group col-md-6 datetimepickers">
                                <label>Date of Founded</label>
                                <div class="input-group date" id="datetimepicker-01" data-target-input="nearest">
                                    <input type="text" class="form-control datetimepicker-input" value="{{ $profile->date_found ?? '' }}" data-target="#datetimepicker-01" name="date_found">
                                    <div class="input-group-append" data-target="#datetimepicker-01" data-toggle="datetimepicker">
                                        <div class="input-group-text"><i class="far fa-calendar-alt"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Mobile (Contact)</label>
                                <input type="text" class="form-control" value="{{ auth()->user()->mobile }}" name="mobile">
                            </div>
                            <div class="form-group col-md-6">
                                <label>Website</label>
                                <input type="text" class="form-control" value="{{ $profile->website }}" name="website">
                            </div>
                            <div class="form-group col-md-12 mb-0">
                                <label>Description</label>
                                <textarea class="form-control" rows="5" placeholder="Use a past defeat as a motivator. Remind yourself you have nowhere to go except up as you have already been at the bottom" name="description">{{ $profile->description ?? '' }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="user-dashboard-info-box">
                        <div class="section-title-02 mb-3">
                            <h4>Address</h4>
                        </div>
                        <div class="form-row">
                            <div class="form-group mb-0 col-md-12">
                                <label>Enter Your Location</label>
                                <input type="text" class="form-control" id="autocomplete" placeholder="Enter your address" onchange="geolocate()" name="street_address_search" value="{{ $profile->street_address_search }}">
                            </div>
                        </div>
                        <div class="form-row mt-2">
                            <div class="form-group mb-0 col-md-2">
                                <label>Flat(House)</label>
                                <input type="text" class="form-control" name="house_no" id="street_number" value="{{ $profile->house_no }}">
                            </div>
                            <div class="form-group mb-0 col-md-10">
                                <label>Street Address</label>
                                <input type="text" class="form-control" name="street_address" id="route" value="{{ $profile->street_address }}">
                            </div>
                            <div class="form-group col-md-4 mt-2">
                                <label>Zipcode</label>
                                <input type="text" class="form-control" placeholder="ZIPCODE" name="zipcode" id="postal_code" value="{{ $profile->zipcode }}">
                            </div>

                            <div class="form-group col-md-4 mt-2">
                                <label>City</label>
                                <input type="text" class="form-control" placeholder="City" name="city" id="locality" value="{{ $profile->city }}">
                            </div>

                            <div class="form-group col-md-4 mt-2">
                                <label>State</label>
                                <input type="text" class="form-control" placeholder="State" name="state" id="administrative_area_level_1" value="{{ $profile->state }}">
                                <input type="hidden" name="country" id="country" value="{{ $profile->country }}">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-lg btn-primary" id="updateCompanyProfileButton">Update Profile</button>
                </form>
            </div>
        </div>
    </div>
</section>
@endsection

@section('js-hooks')
<script src="{{ asset('assets/js/datetimepicker/moment.min.js') }}"></script>
<script src="{{ asset('assets/js/datetimepicker/datetimepicker.min.js') }}"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC4NPCCrBZ1TsbpYntb_AIHaNE180bQTcQ&libraries=places&callback=initAutocomplete" async defer></script>
<script>
    var placeSearch, autocomplete;
    var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'long_name',
        country: 'long_name',
        postal_code: 'short_name',
    };

    function initAutocomplete() {
        // Create the autocomplete object, restricting the search predictions to
        // geographical location types.
        autocomplete = new google.maps.places.Autocomplete(
            document.getElementById('autocomplete'), {
                types: ['geocode']
            });

        // Avoid paying for data that you don't need by restricting the set of
        // place fields that are returned to just the address components.
        autocomplete.setFields(['address_component']);

        // When the user selects an address from the drop-down, populate the
        // address fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
    }

    function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        for (var component in componentForm) {
            document.getElementById(component).value = '';
            document.getElementById(component).disabled = false;
        }

        // Get each component of the address from the place details,
        // and then fill-in the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
            var addressType = place.address_components[i].types[0];
            if (componentForm[addressType]) {
                var val = place.address_components[i][componentForm[addressType]];
                document.getElementById(addressType).value = val;
            }
        }
    }

    function geolocate() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                var geolocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                var circle = new google.maps.Circle({
                    center: geolocation,
                    radius: position.coords.accuracy
                });
                autocomplete.setBounds(circle.getBounds());
            });
        }
    }
</script>
@endsection

@section('css-hooks')
<link rel="stylesheet" href="{{ asset('assets/css/datetimepicker/datetimepicker.min.css') }}" />
@endsection

@section('custom-scripts')
<script>
    $(document).ready(function() {
        $('#updateCompanyProfile').submit(function(e) {
            e.preventDefault();
            $.ajax({
            url: "{{ route('company.post.profile') }}",
                method: 'POST',
                beforeSend: function() {
                    $('#updateCompanyProfileButton').attr('disabled', true);
                    $('#updateCompanyProfileButton').text('Loading...');
                },
                data: $('#updateCompanyProfile').serialize(),

                success: function(data) {
                    toastr["success"]("Profile is updated successfully.", "Profile Updated!");
                },
                error: function(xhr) {
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors);
                },
                complete: function() {
                    $('#updateCompanyProfileButton').attr('disabled', false);
                    $('#updateCompanyProfileButton').text('Update Profile');
                }

            });
        });
    });
</script>
@endsection