@php
$logo = auth()->user()->getFirstMediaUrl('profiles', 'logo');
if($logo == ''){
$logo = asset('company.png');
}
@endphp
<div class="header-inner bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="candidates-user-info">
                    <div class="jobber-user-info">
                        <div class="profile-avatar">
                            <form method="POST" enctype="multipart/form-data" id="profileImage" action="{{ route('company.image') }}">
                                @csrf
                                <img class="img-fluid " src="{{ $logo }}" alt="Logo">
                                <label for="profile">
                                    <i class="fas fa-pencil-alt"></i>
                                    <input type="file" name="profile" id="profile" class="d-none" onchange="document.getElementById('profileImage').submit();" accept="image/png, image/jpeg, image/jpg">
                                </label>
                            </form>
                        </div>
                        <div class="profile-avatar-info ml-4">
                            <h3 class="text-capitalize">{{ auth()->user()->company->name ?? 'Not Specified' }}</h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="progress">
                    @php
                    $percentage = auth()->user()->companyPercentage();
                    @endphp
                    <div class="progress-bar {{ $percentage == 100 ? 'bg-success' : 'bg-danger' }}" role="progressbar" style="width:{{ $percentage }}%" aria-valuenow="{{ $percentage }}" aria-valuemin="0" aria-valuemax="100">
                        <span class="progress-bar-number">{{ $percentage }}%</span>
                    </div>
                </div>
                <div class="candidates-skills">
                    <div class="candidates-skills-info">
                        <h3 class="{{ $percentage == 100 ? 'text-success' : 'text-danger' }}">{{ $percentage }}%</h3>
                        <span class="d-block {{ $percentage == 100 ? 'text-success' : 'text-danger' }}">{{ $percentage == 100 ? 'Your profile is complete and ready to fly' : 'Please complete you profile' }}!</span>
                    </div>
                    <div class="candidates-required-skills ml-auto mt-sm-0 mt-3">
                        <a class="btn btn-dark" href="{{ route('jobs.create') }}">Post New Job</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="sticky-top secondary-menu-sticky-top">
                    <div class="secondary-menu">
                        <ul class="list-unstyled mb-0">
                            <li><a class="{{ Route::currentRouteNamed('company.dashboard') ? 'active' : '' }}" href="{{ route('company.dashboard') }}">Dashboard</a></li>
                            <li><a class="{{ Route::currentRouteNamed('company.profile') ? 'active' : '' }}" href="{{ route('company.profile') }}">My Profile</a></li>
                            <li><a class="{{ Route::currentRouteNamed('jobs.index') || Route::currentRouteNamed('candidates.edit') ? 'active' : '' }}" href="{{ route('jobs.index') }}">Manage Jobs</a></li>
                            <li><a class="{{ Route::currentRouteNamed('candidates.index')  ? 'active' : '' }}" href="{{ route('candidates.index') }}">Manage Candidates</a></li>
                            <li><a class="{{ Route::currentRouteNamed('company.change.password') ? 'active' : '' }}" href="{{ route('company.change.password') }}">Change Password</a></li>
                            <li><a class="{{ Route::currentRouteNamed('notifications') ? 'active' : '' }}" href="{{ route('notifications') }}">Notifications &nbsp;<span class="badge badge-danger"> {{ auth()->user()->unreadNotifications->count() }}</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>