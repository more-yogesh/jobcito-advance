@extends('layouts.app')

@section('content')
@role('company')
@include('company.includes.header')
@endrole
@role('employee')
@include('employee.includes.header')
@endrole
@role('admin')
@include('admin.includes.header')
@endrole
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-dashboard-info-box table-responsive pb-4 mb-0">
                    <div class="section-title">
                        <h6>
                            Notifications <a href="javascript:void(0)" onclick="sendMarkRequest('', 'all')" class="btn btn-danger btn-sm float-right">Mark all as read</a>
                        </h6>
                        <hr />
                    </div>
                    @forelse($notifications as $notification)
                    <div class="col-12">
                        <div class="job-list ">
                            <div class="job-list-details">
                                <div class="job-list-info">
                                    <div class="job-list-title">
                                        <h6 class="mb-0">{{ $notification->data['title'] }} <small><a href="javascript:void(0)" class="badge badge-primary" id="notification-{{ $notification->id }}" data-toggle="tooltip" title="Mark as read" data-original-title="Mark as read" onclick="sendMarkRequest('{{ $notification->id }}')"><i class="fa fa-check"></i></a></small></h6>
                                    </div>
                                    <p>{{ $notification->data['message'] }}</p>
                                </div>
                                <div class="job-list-favourite-time"> <span class="job-list-time order-1"><i class="far fa-clock pr-1"></i>{{ $notification->created_at->diffForHumans() }}</span> </div>
                            </div>
                        </div>
                    </div>
                    @empty
                    <div class="col-12">
                        <div class="job-list ">
                            <div class="job-list-details">
                                <div class="job-list-info">
                                    <div class="job-list-title">
                                        No new notifications
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    @endforelse
                    <div class="row">
                        <div class="col-12 text-center mt-3 mb-4 mt-sm-3">
                            {{ $notifications->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection

@push('scripts')
<script>
    function sendMarkRequest(id = null, type = "single") {
        $.ajax({
            url: "{{ route('notificationStatus') }}",
            method: 'POST',
            data: {
                _token: "{{ csrf_token() }}",
                id: id,
                requestType: type
            },
            beforeSend: function() {
                $('#notification-' + id).attr('disabled', true);
                $('#notification-' + id).text('...');
            },
            success: function(data) {
                toastr["success"]("Mark as read done", "Success");
                if (type == 'all') {
                    window.location.reload();
                }
            },
            error: function(xhr) {
                toastr["error"]("Something went wrong please try again", "Error!");
            },
            complete: function() {
                $('#notification-' + id).attr('disabled', false);
                $('#notification-' + id).html('<i class="fa fa-times"></i>');
            }

        });
    }
</script>
@endpush