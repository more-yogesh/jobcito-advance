@extends('layouts.app')
@section('content')
<div class="header-inner bg-light text-center">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="text-primary">Contact Us</h1>
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}"> Home </a></li>
                    <li class="breadcrumb-item active"> <i class="fas fa-chevron-right"></i> <span> Contact us </span></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<section class="space-ptb">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 mb-4 mb-lg-0">
          <div class="feature-info feature-info-border p-4 text-center">
            <div class="feature-info-icon mb-3">
              <i class="flaticon-placeholder"></i>
            </div>
            <div class="feature-info-content">
              <h2 class="text-black">Address</h2>
              <span class="d-block">G/8, Swaminarayan Complex, Majura Gate,</span>
              <span>Ring Road, Surat, Gujarat, India.</span>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-4 mb-lg-0">
          <div class="feature-info feature-info-border p-4 text-center">
            <div class="feature-info-icon mb-3">
              <i class="flaticon-contact fa-flip-horizontal"></i>
            </div>
            <div class="feature-info-content">
              <h2 class="text-black">Contact Number</h2>
              <span class="d-block">(+91) 92657 27188</span>
              <hr/>
              <span>(+91) 90333 77665</span>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <div class="feature-info feature-info-border p-4 text-center">
            <div class="feature-info-icon mb-3">
              <i class="flaticon-approval"></i>
            </div>
            <div class="feature-info-content">
              <h2 class="text-black">Email</h2>
              <span class="d-block">For job related queries <br/><b>hr@jobcito.com</b></span>
              <hr/>
              <span class="d-block">For job other queries <br/><b>info@jobcito.com</b></span>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  </section>
<section class="space-ptb pt-0">
    <div class="container">
        <div class="row">   
            <div class="col-lg-12">
                <div class="section-title-02 text-center mt-3">
                    <h2>Let’s Get In Touch!</h2>
                    <p>Feel free drop message to us, JobCito team is always here for you :)</p>
                </div>
            </div>
        </div>
        <form id="contactUsForm">
            @csrf
            <div class="form-row">
                <div class="form-group col-md-6">
                    <input type="text" class="form-control" name="name" placeholder="Enter Your Name">
                </div>
                <div class="form-group col-md-6">
                    <input type="email" class="form-control" name="email" placeholder="email">
                </div>
                <div class="form-group col-md-6">
                    <input type="text" class="form-control" name="subject" placeholder="Enter subject">
                </div>
                <div class="form-group col-md-6">
                    <input type="text" class="form-control" name="mobile" placeholder="Enter Your Phone Number">
                </div>
                <div class="form-group col-12 mb-0">
                    <textarea rows="5" class="form-control" name="message" placeholder="Subject"></textarea>
                </div>
                <div class="col-12 text-center mt-4">
                    <button class="btn btn-primary" type="submit" id="contactUsFormButton">Send your message</button>
                </div>
            </div>
        </form>
    </div>
</section>
@endsection
@section('custom-scripts')
<script>
    $(document).ready(function() {
        $('#contactUsForm').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('contact-us.store') }}",
                method: 'POST',
                beforeSend: function() {
                    $('#contactUsFormButton').attr('disabled', true);
                    $('#contactUsFormButton').text('Loading...');
                },
                data: $('#contactUsForm').serialize(),

                success: function(data) {
                    toastr["success"](data.success, "Message Sent!");
                    $('#contactUsForm')[0].reset();
                    $("textarea, input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                },
                error: function(xhr) {
                    toastr["error"]("Please check from details and try again", "Error!");
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors);
                },
                complete: function() {
                    $('#contactUsFormButton').attr('disabled', false);
                    $('#contactUsFormButton').text('Send your messaage');
                }

            });
        });
    });
</script>
@endsection