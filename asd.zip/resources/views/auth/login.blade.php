@extends('layouts.app')

@section('content')
<div class="header-inner bg-light text-center">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2 class="text-primary">Login</h2>
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}"> Home </a></li>
                    <li class="breadcrumb-item active"> <i class="fas fa-chevron-right"></i> <span> Login </span></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<section class="space-ptb mb-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-8 col-lg-10 col-md-12">
                <div class="login-register">
                    <fieldset>
                        <legend class="px-2 display-4" style="font-size:20px;">Login to Your Account</legend>
                        <div class="tab-content">
                            <div class="tab-pane active" id="candidate" role="tabpanel">
                                @include('auth.modal.login')
                            </div>
                        </div>
                    </fieldset>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection