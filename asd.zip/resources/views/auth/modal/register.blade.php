<div class="login-register">
    <div class="tab-content">
        <div class="tab-pane active" id="candidate" role="tabpanel">
            @if(!Route::currentRouteNamed('recruiter'))
            <fieldset>
                <legend class="px-2">Tell us about your work status.</legend>
                <ul class="nav nav-tabs nav-tabs-border d-flex" role="tablist">
                    <li class="nav-item mr-4">
                        <a class="nav-link active" data-toggle="tab" href="#candidate" role="tab" aria-selected="false" onclick="setUserType('fresher')">
                            <div class="d-flex">
                                <div class="tab-icon">
                                    <i class="flaticon-businessman"></i>
                                </div>
                                <div class="ml-3">
                                    <h6 class="mb-0">I am a Fresher.</h6>
                                    <p class="mb-0">
                                        I have just graduated/I haven't worked after graduation.
                                    </p>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#employer" role="tab" aria-selected="false" onclick="setUserType('experince')">
                            <div class="d-flex">
                                <div class="tab-icon">
                                    <i class="flaticon-suitcase"></i>
                                </div>
                                <div class="ml-3">
                                    <h6 class="mb-0">I am an Experience.</h6>
                                    <p class="mb-0">I have at least one month of work experience.</p>
                                </div>
                            </div>
                        </a>
                    </li>
                </ul>
            </fieldset>
            @endif
            <fieldset class="mt-1">
                <form class="mt-4" method="POST" id="registerUser">
                    @csrf()
                    @if(Route::currentRouteNamed('recruiter'))
                    <input type="hidden" name="role" value="company">
                    @else
                    <input type="hidden" name="role" value="employee">
                    @endif
                    <input type="hidden" name="type" value="fresher" id="user-type">
                    <div class="form-row">
                        <div class="form-group col-12">
                            <label for="name">{{ Route::currentRouteNamed('recruiter') ? 'Company Name' : 'Name' }}</label>
                            <input type="text" class="form-control" id="name" name="name">
                        </div>
                        <div class="form-group col-12">
                            <label for="mobile">Mobile Number:</label>
                            <input type="number" class="form-control" id="mobile" name="mobile">
                        </div>
                        <div class="form-group col-12">
                            <label for="email">Email ID</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                        <div class="form-group col-12">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <div class="form-group col-12">
                            <label for="confirm_password">Confirm Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col-md-6">
                            <button class="btn btn-primary btn-block" type="submit" id="registerButton">Register Me</button>
                        </div>
                        <div class="col-md-6">
                            <div class="ml-md-3 mt-3 mt-md-0 forgot-pass">
                                <a href="{{ route('password.request') }}">Forgot Password?</a>
                                <p class="mt-1">Already have an account? <a href="{{ route('login') }}">Login here</a></p>
                            </div>
                        </div>
                    </div>
                </form>
            </fieldset>
        </div>
    </div>
</div>
@push('scripts')
<script>
    $(document).ready(function() {
        $('#registerUser').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('register') }}",
                method: "POST",
                beforeSend: function() {
                    $('#registerButton').attr('disabled', true);
                    $('#registerButton').text('Loading...');
                },
                data: $('#registerUser').serialize(),
                success: function(data) {
                    toastr["success"]("Please check your inbox have sent you an email", "Registration Done!");

                    setTimeout(function() {
                        window.location.href = data.redirect;
                    }, 5000);
                },
                error: function(xhr) {
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors);
                    toastr["error"]("Please check inputs and try again!", "Error!");
                },
                complete: function() {
                    $('#registerButton').attr('disabled', false);
                    $('#registerButton').text('Register Me');
                }
            });
        })
    });
</script>
@endpush