<form class="mt-4" method="POST" id="loginUser">
    @csrf()
    <div class="form-row">
        <div class="form-group col-12">
            <label for="username">Mobile Number Or Email</label>
            <input type="text" class="form-control" id="username" name="username" placeholder="Enter your email or contact number">
        </div>
        <div class="form-group col-12" id="show_hide_password">
            <label for="password">Passoword</label>
            <div class="input-group mb-3">
                <input type="password" name="password" class="form-control" placeholder="Password" aria-label="Password" aria-describedby="basic-addon2">
                <div class="input-group-append">
                    <a class="btn btn-outline-primary btn-sm" href="javascript:void(0)">
                        <i class="fa fa-eye-slash" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="form-row mt-2">
        <div class="col-md-6">
            <button class="btn btn-primary btn-block" type="submit" id="loginButton">Login</button>
        </div>
        <div class="col-md-6">
            <div class="ml-md-3 mt-3 mt-md-0 forgot-pass">
                <a href="{{ route('password.request') }}">Forgot Password?</a>
                <p class="mt-1">I don't have an account? <a href="{{ route('register') }}">Register Me</a></p>
            </div>
        </div>
    </div>
</form>
@push('scripts')
<script>
    $(document).ready(function() {
        $('#loginUser').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('login') }}",
                method: "POST",
                beforeSend: function() {
                    $('#loginButton').attr('disabled', true);
                    $('#loginButton').text('Loading...');
                },
                data: $('#loginUser').serialize(),

                success: function(data) {
                    toastr["success"]("Welcome back to {{ env('APP_NAME') }}", "Login Done!");
                    setTimeout(function() {
                        console.log(data.redirect);
                        window.location.href = data.redirect;
                    }, 2000);

                },
                error: function(xhr) {
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors);
                    toastr["error"]("Someting went wrong please check and try again", "Error!");
                },
                complete: function() {
                    $('#loginButton').attr('disabled', false);
                    $('#loginButton').text('Login');
                }
            });
        })
    });

    $(document).ready(function() {
        $("#show_hide_password a").on('click', function(event) {
            event.preventDefault();
            if ($('#show_hide_password input').attr("type") == "text") {
                $('#show_hide_password input').attr('type', 'password');
                $('#show_hide_password i').addClass("fa-eye-slash");
                $('#show_hide_password i').removeClass("fa-eye");
            } else if ($('#show_hide_password input').attr("type") == "password") {
                $('#show_hide_password input').attr('type', 'text');
                $('#show_hide_password i').removeClass("fa-eye-slash");
                $('#show_hide_password i').addClass("fa-eye");
            }
        });
    });
</script>
@endpush