@extends('layouts.app')
@section('content')
@php

$logo = $company->getFirstMediaUrl('profiles', 'logo');
if($logo == ''){
$logo = asset('company.png');
}
@endphp
<section class="header-inner header-inner-big bg-holder text-white pb-5 pt-5" style="background-image: url({{ asset('assets/images/bg/banner-01.jpg') }});">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="job-search-field">
                    <div class="job-search-item">

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="employers-list border">
                                    <div class="employers-list-logo">
                                        <img class="img-fluid" src="{{$logo}}" alt="">
                                    </div>
                                    <div class="employers-list-details">
                                        <div class="employers-list-info">
                                            <div class="employers-list-title">
                                                <h5 class="mb-0">{{ $company->company->name }}</h5>
                                            </div>
                                            <div class="employers-list-option text-dark">
                                                <ul class="list-unstyled">
                                                    <li><i class="fas fa-map-marker-alt pr-1"></i>{{ $company->company->city }}, {{ $company->company->state }}</li>
                                                    <li><i class="fa fa-phone fa-flip-horizontal pl-1"></i> {{ '(+91) 98251 XXXXX' }}</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="employers-list-position">
                                        <a class="btn btn-sm btn-dark" href="#otherJobs">{{ $company->jobs->count() }} Jobs Open</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="">
    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-8">
                <div class="border p-4">
                    <div class="row">
                        <div class="col-md-4 col-sm-6 mb-4">
                            <div class="d-flex">
                                <i class="font-xll text-primary align-self-center flaticon-binoculars"></i>
                                <div class="feature-info-content pl-3">
                                    <label class="mb-1">Viewed Per Month</label>
                                    <span class="mb-0 font-weight-bold d-block text-dark">{{ mt_rand(100,860) }}</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 mb-4">
                            <div class="d-flex">
                                <i class="font-xll text-primary align-self-center flaticon-placeholder"></i>
                                <div class="feature-info-content pl-3">
                                    <label class="mb-1">Location</label>
                                    <span class="mb-0 font-weight-bold d-block text-dark">{{ $company->company->city }}, {{ $company->company->state }}({{ $company->company->country }})</span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-6 mb-md-0 mb-4">
                            <div class="d-flex">
                                <i class="font-xll text-primary align-self-center flaticon-time"></i>
                                <div class="feature-info-content pl-3">
                                    <label class="mb-1">Since</label>
                                    <span class="mb-0 font-weight-bold d-block text-dark">{{ $company->created_at->format('M, Y') }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mt-4 mt-md-5 mb-4 mb-md-5 ">
                    <h5 class="mb-3 mb-md-4">About company</h5>
                    <p>{!! $company->company->description !!}</p>
                </div>
                <hr />
            </div>
            <div class="col-lg-4 mt-4 mt-lg-0">
                <div class="sidebar mb-0">
                    <div class="widget">
                        <div class="widget-title">
                            <h5>Share {{ $company->company->name }}</h5>
                        </div>
                        <div class="company-detail-meta justify-content-start">
                            <a class="btn btn-sm m-1 btn-social btn-fb" href="https://www.facebook.com/sharer/sharer.php?u={{url()->current()}}" target="_blank" title="Share this company on Facebook">
                                <i class="fab fa-facebook-square"></i> Share
                            </a>
                            <a class="btn btn-sm m-1 btn-social btn-tw" href="https://twitter.com/intent/tweet?text={{$company->company->title}}&amp;url={{url()->current()}}" target="_blank" title="Share this company on Twitter">
                                <i class="fab fa-twitter"></i> Tweet
                            </a>
                            <a class="btn btn-sm m-1 btn-social btn-in" href="https://www.linkedin.com/shareArticle?mini=true&url={{url()->current()}}&amp;title={{$company->company->name}}" target="_blank" title="Share this company on LinkedIn">
                                <i class="fab fa-linkedin-in" data-fa-transform="grow-2"></i> Share
                            </a>

                            <div class="widget mt-4">
                                <div class="widget-title">
                                    <h5>Contact {{ $company->company->name }}</h5>
                                </div>
                                <div class=" company-contact-inner widget-box">
                                    <form id="contactCompanyForm">
                                        @csrf
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Full name" name="name">
                                        </div>
                                        <div class="form-group">
                                            <input type="email" class="form-control" placeholder="Email address" name="email">
                                        </div>
                                        <div class="form-group">
                                            <input type="number" class="form-control" placeholder="Mobile" name="mobile">
                                        </div>
                                        <input type="hidden" name="subject" value="{{ $company->company->name }}">
                                        <div class="form-group">
                                            <textarea class="form-control" rows="3" placeholder="Message" name="message"></textarea>
                                        </div>
                                        <button class="btn btn-primary btn-outline-primary btn-block" id="contactCompanyFormButton" type="submit">Send Email</button>
                                    </form>
                                </div>
                            </div>

                            <div class="widget mb-4" id="otherJobs">
                                <div class="widget-title">
                                    <h5>Other jobs from {{ $company->company->name }}</h5>
                                </div>
                                <div class="similar-jobs-item widget-box">
                                    @forelse($companyOtherJobs as $companyOtherJob)
                                    @php
                                    $companyOtherJobLogo = $companyOtherJob->user->getFirstMediaUrl('profiles', 'logo');
                                    if($companyOtherJobLogo == ''){
                                    $companyOtherJobLogo = asset('company.png');
                                    }
                                    @endphp
                                    <div class="job-list">
                                        <div class="job-list-logo">
                                            <img class="img-fluid" src="{{$companyOtherJobLogo}}" alt="">
                                        </div>
                                        <div class="job-list-details">
                                            <div class="job-list-info">
                                                <div class="job-list-title">
                                                    <h6>
                                                        <a href="{{ route('showJob', $companyOtherJob->jobSlug()) }}">
                                                            {{ $companyOtherJob->title  }}
                                                        </a>
                                                    </h6>
                                                </div>
                                                <div class="job-list-option">
                                                    <ul class="list-unstyled">
                                                        <li>
                                                            <span>via</span>
                                                            <a href="{{ route('showCopmany', $companyOtherJob->companySlug()) }}">{{ $companyOtherJob->user->company->name }}</a>
                                                        </li>
                                                        <li><a class="freelance" href="#"><i class="fas fa-suitcase pr-1"></i>{{ $companyOtherJob->category->name }}</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @empty
                                    <div class="job-list">
                                        <h5 class="mx-auto">Other jobs from {{ $company->company->name }}</h5>
                                    </div>
                                    @endforelse
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</section>
@endsection
@section('custom-scripts')
<script>
    $(document).ready(function() {
        $('#contactCompanyForm').submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('contact-us.store') }}",
                method: 'POST',
                beforeSend: function() {
                    $('#contactCompanyFormButton').attr('disabled', true);
                    $('#contactCompanyFormButton').text('Loading...');
                },
                data: $('#contactCompanyForm').serialize(),

                success: function(data) {
                    toastr["success"](data.success, "Message Sent!");
                    $('#contactCompanyForm')[0].reset();
                    $("textarea, input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                },
                error: function(xhr) {
                    toastr["error"]("Please check from details and try again", "Error!");
                    $("input").removeClass("is-invalid");
                    $(".invalid-feedback").remove();
                    errors = xhr.responseJSON.errors;
                    printErrorMsg(errors);
                },
                complete: function() {
                    $('#contactCompanyFormButton').attr('disabled', false);
                    $('#contactCompanyFormButton').text('Send your messaage');
                }

            });
        });
    });
</script>
@endsection