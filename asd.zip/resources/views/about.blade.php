@extends('layouts.app')
@section('content')
<div class="header-inner bg-light text-center">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="text-primary">About Us</h1>
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}"> Home </a></li>
                    <li class="breadcrumb-item active"> <i class="fas fa-chevron-right"></i> <span> About us </span></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<section class="space-ptb" style="background-image: url(images/google-map.png); background-position: center center; background-repeat: no-repeat;">
    <div class="container">
        <div class="row justify-content-center text-center">
            <div class="col-md-6">
                <h2 class="mb-4">About JobCito's awsome start in Surat(Gujarat, India)</h2>
            </div>
            <div class="col-lg-10">
                <div class="text-center">
                    <p class="mb-lg-5 mb-4 lead">As a Job(Placement Consulatant) in Surat, We help you to find the best candidate in the industry. Your vacancy is most important for us. We believe employers and employees are both the most important aspect to grow together. We are committed to satisfaction towards was the job. We not just hire to fulfill your vacancy but for making and maintaining your corporate culture.
                    </p>
                    <p class="mb-lg-5 mb-4 lead">
                        Technology is the most important part of our organization, So we have a dedicated technical team to provide seamless services.
                    </p>
                    <img class="img-fluid mt-lg-4 mt-3" src="{{ asset('assets/images/about/about-img1.png') }}" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="space-pb">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="feature-info feature-info-border p-xl-5 p-4 text-center">
                    <div class="feature-info-icon mb-3">
                        <i class="flaticon-contract"></i>
                    </div>
                    <div class="feature-info-content">
                        <h5 class="text-black">Job openings</h5>
                        <p class="mb-0">In simple two steps, You can register your company and complete your profile, and that's it. Now you can post your job, and things get started working.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="feature-info feature-info-border p-xl-5 p-4 text-center">
                    <div class="feature-info-icon mb-3">
                        <i class="flaticon-profiles"></i>
                    </div>
                    <div class="feature-info-content">
                        <h5 class="text-black">Assessment</h5>
                        <p class="mb-0">Our goal is to make recruitment as smooth and effective as possible. We conduct individual assessment tests of candidates to check their suitability. </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-info feature-info-border p-xl-5 p-4 text-center">
                    <div class="feature-info-icon mb-3">
                        <i class="flaticon-job-3"></i>
                    </div>
                    <div class="feature-info-content">
                        <h5 class="text-black">Interview</h5>
                        <p class="mb-0">Only when the candidate seems like a perfect match for a vacant job position, would we send
                            them to the client firm. </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="space-pb">
    <div class="container">
        <div class="row">

            <div class="col-lg-12 align-self-center">
                <div class="section-title-02">
                    <h2>Why You Choose JobCito Among Other?</h2>
                </div>
                <div class="row mt-sm-5 mt-4">
                    <div class="col-md-6">
                        <div class="d-flex mb-lg-5 mb-4">
                            <i class="font-xlll text-primary flaticon-team"></i>
                            <h5 class="pl-3 align-self-center mb-0">Best talented people</h5>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex mb-lg-5 mb-4">
                            <i class="font-xlll text-primary flaticon-chat"></i>
                            <h5 class="pl-3 align-self-center mb-0">Easy to find the candidate</h5>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex mb-md-0 mb-4">
                            <i class="font-xlll text-primary flaticon-job-3"></i>
                            <h5 class="pl-3 align-self-center mb-0">Easy to communicate</h5>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex">
                            <i class="font-xlll text-primary flaticon-job-2"></i>
                            <h5 class="pl-3 align-self-center mb-0">Best recruitment options</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection