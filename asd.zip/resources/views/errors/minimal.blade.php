<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="keywords" content="Job searching in surat, job searching in gujarat" />
    <meta name="description" content="Jobcito.com" />
    <meta name="author" content="www.jobcito.com" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>@yield('title')</title>
    <link href="images/favicon.ico" rel="shortcut icon" />
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/css/font-awesome/all.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/flaticon/flaticon.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap/bootstrap.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}" />
</head>

<body>
    <div class="header-inner bg-light text-center">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2 class="text-primary">@yield('code') Error</h2>
                    <ol class="breadcrumb mb-0 p-0">
                        <li class="breadcrumb-item"><a href="{{ route('welcome') }}">Home</a></li>
                        <li class="breadcrumb-item active"> <i class="fas fa-chevron-right"></i> <span>@yield('code') Error</span></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <section class="space-ptb">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <img class="img-fluid" src="{{ asset('assets/images/error-img.png') }}" alt="">
                </div>
                <div class="col-lg-6 col-md-6 mt-4 mt-sm-0 text-center">
                    <div id="notfound">
                        <div class="notfound">
                            <div class="notfound-404">
                                <h1>Oops!</h1>
                            </div>
                            <h2>@yield('code')</h2>
                            <p>@yield('message')</p>
                            <a class="btn btn-primary" href="{{ route('welcome') }}">Go To Homepage</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>

</html>