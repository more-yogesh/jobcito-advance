@extends('layouts.app')
@section('content')
<div class="header-inner bg-light text-center">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h2 class="text-primary">Training</h2>
				<ol class="breadcrumb mb-0 p-0">
					<li class="breadcrumb-item"><a href="{{ url('/') }}"> Home </a></li>
					<li class="breadcrumb-item active"> <i class="fas fa-chevron-right"></i> <span> Training </span></li>
				</ol>
			</div>
		</div>
	</div>
</div>
<section class="py-4 py-lg-5 our-clients">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-12">
				<div class="owl-carousel owl-nav-center" data-animateOut="fadeOut" data-nav-dots="false" data-items="6" data-md-items="5" data-sm-items="4" data-xs-items="3" data-xx-items="2" data-space="50">
					<div class="item">
						<img class="img-fluid" src="{{ asset('assets/images/client/amazon.svg') }}" alt="">
					</div>
					<div class="item">
						<img class="img-fluid" src="{{ asset('assets/images/client/flipkart.svg') }}" alt="">
					</div>
					<div class="item">
						<img class="img-fluid" src="{{ asset('assets/images/client/google.svg') }}" alt="">
					</div>
					<img class="img-fluid" src="{{ asset('assets/images/client/paypal.svg') }}" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
<section class="space-pb">
	<div class="container">
		<div class="row">
			<div class="col-md-4 mb-4 mb-md-0">
				<div class="feature-info feature-info-border p-xl-5 p-4 text-center">
					<div class="feature-info-icon mb-4">
						<img class="img-fluid rounded-circle" src="{{ asset('assets/images/laravel-logo.jpg') }}" alt="">
					</div>
					<div class="feature-info-content">
						<h5 class="text-black">Laravel
						</h5>
						<button type="button" class="btn btn-secondary btn-block mt-3" onclick="showLaravelCourse()">Show course</button>
						<button type="button" class="btn btn-secondary btn-block ml-0" onclick="getInquiry('Laravel PHP Professional Training')">I want this course</button>
					</div>
				</div>
			</div>
			<div class="col-md-4 mb-4 mb-md-0">
				<div class="feature-info feature-info-border p-xl-5 p-4 text-center">
					<div class="feature-info-icon mb-3">
						<img class="img-fluid rounded-circle" src="{{ asset('assets/images/web-icon.jpg') }}" alt="">

					</div>
					<div class="feature-info-content">
						<h5 class="text-black">Web Designing</h5>

						<button type="button" class="btn btn-secondary btn-block mt-3 " onclick="webdesigninglaravel()">Show course</button>

						<button type="button" class="btn btn-secondary btn-block ml-0 mb-3" onclick="getInquiry('Web Designing')">I want this course</button>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="feature-info feature-info-border p-xl-5 p-3 text-center">
					<div class="feature-info-icon mb-3">
						<img class="img-fluid rounded-circle" src="{{ asset('assets/images/react-icon.jpg') }}" alt="">
					</div>
					<div class="feature-info-content">
						<h5 class="text-black">React Native</h5>
						<button type="button" class="btn btn-secondary btn-block" ml-3 onclick="reactnativelaravel()">Show course</button>
						<button type="button" class="btn btn-secondary btn-block ml-0 mb-3" onclick="getInquiry('React Native')">I want this course</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="space-pb">
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<div class="section-title-02">
					<h2>Testimonial</h2>
				</div>
				<div class="owl-carousel owl-nav-top-center" data-nav-arrow="false" data-items="1" data-md-items="1" data-sm-items="1" data-xs-items="1" data-xx-items="1" data-space="5">
					<div class="item">
						<div class="testimonial-item">
							<div class="avatar">
								<img class="img-fluid rounded-circle" src="{{ asset('assets/images/avatar/04.jpg') }}" alt="">
							</div>
							<div class="testimonial-content">
								<p>Dear friends Jobcito.com is really a right place for making your career that gives a direction to core company. Jobcito.com have awesome also a well knowledge trained faculty.</p>
							</div>
							<div class="testimonial-name">
								<i class="fas fa-quote-left quotes"></i>
								<h6 class="mb-1">Felica Queen</h6>
								<span>Product Designer</span>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="testimonial-item">
							<div class="avatar">
								<img class="img-fluid rounded-circle" src="{{ asset('assets/images/avatar/02.jpg') }}" alt="">
							</div>
							<div class="testimonial-content">
								<p>I seriously appreciate the Placement Department of jobcito.com that they provided me the opportunity specially Ms. Shital mem (Placement Head) & Yogesh Sir (Training & Placement Officer)..</p>
							</div>
							<div class="testimonial-name">
								<i class="fas fa-quote-left quotes"></i>
								<h6 class="mb-1">John Doe</h6>
								<span>Graphic Designer</span>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 mt-5 mt-lg-0">
				<div class="section-title-02">
					<h2>Frequently asked questions</h2>
				</div>
				<div class="accordion-style" id="accordion-Two">
					<div class="card">
						<div class="card-header" id="headingOne">
							<h5 class="accordion-title mb-0">
								<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">Is registration on the Jobber free? <i class="fas fa-chevron-down fa-xs"></i></button>
							</h5>
						</div>
						<div id="collapseOne" class="collapse show accordion-content" aria-labelledby="headingOne" data-parent="#accordion-Two">
							<div class="card-body">
								<p class="mb-0">Motivation is not an accident or something that someone else can give you — you are the only one with the power to motivate you. Motivation cannot be an external force, it must come from within as the natural product.</p>
							</div>
						</div>
					</div>
					<div class="card">
						<div class="card-header" id="headingTwo">
							<h5 class="accordion-title mb-0">
								<button class="btn btn-link d-flex align-items-center ml-auto collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">I'm new to Jobber. How can I register for free? <i class="fas fa-chevron-down fa-xs"></i></button>
							</h5>
						</div>
						<div id="collapseTwo" class="collapse accordion-content" aria-labelledby="headingTwo" data-parent="#accordion-Two">
							<div class="card-body">
								<p class="mb-0">We all carry a lot of baggage, thanks to our upbringing. The majority of people carry with them, an entire series of self-limiting beliefs that will absolutely stop, and hold them back from, success. Things like “I’m not good enough”</p>
							</div>
						</div>
					</div>
					<div class="card">
						<div class="card-header" id="headingthree">
							<h5 class="accordion-title mb-0">
								<button class="btn btn-link d-flex align-items-center ml-auto collapsed" data-toggle="collapse" data-target="#collapsethree" aria-expanded="false" aria-controls="collapsethree">How does Jobber work for job seekers? <i class="fas fa-chevron-down fa-xs"></i></button>
							</h5>
						</div>
						<div id="collapsethree" class="collapse accordion-content" aria-labelledby="headingthree" data-parent="#accordion-Two">
							<div class="card-body">
								<p class="mb-0">For those of you who are serious about having more, doing more, giving more and being more, success is achievable with some understanding of what to do, some discipline around planning and execution.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="modal fade" id="laravelModal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index: 10000;">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header p-4">
				<h4 class="mb-0 text-center">Laravel + PHP Professional Training. </h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body mb-4">
				<div class="panel-body" style="border-bottom: 1px solid #ccc;">
					<div class="col-lg-12">
						<div class="row">
							<div class="col-lg-6 col-md-6 mt-1">
								<div class="accordion-style" id="accordion-one">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
													1.Programing fundamentals
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseOne" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-one">
											<div class="card-body">
												<ul>
													<li>What is programming?</li>
													<li>What is software engineering? </li>
													<li>Software life cycle</li>
													<li>What is C and C++ with OOPs and POP</li>
													<li>What is SQL?</li>
													<li>Basic of design</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-mt-1 ">
								<div class="accordion-style" id="accordion-two">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
													2. Learning Programming with PHP
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseTwo" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-two">
											<div class="card-body">
												<ul>
													<li>History of PH</li>
													<li>PHP structure and how it works </li>
													<li>HTTP protoco</li>
													<li>PHP variable </li>
													<li>PHP expression </li>
													<li>PHP operator and operand</li>
													<li>PHP events, flow, and conditional statements </li>
													<li>PHP loops </li>
													<li>PHP string operations with string functions</li>
													<li>What is PHP array and types? </li>
													<li>PHP array functions</li>
													<li>PHP Date and time functions </li>
													<li>PHP include files </li>
													<li>PHP header functions</li>
													<li>validations using REGEX </li>
													<li>HTTP request methods </li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-lg-6 col-md-6 col-mt-1 ">
								<div class="accordion-style" id="accordion-three">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseTwo">
													3.Programing fundamentals
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseThree" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-three">
											<div class="card-body">
												<ul>
													<li>Concept of DB(Database) </li>
													<li>What are DBMS and RDBMS?</li>
													<li>MySQL introduction </li>
													<li>Database terminology</li>
													<li>MySQL Creating Structure</li>
													<li>MySQL Modify Structure </li>
													<li>MySQL Inserts</li>
													<li>MySQL Update</li>
													<li>MySQL Deletes</li>
													<li>MySQL selects</li>
													<li>MySQL clause </li>
													<li>MySQL group by</li>
													<li>MySQL between and limit</li>
													<li>MySQL joins</li>
													<li>MySQL date conversion and functions</li>
													<li>MySQL other functions </li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-mt-1 ">
								<div class="accordion-style" id="accordion-for">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseFor" aria-expanded="true" aria-controls="collapseTwo">
															4.Web Layout
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseFor" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-for">
											<div class="card-body">
												<ul>
								
													<li>HTML tags and attributes</li>
													<li>HTML anchor tags </li>
													<li>HTML listing</li>
													<li>Html table</li>
													<li>Html div and span tags</li>
													<li>javaScript intro</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-mt-1 ">
								<div class="accordion-style" id="accordion-five">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true" aria-controls="collapseTwo">
															5.SEO
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseFive" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-five">
											<div class="card-body">
												<ul>
								
												<li>What is SEO? </li>
												<li>Implementation in HTML page</li>
												<li>SEO on images</li>
												<li>SEO on anchor tags</li>
												<li>SEO for web page (meta tags)</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-six">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseSix" aria-expanded="true" aria-controls="collapseTwo">
												6. Web Designing
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseSix" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-six">
											<div class="card-body">
												<ul>
								
														<li>What is CSS? </li>
														<li>How to apply CSS?</li>
														<li>Types of CSS </li>
														<li>CSS margin and padding</li>
														<li>CSS backgrounds</li>
														<li>CSS class vs ID</li>
														<li>CSS pseudo-class</li>
														<li>CSS display and position</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-seven">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="true" aria-controls="collapseTwo">
												7.Web Design Framework 
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseSeven" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-seven">
											<div class="card-body">
												<ul>
														<li>What is bootstrap?</li>
														<li>Overview of bootstrap</li>
														<li>Responsive layout </li>
														<li>Bootstrap and grid system</li>
														<li>Bootstrap responsive utilities </li>
														<li>Bootstrap buttons, alerts, and icons</li>
														<li>Bootstrap responsive tables</li>
														<li>Bootstrap carousel</li>
												
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-eight">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseEight" aria-expanded="true" aria-controls="collapseTwo">
												8. Standard PHP For Developers 
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseEight" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-eight">
											<div class="card-body">
												<ul>
													<li>PHP OOPs concepts</li>
													<li>Creating MVC architecture </li>
													<li>PHP OOPs with MVC architecture </li>
													<li>Regular expressions for validation</li>
													<li>PHP session Vs cookies </li>
													<li>PHP file handling </li>
													<li>Accessing directory and files</li>
													<li>Code re-usability </li>
													<li>JSON and XML</li>
													<li>AJAX </li>
													<li>Security</li>
													<li>Email handling</li>
													<li>JavaScript DOM manipulation</li>
												
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-nine">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseNine" aria-expanded="true" aria-controls="collapseTwo">
												9. Industry Trends
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseNine" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-nine">
											<div class="card-body">
												<ul>
												<li>Web services (REST)</li>
												<li>Introduction to CURL</li>
												<li>Payment gateway integration</li>
												<li>Working with jQuery</li>
												
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-ten">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseTen" aria-expanded="true" aria-controls="collapseTwo">
												10.Laravel Industry Training
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseTen" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-ten">
											<div class="card-body">
												<ul>
													<li>Laravel</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="webdevloping" tabindex="-1" role="dialog" aria-hidden="true" style="z-index: 10000;">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header p-4">
				<h4 class="mb-0 text-center">Web Designing</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body mb-4">
				<div class="panel-body" style="border-bottom: 1px solid #ccc;">
					<div class="col-lg-12">
						<div class="row">
							<div class="col-lg-6 col-md-6">
								<div class="accordion-style" id="accordion-one">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
													1.Programing fundamentals
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseOne" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-one">
											<div class="card-body">
												<ul>
													<li>What is programming?</li>
													<li>What is software engineering? </li>
													<li>Software life cycle</li>
													<li>What is C and C++ with OOPs and POP</li>
													<li>What is SQL?</li>
													<li>Basic of design</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-two">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
													2. Learning Programming with PHP
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseTwo" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-two">
											<div class="card-body">
												<ul>
													<li>History of PH</li>
													<li>PHP structure and how it works </li>
													<li>HTTP protoco</li>
													<li>PHP variable </li>
													<li>PHP expression </li>
													<li>PHP operator and operand</li>
													<li>PHP events, flow, and conditional statements </li>
													<li>PHP loops </li>
													<li>PHP string operations with string functions</li>
													<li>What is PHP array and types? </li>
													<li>PHP array functions</li>
													<li>PHP Date and time functions </li>
													<li>PHP include files </li>
													<li>PHP header functions</li>
													<li>validations using REGEX </li>
													<li>HTTP request methods </li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-three">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseTwo">
													3.Programing fundamentals
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseThree" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-three">
											<div class="card-body">
												<ul>
													<li>Concept of DB(Database) </li>
													<li>What are DBMS and RDBMS?</li>
													<li>MySQL introduction </li>
													<li>Database terminology</li>
													<li>MySQL Creating Structure</li>
													<li>MySQL Modify Structure </li>
													<li>MySQL Inserts</li>
													<li>MySQL Update</li>
													<li>MySQL Deletes</li>
													<li>MySQL selects</li>
													<li>MySQL clause </li>
													<li>MySQL group by</li>
													<li>MySQL between and limit</li>
													<li>MySQL joins</li>
													<li>MySQL date conversion and functions</li>
													<li>MySQL other functions </li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-for">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseFor" aria-expanded="true" aria-controls="collapseTwo">
															4.Web Layout
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseFor" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-for">
											<div class="card-body">
												<ul>
								
													<li>HTML tags and attributes</li>
													<li>HTML anchor tags </li>
													<li>HTML listing</li>
													<li>Html table</li>
													<li>Html div and span tags</li>
													<li>javaScript intro</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-five">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true" aria-controls="collapseTwo">
															5.SEO
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseFive" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-five">
											<div class="card-body">
												<ul>
								
												<li>What is SEO? </li>
												<li>Implementation in HTML page</li>
												<li>SEO on images</li>
												<li>SEO on anchor tags</li>
												<li>SEO for web page (meta tags)</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-six">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseSix" aria-expanded="true" aria-controls="collapseTwo">
												6. Web Designing
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseSix" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-six">
											<div class="card-body">
												<ul>
								
														<li>What is CSS? </li>
														<li>How to apply CSS?</li>
														<li>Types of CSS </li>
														<li>CSS margin and padding</li>
														<li>CSS backgrounds</li>
														<li>CSS class vs ID</li>
														<li>CSS pseudo-class</li>
														<li>CSS display and position</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-seven">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="true" aria-controls="collapseTwo">
												7.Web Design Framework 
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseSeven" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-seven">
											<div class="card-body">
												<ul>
														<li>What is bootstrap?</li>
														<li>Overview of bootstrap</li>
														<li>Responsive layout </li>
														<li>Bootstrap and grid system</li>
														<li>Bootstrap responsive utilities </li>
														<li>Bootstrap buttons, alerts, and icons</li>
														<li>Bootstrap responsive tables</li>
														<li>Bootstrap carousel</li>
												
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-eight">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseEight" aria-expanded="true" aria-controls="collapseTwo">
												8. Standard PHP For Developers 
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseEight" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-eight">
											<div class="card-body">
												<ul>
													<li>PHP OOPs concepts</li>
													<li>Creating MVC architecture </li>
													<li>PHP OOPs with MVC architecture </li>
													<li>Regular expressions for validation</li>
													<li>PHP session Vs cookies </li>
													<li>PHP file handling </li>
													<li>Accessing directory and files</li>
													<li>Code re-usability </li>
													<li>JSON and XML</li>
													<li>AJAX </li>
													<li>Security</li>
													<li>Email handling</li>
													<li>JavaScript DOM manipulation</li>
												
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-nine">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseNine" aria-expanded="true" aria-controls="collapseTwo">
												9. Industry Trends
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseNine" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-nine">
											<div class="card-body">
												<ul>
												<li>Web services (REST)</li>
												<li>Introduction to CURL</li>
												<li>Payment gateway integration</li>
												<li>Working with jQuery</li>
												
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-ten">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseTen" aria-expanded="true" aria-controls="collapseTwo">
												10.Laravel Industry Training
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseTen" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-ten">
											<div class="card-body">
												<ul>
													<li>Laravel</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="reactnative" tabindex="-1" role="dialog" aria-hidden="true" style="z-index: 10000;">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header p-4">
				<h4 class="mb-0 text-center">React Native </h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body mb-4">
				<div class="panel-body" style="border-bottom: 1px solid #ccc;">
					<div class="col-lg-12">
						<div class="row">
							<div class="col-lg-6 col-md-6">
								<div class="accordion-style" id="accordion-one">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
													1.Programing fundamentals
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseOne" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-one">
											<div class="card-body">
												<ul>
													<li>What is programming?</li>
													<li>What is software engineering? </li>
													<li>Software life cycle</li>
													<li>What is C and C++ with OOPs and POP</li>
													<li>What is SQL?</li>
													<li>Basic of design</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-two">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
													2. Learning Programming with PHP
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseTwo" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-two">
											<div class="card-body">
												<ul>
													<li>History of PH</li>
													<li>PHP structure and how it works </li>
													<li>HTTP protoco</li>
													<li>PHP variable </li>
													<li>PHP expression </li>
													<li>PHP operator and operand</li>
													<li>PHP events, flow, and conditional statements </li>
													<li>PHP loops </li>
													<li>PHP string operations with string functions</li>
													<li>What is PHP array and types? </li>
													<li>PHP array functions</li>
													<li>PHP Date and time functions </li>
													<li>PHP include files </li>
													<li>PHP header functions</li>
													<li>validations using REGEX </li>
													<li>HTTP request methods </li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-three">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseTwo">
													3.Programing fundamentals
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseThree" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-three">
											<div class="card-body">
												<ul>
													<li>Concept of DB(Database) </li>
													<li>What are DBMS and RDBMS?</li>
													<li>MySQL introduction </li>
													<li>Database terminology</li>
													<li>MySQL Creating Structure</li>
													<li>MySQL Modify Structure </li>
													<li>MySQL Inserts</li>
													<li>MySQL Update</li>
													<li>MySQL Deletes</li>
													<li>MySQL selects</li>
													<li>MySQL clause </li>
													<li>MySQL group by</li>
													<li>MySQL between and limit</li>
													<li>MySQL joins</li>
													<li>MySQL date conversion and functions</li>
													<li>MySQL other functions </li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-for">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseFor" aria-expanded="true" aria-controls="collapseTwo">
															4.Web Layout
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseFor" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-for">
											<div class="card-body">
												<ul>
								
													<li>HTML tags and attributes</li>
													<li>HTML anchor tags </li>
													<li>HTML listing</li>
													<li>Html table</li>
													<li>Html div and span tags</li>
													<li>javaScript intro</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-five">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true" aria-controls="collapseTwo">
															5.SEO
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseFive" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-five">
											<div class="card-body">
												<ul>
								
												<li>What is SEO? </li>
												<li>Implementation in HTML page</li>
												<li>SEO on images</li>
												<li>SEO on anchor tags</li>
												<li>SEO for web page (meta tags)</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-six">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseSix" aria-expanded="true" aria-controls="collapseTwo">
												6. Web Designing
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseSix" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-six">
											<div class="card-body">
												<ul>
								
														<li>What is CSS? </li>
														<li>How to apply CSS?</li>
														<li>Types of CSS </li>
														<li>CSS margin and padding</li>
														<li>CSS backgrounds</li>
														<li>CSS class vs ID</li>
														<li>CSS pseudo-class</li>
														<li>CSS display and position</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-seven">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="true" aria-controls="collapseTwo">
												7.Web Design Framework 
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseSeven" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-seven">
											<div class="card-body">
												<ul>
														<li>What is bootstrap?</li>
														<li>Overview of bootstrap</li>
														<li>Responsive layout </li>
														<li>Bootstrap and grid system</li>
														<li>Bootstrap responsive utilities </li>
														<li>Bootstrap buttons, alerts, and icons</li>
														<li>Bootstrap responsive tables</li>
														<li>Bootstrap carousel</li>
												
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-eight">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseEight" aria-expanded="true" aria-controls="collapseTwo">
												8. Standard PHP For Developers 
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseEight" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-eight">
											<div class="card-body">
												<ul>
													<li>PHP OOPs concepts</li>
													<li>Creating MVC architecture </li>
													<li>PHP OOPs with MVC architecture </li>
													<li>Regular expressions for validation</li>
													<li>PHP session Vs cookies </li>
													<li>PHP file handling </li>
													<li>Accessing directory and files</li>
													<li>Code re-usability </li>
													<li>JSON and XML</li>
													<li>AJAX </li>
													<li>Security</li>
													<li>Email handling</li>
													<li>JavaScript DOM manipulation</li>
												
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-nine">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseNine" aria-expanded="true" aria-controls="collapseTwo">
												9. Industry Trends
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseNine" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-nine">
											<div class="card-body">
												<ul>
												<li>Web services (REST)</li>
												<li>Introduction to CURL</li>
												<li>Payment gateway integration</li>
												<li>Working with jQuery</li>
												
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 ">
								<div class="accordion-style" id="accordion-ten">
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="accordion-title mb-0">
												<button class="btn btn-link d-flex align-items-center ml-auto" data-toggle="collapse" data-target="#collapseTen" aria-expanded="true" aria-controls="collapseTwo">
												10.Laravel Industry Training
													<i class="fas fa-chevron-down fa-xs"></i>
												</button>
											</h5>
										</div>
										<div id="collapseTen" class="collapse accordion-content" aria-labelledby="headingOne" data-parent="#accordion-ten">
											<div class="card-body">
												<ul>
													<li>Laravel</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="inquiryModal" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header p-4">
				<h4 class="mb-0 text-center">Please Enter Details</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body mb-3">
				<h3 class="text-danger" id="course-title"></h3>
				<form class="mt-4" method="POST" id="inquiryForm">
					@csrf
					<input type="hidden" name="course_name" id="course_name">
					<div class="form-row">
						<div class="form-group col-12">
							<label for="name">Name</label>
							<input type="text" class="form-control" id="name" name="name" placeholder="Enter your name">
						</div>
						<div class="form-group col-12">
							<label for="mobile">Mobile Number</label>
							<input type="number" class="form-control" id="mobile" name="mobile" placeholder="Enter your contact number">
						</div>
					</div>
					<div class="form-row mt-2">
						<div class="col-md-12">
							<button class="btn btn-primary btn-block" type="submit" id="inquiryButton">SEND</button>
						</div>

					</div>
				</form>
			</div>
		</div>
	</div>
</div>

@endsection

@push('scripts')
<script>
	function showLaravelCourse() {
		$('#laravelModal').modal('show');
	}

	function reactnativelaravel() {
		$('#reactnative').modal('show');
	}

	function webdesigninglaravel() {
		$('#webdevloping').modal('show');
	}

	function getInquiry(courseName) {
		$('#course_name').val(courseName);
		$('#course-title').text("For " + courseName + " Course");
		$('#inquiryModal').modal('show');
	}
</script>
<script>
	$(document).ready(function() {
		$('#inquiryForm').submit(function(e) {
			e.preventDefault();
			$.ajax({
				url: "{{ route('training-inquiry.store') }}",
				method: "POST",
				beforeSend: function() {
					$('#inquiryButton').attr('disabled', true);
					$('#inquiryButton').text('Loading...');
				},
				data: $('#inquiryForm').serialize(),

				success: function(data) {
					toastr["success"](data.message, "Success");
					location.reload();
				},
				error: function(xhr) {
					$("input").removeClass("is-invalid");
					$(".invalid-feedback").remove();
					errors = xhr.responseJSON.errors;
					printErrorMsg(errors);
					toastr["error"]("Someting went wrong please check and try again", "Error!");
				},
				complete: function() {
					$('#inquiryButton').attr('disabled', false);
					$('#inquiryButton').text('SEND');
				}
			});
		})
	});
</script>
@endpush