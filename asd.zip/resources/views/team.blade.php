@extends('layouts.app')
@section('content')

<section class="space-ptb">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2>Meet Our Team</h2>
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="candidate-list candidate-grid">
                            <div class="candidate-list-image">
                                <img class="img-fluid" src="{{ asset('assets/images/avatar/shital.jpg')}}" alt="" height="300px">
                            </div>
                            <div class="candidate-list-details">
                                <div class="candidate-list-info">
                                    <div class="candidate-list-title">
                                        <h5><a href="#">Shital Tripathi</a></h5>
                                    </div>
                                    <div class="candidate-list-option">
                                    </div>
                                </div>
                            </div>
                            <div class="candidate-list-favourite-time text-center">
                                <div class="mx-auto">
                                    <h7>Co-Foundar</h7>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="candidate-list candidate-grid">
                            <div class="candidate-list-image">
                                <img class="img-fluid" src="{{ asset('assets/images/avatar/mmmm.jpg')}}" alt="" height="300px">
                            </div>
                            <div class="candidate-list-details">
                                <div class="candidate-list-info">
                                    <div class="candidate-list-title">
                                        <h5><a href="#">Mahima Patel</a></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="candidate-list-favourite-time text-center">
                                <div class="mx-auto">
                                    <h7>Business Development Executive</h7>
                                </div>
                            </div>
                        </div>
                    </div>
                  


                    <div class="col-md-4 mb-3">
                        <div class="candidate-list candidate-grid">
                            <div class="candidate-list-image">
                                <img class="img-fluid" src="{{ asset('assets/images/avatar/hina2.jpg')}}" alt="" height="300px">
                            </div>
                            <div class="candidate-list-details">
                                <div class="candidate-list-info">
                                    <div class="candidate-list-title">
                                        <h5><a href="#">Hina Hirpara</a></h5>
                                    </div>
                                    <div class="candidate-list-option">
                                    </div>
                                </div>
                            </div>
                            <div class="candidate-list-favourite-time text-center">

                                <div class="mx-auto">

                                    <h7>Software Engineer</h7>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="candidate-list candidate-grid">
                            <div class="candidate-list-image">
                                <img class="img-fluid" src="{{ asset('assets/images/avatar/bbbb1.jpg')}}" alt="" height="300px">
                            </div>
                            <div class="candidate-list-details">
                                <div class="candidate-list-info">
                                    <div class="candidate-list-title">
                                        <h5><a href="#">Yogesh More </a></h5>
                                    </div>
                                    <div class="candidate-list-option">
                                    </div>
                                </div>
                            </div>
                            <div class="candidate-list-favourite-time text-center">

                                <div class="mx-auto">

                                    <h7>Business Development Executive</h7>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="candidate-list candidate-grid">
                            <div class="candidate-list-image">
                                <img class="img-fluid" src="{{ asset('assets/images/avatar/bharti4.jpg')}}" alt="" height="300px">
                            </div>
                            <div class="candidate-list-details">
                                <div class="candidate-list-info">
                                    <div class="candidate-list-title">
                                        <h5><a href="#">Bharti Nishad</a></h5>
                                    </div>
                                    <div class="candidate-list-option">
                                    </div>
                                </div>
                            </div>
                            <div class="candidate-list-favourite-time text-center">

                                <div class="mx-auto">

                                    <h7>HR Manager</h7>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


@endsection