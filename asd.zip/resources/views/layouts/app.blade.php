<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" name="viewport">
    {!! SEO::generate() !!}
    <link href="{{ asset('favicon.ico') }}" rel="shortcut icon" />
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/css/font-awesome/all.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/flaticon/flaticon.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap/bootstrap.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/select2/select2.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/css/owl-carousel/owl.carousel.min.css') }}" />
    @yield('css-hooks')
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" />
    @stack('style')
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'UA-154155495-1');
    </script>
    <script>
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '1807294476214725');
        fbq('track', 'PageView');
    </script>
    <noscript>
        <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=1807294476214725&ev=PageView&noscript=1" />
    </noscript>
</head>

<body>
    <header class="header bg-dark">
        <nav class="navbar navbar-static-top navbar-expand-lg header-sticky">
            <div class="container-fluid">
                <button id="nav-icon4" type="button" class="navbar-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <a class="navbar-brand" href="{{ url('/') }}">
                    <img class="img-fluid" src="{{ asset('assets/images/logo.png')}}" alt="logo">
                </a>
                <div class="navbar-collapse collapse justify-content-start">
                    <ul class="nav navbar-nav d-sm-none d-lg-none d-md-none d-xs-block">
                        @guest
                        <li class="nav-item ">
                            <a class="nav-link" href="{{ route('register') }}">Register</a>
                            <a class="nav-link" href="{{ route('login') }}">Login</a>
                        </li>
                        @else
                        @role('employee')
                        <a class="nav-link" href="{{ route('dashboard') }}">Dashboard</a>
                        <a class="nav-link" href="{{ route('profile') }}">profile</a>
                        @endrole
                        @role('admin')
                        <a class="nav-link" href="{{ route('admin.dashboard') }}">Dashboard</a>
                        @endrole
                        @role('company')
                        <a class="nav-link" href="{{ route('company.dashboard') }}">Dashboard</a>
                        <a class="nav-link" href="{{ route('jobs.create') }}">Post Job</a>
                        <a class="nav-link" href="{{ route('company.profile') }}">Profile</a>
                        <a class="nav-link" href="{{ route('notifications') }}">Notifications &nbsp;<span class="badge badge-danger"> {{ auth()->user()->unreadNotifications->count() }}</span></a>
                        @endrole
                        <li><a class="nav-link" href="{{ route('logout') }}" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">Logout2</a></li>
                        @endguest
                    </ul>
                </div>
                @guest
                <div class=" add-listing">
                    <div class="login d-inline-block mr-4">
                        <button class="btn btn-white btn-md" data-toggle="modal" data-target="#exampleModalCenter">
                            <i class="far fa-user pr-2"></i>Register</button>
                    </div>
                    <a href="{{ route('login') }}"><i class="fa fa-lock"></i> Login</a>
                </div>
                @else
                <div class="add-listing">
                    <div class="navbar-collapse collapse justify-content-start">
                        <ul class="nav navbar-nav">
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Hi,
                                    @role('employee')
                                    {{ substr(auth()->user()->employee->name, 0, 12) }}
                                    @endrole
                                    @role('company')
                                    {{ substr(auth()->user()->company->name,0,10) }}
                                    @endrole
                                    @role('admin')
                                    Admin
                                    @endrole
                                    <i class="fas fa-chevron-down fa-xs mt-1"></i></a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown" style="left: 66%;">
                                    @role('employee')
                                    <li><a class="dropdown-item" href="{{ route('dashboard') }}">Dashboard</a></li>
                                    <li><a class="dropdown-item" href="{{ route('profile') }}">profile</a></li>
                                    <li><a class="dropdown-item" href="{{ route('notifications') }}">Notifications &nbsp;<span class="badge badge-danger"> {{ auth()->user()->unreadNotifications->count() }}</span></a></li>
                                    @endrole
                                    @role('company')
                                    <li><a class="dropdown-item" href="{{ route('company.dashboard') }}">Dashboard</a></li>
                                    <li><a class="dropdown-item" href="{{ route('jobs.create') }}">Post Job</a></li>
                                    <li><a class="dropdown-item" href="{{ route('company.profile') }}">Profile</a></li>
                                    <li><a class="dropdown-item" href="{{ route('notifications') }}">Notifications &nbsp;<span class="badge badge-danger"> {{ auth()->user()->unreadNotifications->count() }}</span></a></li>
                                    @endrole
                                    @role('admin')
                                    <li><a class="dropdown-item" href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                                    <li><a class="dropdown-item" href="{{ route('settings') }}">Settings</a></li>
                                    <li><a class="dropdown-item" href="{{ route('notifications') }}">Notifications &nbsp;<span class="badge badge-danger"> {{ auth()->user()->unreadNotifications->count() }}</span></a></li>
                                    @endrole
                                    <li><a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
						document.getElementById('logout-form').submit();">Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                    @csrf
                </form>
                @endguest
            </div>
        </nav>
    </header>
    @yield('content')
    @guest
    <section class="feature-info-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mb-lg-0 mb-4">
                    <div class="feature-info feature-info-02 p-4 p-lg-5 bg-primary">
                        <div class="feature-info-icon mb-3 mb-sm-0 text-dark">
                            <i class="flaticon-team"></i>
                        </div>
                        <div class="feature-info-content text-white pl-sm-4 pl-0">
                            <p>Jobseeker</p>
                            <h5 class="text-white">I am looking for a job.</h5>
                        </div>
                        <a class="ml-auto align-self-center" href="{{ route('register') }}">Apply now<i class="fas fa-long-arrow-alt-right"></i> </a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="feature-info feature-info-02 p-4 p-lg-5 bg-dark">
                        <div class="feature-info-icon mb-3 mb-sm-0 text-primary">
                            <i class="flaticon-job-3"></i>
                        </div>
                        <div class="feature-info-content text-white pl-sm-4 pl-0">
                            <p>Recruiter</p>
                            <h5 class="text-white">Are you recruiting?</h5>
                        </div>
                        <a class="ml-auto align-self-center" href="{{ route('recruiter') }}">Post a job<i class="fas fa-long-arrow-alt-right"></i> </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @endguest
    <footer class="footer @guest bg-light @endguest">
        @guest
        <div class="position-relative">
            <svg class="footer-shape" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="100%" height="85px">
                <path fill-rule="evenodd" fill="rgb(255, 255, 255)" d="M-0.000,-0.001 L1923.000,-0.001 L1923.000,84.999 C1608.914,41.669 1279.532,19.653 962.500,19.000 C635.773,18.326 323.692,40.344 -0.000,84.999 C-0.000,-83.334 -0.000,168.332 -0.000,-0.001 Z" />
            </svg>
        </div>
        <div class="container pt-5">
            <div class="row mt-5">
            </div>
        </div>

        @endguest
        <div class="footer-bottom bg-dark mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="d-flex justify-content-md-start">
                            <ul class="nav">
                                <li><a href="{{ route('policy') }}">Policy |</a></li>
                                <li><a href="{{ route('contact-us.index') }}">Contact Us |</a></li>
                                <li><a href="{{ route('about') }}">About |</a></li>
                                <li><a href="{{ route('recruiter') }}">Company(Recruiter) |</a></li>
                                <!--<li><a href="{{ route('training') }}">Training |</a></li>-->
                                <li><a href="{{ route('team') }}">Team </a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <p class="mb-0">
                            &copy;Copyright <span id="copyright">
                                {{ date('Y') }}
                            </span> <a href="{{ route('welcome') }}"> JobCito </a> All Rights Reserved
                        </p>
                    </div>
                    <hr />
                    <div class="col-md-12 d-flex justify-content-md-center">
                        <ul class="nav">
                            <li class="mb-2">
                                <a href="https://www.facebook.com/jobcitoindia" target="__blank" class="btn btn-info text-white">
                                    <i class="fab fa-facebook-f mr-1 "></i> Facebook Reviews</a>
                            </li>
                            <li>
                                
                                <a href="https://www.google.com/search?q=jobcito&rlz=1C1RLNS_enIN883IN883&oq=jobcito&aqs=chrome..69i57j69i60l6.2685j0j4&sourceid=chrome&ie=UTF-8#lrd=0x3be04f64267a1f93:0x1e67bfcc849f213c,1,,," class="btn btn-danger text-white" target="__blank"><i class="fab fa-google mr-1"></i> Google Reviews</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    @guest

    @if(!Route::currentRouteNamed('register'))
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-hidden="true" style="z-index: 10000;">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header p-4">
                    <h4 class="mb-0 text-center">Register For Free</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body mb-3">
                    @include('auth.modal.register')
                </div>
            </div>
        </div>
    </div>
    @endif

    @if(!Route::currentRouteNamed('login'))
    <div class="modal fade" id="loginModalCenter" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header p-4">
                    <h4 class="mb-0 text-center">Login To Continue</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body mb-3">
                    @include('auth.modal.login')
                </div>
            </div>
        </div>
    </div>
    @endif
    @endguest
    <script type="text/javascript">
        // (function () {
        //     var options = {
        //         whatsapp: "919265727188",
        //         call_to_action: "Feel free to message us, If you have any query :)",
        //         position: "right",
        //     };
        //     var proto = document.location.protocol, hsaost = "getbutton.io", url = proto + "//static." + host;
        //     var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        //     s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        //     var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
        // })();
    </script>
    <script src="{{ asset('assets/js/jquery-3.4.1.min.js') }}"></script>
    <script src="{{ asset('assets/js/popper/popper.min.js') }}"></script>
    <script src="{{ asset('assets/js/bootstrap/bootstrap.min.js') }}"></script>
    <script src="{{ asset('assets/js/jquery.appear.js') }}"></script>
    <script src="{{ asset('assets/js/counter/jquery.countTo.js') }}"></script>
    <script src="{{ asset('assets/js/owl-carousel/owl-carousel.min.js') }}"></script>
    @yield('js-hooks')
    <script src="{{ asset('assets/js/custom.js') }}"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="{{ asset('assets/js/unitls.js') }}"></script>
    @if (session('status'))
    <script>
        toastr["success"]("{{ session('status') }}", "Success");
    </script>
    @endif
    <script>
        function addFavourite(jobId) {
            $.ajax({
                url: "{{ route('favorites.store') }}",
                method: "POST",
                dataType: "JSON",
                data: {
                    _token: "{{ csrf_token() }}",
                    id: jobId
                },
                success: function(data) {
                    toastr["success"](data.success, "Success");
                    $('#favoriteArea-' + jobId).html(`<a class="job-list-favourite order-2" href="javascript:void(0)" onclick="removeFavourite(${jobId})"><i class="fa fa-heart text-danger" id="favorite-${jobId}"></i></a>`);
                },
                error: function(xhr) {
                    toastr["error"]("Something went wrong plese try again letter", "Error!");
                }
            });
        }

        function removeFavourite(jobId) {
            let dataUrl = "{{ route('favorites.destroy', ':jobId') }}";
            dataUrl = dataUrl.replace(':jobId', jobId)
            $.ajax({
                url: dataUrl,
                method: "POST",
                dataType: "JSON",
                data: {
                    _token: "{{ csrf_token() }}",
                    _method: "DELETE",
                    id: jobId
                },
                success: function(data) {
                    toastr["success"](data.success, "Success");
                    $('#favoriteArea-' + jobId).html(`<a class="job-list-favourite order-2" href="javascript:void(0)" onclick="addFavourite(${jobId})"><i class="far fa-heart" id="favorite-${jobId}"></i></a>`);
                },
                error: function(xhr) {
                    toastr["error"]("Something went wrong plese try again letter", "Error!");
                }
            });
        }
    </script>
    <script>
        function applyJob(jobId, type = 'single') {
            $.ajax({
                url: "{{ route('apply-job.store') }}",
                method: "POST",
                dataType: "JSON",
                data: {
                    _token: "{{ csrf_token() }}",
                    id: jobId
                },
                success: function(data) {
                    toastr["success"](data.success, "Success");
                    if (type == 'single') {
                        $('.jobAction').html(`<a class="btn btn-secondary btn-block" href="javascript:void(0)" onclick="removeJob(${jobId})"><i class="fa fa-check"></i>
                            Applied
                        </a>`);
                    } else {
                        $('#jobAction-' + jobId).html(`<a class="btn btn-secondary btn-block" href="javascript:void(0)" onclick="removeJob(${jobId})"><i class="fa fa-check"></i>
                            Applied
                        </a>`);
                    }

                },
                error: function(xhr) {
                    toastr["error"]("Something went wrong plese try again letter", "Error!");
                }
            });
        }

        function removeJob(jobId, type = 'single') {
            let dataUrl = "{{ route('apply-job.destroy', ':jobId') }}";
            dataUrl = dataUrl.replace(':jobId', jobId)
            $.ajax({
                url: dataUrl,
                method: "POST",
                dataType: "JSON",
                data: {
                    _token: "{{ csrf_token() }}",
                    _method: "DELETE",
                    id: jobId
                },
                success: function(data) {
                    toastr["success"](data.success, "Success");
                    if (type == 'single') {
                        $('.jobAction').html(`<a class="btn btn-primary btn-block" href="javascript:void(0)" onclick="applyJob(${jobId})"><i class="far fa-paper-plane"></i>
                            Apply Now
                        </a>`);
                    } else {
                        $('#jobAction-' + jobId).html(`<a class="btn btn-primary btn-block" href="javascript:void(0)" onclick="applyJob(${jobId})"><i class="far fa-paper-plane"></i>
                            Apply Now
                        </a>`);
                    }

                },
                error: function(xhr) {
                    toastr["error"]("Something went wrong plese try again letter", "Error!");
                }
            });
        }
    </script>
    @yield('custom-scripts')
    @stack('scripts')
</body>

</html>