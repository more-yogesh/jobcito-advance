@extends('layouts.app')
@section('content')
<form action="{{ route('search') }}" id="searchForm" method="GET">
  <section class="header-inner header-inner-big bg-holder text-white" style="background-image: url({{ asset('assets/images/bg/banner-01.jpg') }});">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="job-search-field">
            <div class="job-search-item">
              <div class="form row" id="requestForm">
                <div class="col-lg-5">
                  <div class="form-group left-icon">
                    <input type="text" class="form-control" name="job" placeholder="What?" value="{{ request()->job }}">
                    <i class="fas fa-search"></i>
                  </div>
                </div>
                <div class="col-lg-5">
                  <div class="form-group left-icon">
                    <input type="text" class="form-control" name="location" placeholder="Where?" value="{{ request()->location }}">
                    <i class="fas fa-crosshairs"></i>
                  </div>
                </div>
                <div class="col-lg-2 col-sm-12">
                  <div class="form-group form-action">
                    <button type="submit" class="btn btn-primary mt-0"><i class="fas fa-search-location"></i> Find Job</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="space-ptb">
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <div class="sidebar">
            <div class="widget">
              <div class="widget-title widget-collapse">
                <h6>Date Posted</h6>
                <a class="ml-auto" data-toggle="collapse" href="#dateposted" role="button" aria-expanded="false" aria-controls="dateposted"> <i class="fas fa-chevron-down"></i> </a>
              </div>
              <div class="collapse" id="dateposted">
                <div class="widget-content">
                  <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="dateposted1" name="posted_date" value="1" {{request()->posted_date == '1'  ? 'checked' : '' }}>
                    <label class="custom-control-label" for="dateposted1">Last hour</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="dateposted2" name="posted_date" value="24" {{ request()->posted_date == '24'  ? 'checked' : '' }}>
                    <label class="custom-control-label" for="dateposted2">Last 24 hour</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="dateposted3" name="posted_date" value="{{ $day7 = 24*7 }}" {{  request()->posted_date == $day7 ? 'checked' : '' }}>
                    <label class="custom-control-label" for="dateposted3">Last 7 days</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="dateposted4" name="posted_date" value="{{ $day14 = 24*14 }}" {{  request()->posted_date == $day14 ? 'checked' : '' }}>
                    <label class="custom-control-label" for="dateposted4">Last 14 days</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="dateposted5" name="posted_date" value="{{ $day30 = 24*30}}" {{  request()->posted_date == $day30 ? 'checked' : '' }}>
                    <label class="custom-control-label" for="dateposted5">Last 30 days</label>
                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="widget">
              <div class="widget-title widget-collapse">
                <h6>Category </h6>
                <a class="ml-auto" data-toggle="collapse" href="#specialism" role="button" aria-expanded="false" aria-controls="specialism"></a>
              </div>
              <div class="collapse show" id="specialism">
                <div class="widget-content">
                  <div class="form-group">
                    <select name="category_id" class="form-control">
                      <option value="">Select</option>
                      @foreach($categories as $category)
                      <option value="{{ $category->id }}" {{ $category->id == request()->category_id ? 'selected' : '' }}>{{ $category->name }}</option>
                      @endforeach
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="widget">
              <div class="widget-title widget-collapse">
                <h6>Job Type</h6>
                <a class="ml-auto" data-toggle="collapse" href="#jobtype" role="button" aria-expanded="false" aria-controls="jobtype"> <i class="fas fa-chevron-down"></i> </a>
              </div>
              <div class="collapse" id="jobtype">
                <div class="widget-content">
                  @foreach($jobTypes as $jobType)
                  <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="jobtype{{ $jobType->id }}" name="job_type[]" value="{{ $jobType->id }}" {{ in_array($jobType->id, request()->job_type ?? []) ? 'checked' : '' }}>
                    <label class="custom-control-label text-capitalize" for="jobtype{{ $jobType->id }}">{{ $jobType->name }}</label>
                  </div>
                  @endforeach
                </div>
              </div>
            </div>
            <hr>
            <div class="widget">
              <div class="widget-title widget-collapse">
                <h6>Offered Salary</h6>
                <a class="ml-auto" data-toggle="collapse" href="#Offeredsalary" role="button" aria-expanded="false" aria-controls="Offeredsalary"> <i class="fas fa-chevron-down"></i> </a>
              </div>
              <div class="collapse" id="Offeredsalary">
                <div class="widget-content">
                  <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="Offeredsalary1" name="salary_range" value="5-20" {{ '5-20' == request()->salary_range ? 'checked' : '' }}>
                    <label class="custom-control-label" for="Offeredsalary1">05k - 20k</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="Offeredsalary2" name="salary_range" value="20-30" {{ '20-30' == request()->salary_range ? 'checked' : '' }}>
                    <label class="custom-control-label" for="Offeredsalary2">20k - 30k</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="Offeredsalary3" name="salary_range" value="30-40" {{ '30-40' == request()->salary_range ? 'checked' : '' }}>
                    <label class="custom-control-label" for="Offeredsalary3">30k - 40k</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="Offeredsalary4" name="salary_range" value="40-50" {{ '40-50' == request()->salary_range ? 'checked' : '' }}>
                    <label class="custom-control-label" for="Offeredsalary4">40k - 50k</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="Offeredsalary5" name="salary_range" value="50-above" {{ '50-above' == request()->salary_range ? 'checked' : '' }}>
                    <label class="custom-control-label" for="Offeredsalary5">50k - & Above</label>
                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="widget">
              <div class="widget-add">
                <button class="btn btn-primary btn-block" type="submit" id="searchFormButton">Search</button>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-9">
          <div class="row mb-4">
            <div class="col-md-6">
              <div class="section-title mb-3 mb-lg-4">
                @if($jobs->count()>0)
                <h6 class="mb-0">Your search contain <span class="text-primary">{{ $jobs->count() }} Jobs</span></h6>
                @endif
              </div>
            </div>
            <div class="col-md-6">
              <div class="job-filter-tag">
                <ul class="list-unstyled">
                  <li><a class="filter-clear" href="{{ route('search') }}">Reset Search <i class="fas fa-redo-alt"></i> </a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="row">
            @forelse($jobs as $job)
            <div class="col-12 mt-2">
              <div class="job-list rounded border border-danger">
                <div class="job-list-logo">
                  @php
                  $logo = $job->user->getFirstMediaUrl('profiles', 'logo');
                  if($logo == ''){
                  $logo = asset('company.png');
                  }
                  @endphp
                  <a href="{{ route('showJob', $job->jobSlug()) }}">
                    <img class="img-fluid" src="{{$logo}}" alt="{{ $job->user->company->name }}" />
                  </a>
                </div>
                <div class="job-list-details">
                  <div class="job-list-info">
                    <div class="job-list-title">
                      <h5 class="mb-0"><a href="{{ route('showJob', $job->jobSlug()) }}">{{$job->title}}</a>
                        @if($job->Applied())
                        <small>
                          <span class="badge badge-secondary text-white p-1" style="font-weight: normal;"><i class="fa fa-check"></i> Applied</span>
                        </small>
                        @endif
                      </h5>
                    </div>
                    <div class="job-list-option">
                      <ul class="list-unstyled">
                        <li> <span>via</span> <a href="{{ route('showCopmany', $job->companySlug()) }}">{{ $job->user->company->name }}</a> </li>
                        <li><i class="fas fa-map-marker-alt pr-1"></i>{{ $job->user->company->city }}, {{ $job->user->company->state }}</li>
                        <li><i class="fas fa-filter pr-1"></i>{{ $job->category->name }}</li>
                        <li><a class="freelance text-capitalize" href="#"><i class="fas fa-suitcase pr-1"></i>{{ $job->jobType->name }}</a></li>
                      </ul>
                    </div>
                    <div class="job-list-option">
                      <div class="job-list-title text-dark">
                        @if($job->salary_from)
                        ₹ {{ number_format($job->salary_from) }} <i> - </i> ₹ {{ number_format($job->salary_to) ?? ''}}
                        @else
                        Not Spacified
                        @endif
                      </div>
                    </div>
                  </div>
                </div>
                <div class="job-list-favourite-time" id="favoriteArea-{{$job->id}}">
                  @role('employee')
                  @if($job->favorited())
                  <a class="job-list-favourite order-2" href="javascript:void(0)" onclick="removeFavourite({{$job->id}})"><i class="fa fa-heart text-danger" id="favorite-{{$job->id}}"></i></a>
                  @else
                  <a class="job-list-favourite order-2" href="javascript:void(0)" onclick="addFavourite({{$job->id}})"><i class="far fa-heart" id="favorite-{{$job->id}}"></i></a>
                  @endif
                  @endrole
                  @guest
                  <a class="job-list-favourite order-2" href="javascript:void(0)" data-toggle="modal" data-target="#loginModalCenter"><i class="far fa-heart"></i></a>
                  @endguest
                  <span class="job-list-time order-1">
                    <i class="far fa-clock pr-1"></i>{{$job->created_at->diffForHumans()}}</span>
                </div>
              </div>
            </div>
            @empty
            <div class="col-12 text-center">
              <div class="job-list border border-danger">
                <h4 class="mx-auto">No jobs found</h4>
              </div>
            </div>
            @endforelse
          </div>
          <div class="row">
            <div class="col-12 text-center mt-4 mt-md-5">
              {{ $jobs->links() }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</form>
@endsection